# 🧪 Guía de Pruebas e Integración - SINAR XAMPP

## 📋 Pre-Requisitos

- ✅ Flask ejecutándose en `http://localhost:5000`
- ✅ XAMPP (Apache + MySQL) iniciado
- ✅ Base de datos `prestamos_radios` creada
- ✅ App Flutter compilada sin errores
- ✅ URL base en `api_service.dart` configurada como `http://localhost:5000`

---

## 🔍 Fase 1: Verificación de Conectividad

### Test 1.1: Verificar Flask Activo
```bash
# En PowerShell, ejecuta:
curl http://localhost:5000

# Resultado esperado:
# StatusCode        : 404 (está bien, Flask está respondiendo)
```

### Test 1.2: Probar Endpoint de Autenticación
```bash
# En PowerShell, ejecuta:
$body = @{
    usuario = "admin"
    password = "123456"
} | ConvertTo-Json

$response = Invoke-WebRequest -Uri "http://localhost:5000/api/login" `
    -Method POST `
    -Body $body `
    -ContentType "application/json"

$response.Content

# Resultado esperado:
# {"status":"ok","tecnico":"admin"}  (si el usuario existe)
# {"error":"Credenciales inválidas"}  (si no existe)
```

### Test 1.3: Verificar Funcionarios
```bash
# En PowerShell:
$response = Invoke-WebRequest -Uri "http://localhost:5000/api/funcionarios"
$response.Content | ConvertFrom-Json

# Resultado esperado: Array de funcionarios
# [
#   {"id":1,"nombre":"Juan Perez","cedula":"12345678","unidad":"GUTIC"},
#   ...
# ]
```

---

## 🗄️ Fase 2: Verificación de Base de Datos

### Checklist de Integridad de Datos

Abre phpMyAdmin y verifica:

#### ✅ Tabla: `funcionarios`
```sql
SELECT * FROM funcionarios LIMIT 5;
```
**Esperado**:
- [ ] Mínimo 5 registros
- [ ] Campos: identificacion (único), apellidos_nombres, grado, unidad, cargo, celular
- [ ] Sin valores nulos en campos críticos

#### ✅ Tabla: `tecnicos`
```sql
SELECT * FROM tecnicos;
```
**Esperado**:
- [ ] Mínimo 3 técnicos
- [ ] Campos: nombre, grado, cargo, correo
- [ ] Nombres válidos (sin valores nulos)

#### ✅ Tabla: `radios`
```sql
SELECT * FROM radios;
```
**Esperado**:
- [ ] Mínimo 10 radios
- [ ] Campos: serial (único), modelo, accesorios, observaciones
- [ ] Serial sin valores duplicados

#### ✅ Tabla: `prestamos`
```sql
SELECT * FROM prestamos;
```
**Esperado**:
- [ ] Pueden estar vacíos (nuevos registros se crean desde app)
- [ ] Si hay datos: fechas válidas, IDs de relaciones válidos

#### ✅ Tabla: `usuarios`
```sql
SELECT usuario FROM usuarios;
```
**Esperado**:
- [ ] Mínimo 1 usuario para login
- [ ] Si está vacía, ejecuta: `python crear_usuarios.py` en carpeta Flask

---

## 📱 Fase 3: Pruebas en la App

### Test 3.1: Login
**Pasos**:
1. Abre la app
2. Ve a pantalla de **Login**
3. Ingresa credenciales existentes en BD (tabla `usuarios`)
4. Presiona **Iniciar sesión**

**Esperado**:
- ✅ App navega a pantalla principal
- ✅ Muestra nombre del usuario
- ✅ Pestaña "Registro de Préstamo" es visible

**Si falla**:
- Verifica usuario existe en BD: `SELECT * FROM usuarios;` en phpMyAdmin
- Verifica Flask sigue ejecutándose
- Revisa logs en terminal de Flask

---

### Test 3.2: Búsqueda de Funcionario
**Pasos**:
1. En pantalla **Registro de Préstamo**
2. Ingresa cédula de funcionario existente
3. Presiona **Buscar**

**Esperado**:
- ✅ Los campos se rellenan automáticamente:
  - Nombre
  - Grado
  - Celular
  - Unidad
  - Cargo
- ✅ Puedes editar los datos

**Si falla**:
```sql
-- En phpMyAdmin, verifica:
SELECT * FROM funcionarios WHERE identificacion = '1234567890';
```

---

### Test 3.3: Crear Préstamo (Flujo Completo)
**Pasos**:
1. Busca funcionario (Test 3.2)
2. Selecciona **Técnico que entrega**
3. Selecciona **Radio disponible**
4. Ingresa **Accesorios** (opcional)
5. Ingresa **Observaciones** (opcional)
6. Dibuja **Firma**
7. Presiona **Guardar Préstamo**

**Esperado**:
- ✅ Mensaje: "Préstamo registrado exitosamente"
- ✅ PDF se genera en: `C:\Users\luish\Downloads\prestamos_radios\`
- ✅ Nuevo registro en tabla `prestamos`

**Verificación en BD**:
```sql
SELECT * FROM prestamos 
ORDER BY fecha_asignacion DESC 
LIMIT 1;
```

---

### Test 3.4: Ver Préstamos Activos
**Pasos**:
1. Ve a pestaña **Listado**
2. Verifica que aparezca el préstamo creado en Test 3.3

**Esperado**:
- ✅ Préstamo visible en la lista
- ✅ Muestra:
  - Nombre del funcionario
  - Serial del radio
  - Fecha de asignación
  - Estado (Activo/Alerta/Vencido)
  - Días transcurridos

---

### Test 3.5: Registrar Devolución
**Pasos**:
1. Ve a pestaña **Devoluciones**
2. Selecciona un préstamo activo
3. Dibuja firma
4. Presiona **Guardar Devolución**

**Esperado**:
- ✅ Mensaje: "Devolución registrada exitosamente"
- ✅ Préstamo ya no aparece en listado activos
- ✅ Fecha de devolución en BD

**Verificación en BD**:
```sql
SELECT * FROM prestamos 
WHERE fecha_devolucion IS NOT NULL 
ORDER BY fecha_devolucion DESC 
LIMIT 1;
```

---

### Test 3.6: Ver Reportes
**Pasos**:
1. Ve a pestaña **Reportes**
2. Espera a que carguen los datos

**Esperado - Estadísticas Generales**:
- ✅ Total de radios
- ✅ Radios disponibles
- ✅ Radios en préstamo
- ✅ Total funcionarios
- ✅ Total técnicos
- ✅ Préstamos activos
- ✅ Préstamos devueltos
- ✅ Tasa de uso

**Esperado - Gráficas**:
- ✅ Radios más asignados (top 10)
- ✅ Funcionarios con más préstamos (top 10)
- ✅ Técnicos más activos (top 10)
- ✅ Radios por unidad

**Si falla**:
- Verifica que haya datos en BD
- Revisa endpoint: `curl http://localhost:5000/api/reportes/estadisticas`

---

## 🛠️ Fase 4: Pruebas de Manejo de Errores

### Test 4.1: Búsqueda de Funcionario Inexistente
**Pasos**:
1. Ingresa cédula que no existe (ej: "9999999999")
2. Presiona **Buscar**

**Esperado**:
- ✅ Mensaje: "Funcionario no encontrado..."
- ✅ Se habilita entrada manual de datos
- ✅ Puedes ingresar datos manualmente

---

### Test 4.2: Radio Sin Disponibilidad
**Pasos**:
1. Intenta crear préstamo
2. Si el dropdown de radios está vacío

**Esperado**:
- ✅ Mensaje informativo: "No hay radios disponibles"
- ✅ O dropdown muestra opción vacía

**Solución**:
- Devolución de radios (Test 3.5)
- O verificar radios no están en préstamo activo

---

### Test 4.3: Desconexión de Red
**Pasos**:
1. Desactiva WiFi/Ethernet
2. Intenta hacer login o buscar funcionario

**Esperado**:
- ✅ Error informativo: "Error de conexión"
- ✅ No crash de la app

---

## 📊 Fase 5: Validación de Datos

### Script de Validación SQL

```sql
-- Verifica integridad referencial
SELECT COUNT(*) as prestamos_sin_funcionario 
FROM prestamos p 
WHERE NOT EXISTS (SELECT 1 FROM funcionarios f WHERE f.id = p.funcionario_id);

SELECT COUNT(*) as prestamos_sin_radio 
FROM prestamos p 
WHERE NOT EXISTS (SELECT 1 FROM radios r WHERE r.id = p.radio_id);

SELECT COUNT(*) as prestamos_sin_tecnico 
FROM prestamos p 
WHERE NOT EXISTS (SELECT 1 FROM tecnicos t WHERE t.id = p.tecnico_presta_id);

-- Resultado esperado: 0 en todos
```

**Esperado**: Todas las consultas retornan `0`

---

## ✅ Checklist Final

### Conectividad
- [ ] Flask responde en `http://localhost:5000`
- [ ] XAMPP ejecutando (Apache + MySQL)
- [ ] Base de datos accesible en phpMyAdmin

### Datos
- [ ] Tabla `funcionarios` tiene registros
- [ ] Tabla `tecnicos` tiene registros
- [ ] Tabla `radios` tiene registros
- [ ] Tabla `usuarios` tiene registros
- [ ] Integridad referencial verificada

### App
- [ ] App compila sin errores
- [ ] Login funciona
- [ ] Búsqueda de funcionarios funciona
- [ ] Crear préstamo funciona
- [ ] PDF se genera correctamente
- [ ] Listado de préstamos funciona
- [ ] Devoluciones funcionan
- [ ] Reportes cargan datos

### Errores
- [ ] Mensajes de error son informativos
- [ ] App no hace crash
- [ ] Manejo de desconexión de red

---

## 🐛 Troubleshooting

### Problema: "Connection refused"
```
Solución:
1. Verifica Flask: python app.py
2. Verifica puerto 5000 disponible: netstat -ano | findstr :5000
3. Si está en uso: taskkill /PID <pid> /F
```

### Problema: "Database connection error"
```
Solución:
1. Verifica MySQL: En XAMPP, inicia MySQL
2. Verifica credenciales en app.py config
3. Verifica BD existe: SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA;
```

### Problema: "Funcionario no encontrado" siempre
```
Solución:
1. Verifica datos en BD: SELECT COUNT(*) FROM funcionarios;
2. Importa datos: python importar_funcionarios.py
3. Prueba con cédula conocida
```

### Problema: "Préstamo guardado pero sin PDF"
```
Solución:
1. Verifica carpeta Downloads: C:\Users\luish\Downloads\prestamos_radios\
2. Verifica permisos de escritura
3. Verifica ReportLab instalado: pip install reportlab
```

---

## 📞 Logs Importantes

### Ver logs de Flask
```bash
# En la terminal donde corre Flask, verás:
[DEBUG] GET /api/funcionario/1234567890
[200] response sent
```

### Ver logs de Flutter
```bash
flutter logs
```

### Base de datos - Ver últimas operaciones
```sql
SELECT * FROM prestamos ORDER BY fecha_asignacion DESC LIMIT 5;
```

---

**Última actualización**: 26 de Mayo, 2026
**Estado**: Listo para Pruebas Integrales ✅
