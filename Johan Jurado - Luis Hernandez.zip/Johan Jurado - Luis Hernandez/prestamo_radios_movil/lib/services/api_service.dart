//import 'dart:convert';
//import 'package:http/http.dart' as http;
//import '../models/funcionario.dart';
//import '../models/prestamo_activo.dart';
//import '../models/tecnico.dart';
//import '../models/radio.dart';

import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:prestamo_radios_movil/models/funcionario.dart';
import 'package:prestamo_radios_movil/models/prestamo_activo.dart';
import 'package:prestamo_radios_movil/models/radio.dart';
import 'package:prestamo_radios_movil/models/tecnico.dart';

class ApiService {
  // URL base apuntando a Flask en XAMPP
  // Cambiar a IP local si se accede desde otro dispositivo
  static const String baseUrl = 'http://10.191.146.217:5000';

  static Future<List> obtenerFuncionarios() async {
    final response = await http.get(Uri.parse("$baseUrl/funcionarios"));

    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw Exception("Error al cargar funcionarios");
    }
  }

  static Future<List<Tecnico>> obtenerTecnicos() async {
    final res = await http.get(Uri.parse('$baseUrl/api/tecnicos'));
    if (res.statusCode == 200) {
      final List data = jsonDecode(res.body);
      return data.map((e) => Tecnico.fromJson(e)).toList();
    }
    return [];
  }

  static Future<List<Radio>> obtenerRadiosDisponibles() async {
    final res = await http.get(Uri.parse('$baseUrl/api/radios_disponibles'));
    if (res.statusCode == 200) {
      final List data = jsonDecode(res.body);
      return data.map((e) => Radio.fromJson(e)).toList();
    }
    return [];
  }

  static Future<List<Radio>> obtenerRadios() async {
    return obtenerRadiosDisponibles();
  }

  static Future<Funcionario?> buscarFuncionario(String cedula) async {
    final url = Uri.parse('$baseUrl/api/funcionario/$cedula');
    final response = await http.get(url);
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data['exists'] == true) {
        return Funcionario.fromJson(data);
      }
    }
    return null;
  }

  /// Actualiza los datos de un funcionario existente en el servidor.
  /// Retorna true si la actualización fue exitosa.
  static Future<bool> actualizarFuncionario(
    String cedula,
    Map<String, dynamic> datos,
  ) async {
    try {
      final response = await http.put(
        Uri.parse('$baseUrl/api/funcionario/$cedula'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(datos),
      );
      if (response.statusCode == 200) {
        return true;
      }
      throw Exception('Error ${response.statusCode}: ${response.body}');
    } catch (e) {
      throw Exception('Error al actualizar funcionario: $e');
    }
  }

  static Future<String> registrarPrestamo(
    Map<String, dynamic> datos,
    String firmaBase64,
  ) async {
    final body = {...datos, 'firma': firmaBase64};

    try {
      print('📤 Enviando préstamo a: $baseUrl/api/prestamo');
      print('📦 Datos: $datos');

      final response = await http.post(
        Uri.parse('$baseUrl/api/prestamo'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(body),
      );

      print('📡 Status: ${response.statusCode}');
      print('📨 Response: ${response.body}');

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final pdf = data['pdf'] ?? data['pdfUrl'] ?? '';
        if (pdf.isNotEmpty) {
          print('✅ PDF generado: $pdf');
          return pdf;
        } else {
          print('⚠️ PDF vacío en respuesta');
          return 'Préstamo registrado (sin PDF)';
        }
      } else if (response.statusCode == 201) {
        final data = jsonDecode(response.body);
        final pdf = data['pdf'] ?? data['pdfUrl'] ?? '';
        print('✅ Creado (201): ${pdf.isNotEmpty ? pdf : 'sin PDF'}');
        return pdf.isNotEmpty ? pdf : 'Préstamo registrado';
      } else {
        print('❌ Error: ${response.statusCode} - ${response.body}');
        throw Exception('Error ${response.statusCode}: ${response.body}');
      }
    } catch (e) {
      print('💥 Excepción: $e');
      throw Exception('Error al registrar: $e');
    }
  }

  // ── Versión original — devuelve objetos PrestamoActivo ────────────────
  static Future<List<PrestamoActivo>> obtenerPrestamosActivos() async {
    final res = await http.get(Uri.parse('$baseUrl/api/prestamos_activos'));
    if (res.statusCode == 200) {
      final List data = jsonDecode(res.body);
      return data.map((e) => PrestamoActivo.fromJson(e)).toList();
    }
    return [];
  }

  // ── Nueva versión — devuelve Maps crudos ─────────────────────────────
  static Future<List<Map<String, dynamic>>> obtenerPrestamosActivosMap() async {
    final res = await http.get(Uri.parse('$baseUrl/api/prestamos_activos'));
    if (res.statusCode == 200) {
      final List data = jsonDecode(res.body);
      return data.map((e) => Map<String, dynamic>.from(e)).toList();
    }
    return [];
  }

  static Future<void> registrarDevolucion(
    int prestamoId,
    String tecnico,
    String firmaBase64,
  ) async {
    final response = await http.post(
      Uri.parse('$baseUrl/api/devolucion'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'prestamo_id': prestamoId,
        'tecnico': tecnico,
        'firma': firmaBase64,
      }),
    );
    if (response.statusCode != 200) {
      throw Exception('Error al registrar devolución: ${response.body}');
    }
  }

  static Future<Map<String, dynamic>?> login(
    String usuario,
    String password,
  ) async {
    final response = await http.post(
      Uri.parse('$baseUrl/api/login'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'usuario': usuario, 'password': password}),
    );
    if (response.statusCode == 200) {
      return jsonDecode(response.body) as Map<String, dynamic>;
    }
    return null;
  }

  // ════════════════════════════════════════════════════════════════════════
  // ENDPOINTS DE REPORTES
  // ════════════════════════════════════════════════════════════════════════

  /// Retorna estadísticas globales del sistema.
  static Future<Map<String, dynamic>> obtenerEstadisticas() async {
    final res = await http.get(Uri.parse('$baseUrl/api/reportes/estadisticas'));
    if (res.statusCode == 200) {
      return Map<String, dynamic>.from(jsonDecode(res.body));
    }
    throw Exception('Error al obtener estadísticas: ${res.statusCode}');
  }

  /// Radios más asignados (por número de préstamos).
  static Future<List<Map<String, dynamic>>> obtenerReporteRadios() async {
    final res = await http.get(
      Uri.parse('$baseUrl/api/reportes/radios_mas_asignadas'),
    );
    if (res.statusCode == 200) {
      final List data = jsonDecode(res.body);
      return data.map((e) => Map<String, dynamic>.from(e)).toList();
    }
    throw Exception('Error al obtener reporte radios: ${res.statusCode}');
  }

  /// Funcionarios con más préstamos.
  static Future<List<Map<String, dynamic>>> obtenerReporteFuncionarios() async {
    final res = await http.get(
      Uri.parse('$baseUrl/api/reportes/funcionarios_mas_radios'),
    );
    if (res.statusCode == 200) {
      final List data = jsonDecode(res.body);
      return data.map((e) => Map<String, dynamic>.from(e)).toList();
    }
    throw Exception('Error al obtener reporte funcionarios: ${res.statusCode}');
  }

  /// Técnicos más activos (entregas y recepciones).
  static Future<List<Map<String, dynamic>>> obtenerReporteTecnicos() async {
    final res = await http.get(
      Uri.parse('$baseUrl/api/reportes/tecnicos_mas_radios'),
    );
    if (res.statusCode == 200) {
      final List data = jsonDecode(res.body);
      return data.map((e) => Map<String, dynamic>.from(e)).toList();
    }
    throw Exception('Error al obtener reporte técnicos: ${res.statusCode}');
  }

  /// Unidades con más radios activos en préstamo.
  static Future<List<Map<String, dynamic>>> obtenerReporteUnidades() async {
    final res = await http.get(
      Uri.parse('$baseUrl/api/reportes/radios_por_unidad'),
    );
    if (res.statusCode == 200) {
      final List data = jsonDecode(res.body);
      return data.map((e) => Map<String, dynamic>.from(e)).toList();
    }
    throw Exception('Error al obtener reporte unidades: ${res.statusCode}');
  }
}
