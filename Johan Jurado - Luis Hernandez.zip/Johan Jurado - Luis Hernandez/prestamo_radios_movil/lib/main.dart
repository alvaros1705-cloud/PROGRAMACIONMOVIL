import 'package:flutter/material.dart';
import 'screens/login_screen.dart';

void main() {
  runApp(const PrestamoRadiosApp());
}

class PrestamoRadiosApp extends StatelessWidget {
  const PrestamoRadiosApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Préstamo de Radios',
      theme: ThemeData(primarySwatch: Colors.blueGrey),
      home: const LoginScreen(),
    );
  }
}
