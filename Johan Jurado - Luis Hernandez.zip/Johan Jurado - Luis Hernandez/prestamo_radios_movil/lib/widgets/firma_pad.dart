import 'dart:ui' as ui;
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter_signature_pad/flutter_signature_pad.dart';

const Color _teal = Color(0xFF1A7A8A);
const Color _rojo = Color(0xFFCC0000);

class FirmaPad extends StatefulWidget {
  final Function(ByteData?) onSave;

  const FirmaPad({super.key, required this.onSave});

  @override
  State<FirmaPad> createState() => _FirmaPadState();
}

class _FirmaPadState extends State<FirmaPad> {
  final GlobalKey<SignatureState> _signKey = GlobalKey<SignatureState>();
  bool _procesando = false;
  bool _tieneFirma = false;

  Future<void> _guardarFirma() async {
    // Evita doble tap
    if (_procesando) return;

    setState(() => _procesando = true);

    try {
      final ui.Image image = await _signKey.currentState!.getData();
      final ByteData? data = await image.toByteData(
        format: ui.ImageByteFormat.png,
      );

      // ✅ FIX CRÍTICO: verificar mounted antes de usar el callback
      if (!mounted) return;

      widget.onSave(data);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: _rojo,
          content: Text('Error al procesar firma: $e'),
        ),
      );
    } finally {
      // Solo actualiza estado si el widget sigue montado
      if (mounted) setState(() => _procesando = false);
    }
  }

  void _limpiar() {
    _signKey.currentState?.clear();
    setState(() => _tieneFirma = false);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // ── Área de firma ───────────────────────────────────────────
        Container(
          height: 200,
          width: double.infinity,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: _tieneFirma ? _teal : Colors.grey.shade400,
              width: _tieneFirma ? 2 : 1,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.06),
                blurRadius: 6,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: Stack(
              children: [
                Signature(
                  key: _signKey,
                  color: Colors.black,
                  strokeWidth: 3.0,
                  backgroundPainter: null,
                  onSign: () {
                    // Detecta cuando el usuario empieza a firmar
                    if (!_tieneFirma) setState(() => _tieneFirma = true);
                  },
                ),
                // Texto guía cuando no hay firma
                if (!_tieneFirma)
                  const Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.draw_outlined, color: Colors.grey, size: 32),
                        SizedBox(height: 6),
                        Text(
                          'Firme aquí',
                          style: TextStyle(color: Colors.grey, fontSize: 13),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ),

        const SizedBox(height: 12),

        // ── Botones ─────────────────────────────────────────────────
        Row(
          children: [
            // Botón Limpiar
            Expanded(
              child: OutlinedButton.icon(
                icon: const Icon(Icons.clear, size: 18),
                label: const Text('Limpiar'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: _rojo,
                  side: const BorderSide(color: _rojo),
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                onPressed: _limpiar,
              ),
            ),

            const SizedBox(width: 12),

            // Botón Guardar firma
            Expanded(
              flex: 2,
              child: ElevatedButton.icon(
                icon: _procesando
                    ? const SizedBox(
                        height: 18,
                        width: 18,
                        child: CircularProgressIndicator(
                          color: Colors.white,
                          strokeWidth: 2,
                        ),
                      )
                    : const Icon(Icons.check, size: 18),
                label: Text(
                  _procesando ? 'Procesando...' : 'Confirmar firma',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: _tieneFirma ? _teal : Colors.grey,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                // Solo habilita si hay firma y no está procesando
                onPressed: (_tieneFirma && !_procesando) ? _guardarFirma : null,
              ),
            ),
          ],
        ),
      ],
    );
  }
}
