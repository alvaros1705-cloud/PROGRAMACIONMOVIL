import 'package:flutter/material.dart';
import 'package:flutter/material.dart';
import '../services/api_service.dart';

class FuncionariosScreen extends StatelessWidget {
  const FuncionariosScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Funcionarios")),
      body: FutureBuilder(
        future: ApiService.obtenerFuncionarios(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasData) {
            final lista = snapshot.data as List;

            return ListView.builder(
              itemCount: lista.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(lista[index]["nombre"]),
                  subtitle: Text(lista[index]["cedula"]),
                );
              },
            );
          }

          return Center(child: Text("Error cargando datos"));
        },
      ),
    );
  }
}
