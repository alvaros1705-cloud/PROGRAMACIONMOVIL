import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import '../models/prestamo_activo.dart';
import '../services/api_service.dart';
import '../widgets/firma_pad.dart';

// ─── COLORES INSTITUCIONALES ───────────────────────────────────────────────
const Color _teal = Color(0xFF1A7A8A);
const Color _tealDark = Color(0xFF145F6E);
const Color _tealLight = Color(0xFFE0F4F7);
const Color _rojo = Color(0xFFCC0000);

class DevolucionScreen extends StatefulWidget {
  final int? prestamoIdInicial;
  const DevolucionScreen({super.key, this.prestamoIdInicial});

  @override
  State<DevolucionScreen> createState() => _DevolucionScreenState();
}

class _DevolucionScreenState extends State<DevolucionScreen> {
  List<PrestamoActivo> _prestamos = [];
  PrestamoActivo? _seleccionado;

  bool _cargando = true;
  bool _guardando = false;
  bool _firmaLista = false;
  Uint8List? _firmaBytes;

  @override
  void initState() {
    super.initState();
    _cargar();
  }

  Future<void> _cargar() async {
    try {
      final lista = await ApiService.obtenerPrestamosActivos();
      if (!mounted) return;

      setState(() {
        _prestamos = lista;
        _cargando = false;
      });

      if (widget.prestamoIdInicial != null) {
        final match = _prestamos.cast<PrestamoActivo?>().firstWhere(
          (p) => p?.id == widget.prestamoIdInicial,
          orElse: () => null,
        );
        if (match != null && mounted) {
          setState(() => _seleccionado = match);
        }
      }
    } catch (e) {
      if (!mounted) return;
      _toast('Error: $e');
    }
  }

  void _toast(String msg) {
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(backgroundColor: _rojo, content: Text(msg)));
  }

  Future<void> _guardar() async {
    if (_seleccionado == null || _firmaBytes == null) {
      _toast('Completa todos los campos');
      return;
    }

    setState(() => _guardando = true);
    try {
      String firmaBase64 = base64Encode(_firmaBytes!);
      // TODO: Obtener el ID real del técnico logueado desde login
      // Por ahora usa 1 (primer técnico en base de datos)
      await ApiService.registrarDevolucion(
        _seleccionado!.id,
        '1', // Cambiar a ID del técnico actual logueado
        firmaBase64,
      );

      if (!mounted) return;
      _toast('Devolución registrada exitosamente');
      Navigator.pop(context);
    } catch (e) {
      if (!mounted) return;
      _toast('Error: $e');
    } finally {
      if (mounted) setState(() => _guardando = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: _teal,
        foregroundColor: Colors.white,
        elevation: 3,
        title: const Text('Registrar Devolución'),
      ),
      body: Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              'assets/images/MonedaCara1.png',
              fit: BoxFit.cover,
              color: Colors.white.withValues(alpha: 0.06),
              colorBlendMode: BlendMode.modulate,
              errorBuilder: (_, __, ___) =>
                  Container(color: const Color(0xFFEEEEEE)),
            ),
          ),
          _cargando
              ? const Center(child: CircularProgressIndicator(color: _teal))
              : SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // ── Encabezado de sección ──────────────────────
                      const _SeccionTitulo(
                        icono: Icons.assignment_return,
                        titulo: 'Registrar Devolución',
                        subtitulo:
                            'Selecciona el préstamo activo y captura la firma',
                      ),
                      const SizedBox(height: 20),

                      // ── Selector de préstamo ───────────────────────
                      _Tarjeta(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _LabelCampo(
                              icono: Icons.radio,
                              label: 'Préstamo activo',
                            ),
                            const SizedBox(height: 8),
                            DropdownButtonFormField<PrestamoActivo>(
                              initialValue: _seleccionado,
                              hint: const Text('Seleccione un préstamo'),
                              isExpanded: true,
                              decoration: _inputDeco(''),
                              items: _prestamos.map((p) {
                                return DropdownMenuItem(
                                  value: p,
                                  child: Text(
                                    '${p.radio} — ${p.funcionario}',
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                );
                              }).toList(),
                              onChanged: (v) => setState(() {
                                _seleccionado = v;
                                _firmaBytes = null;
                                _firmaLista = false;
                              }),
                            ),
                          ],
                        ),
                      ),

                      if (_seleccionado != null) ...[
                        const SizedBox(height: 16),
                        _TarjetaDetalle(prestamo: _seleccionado!),
                        const SizedBox(height: 16),

                        // ── Firma ────────────────────────────────────
                        _Tarjeta(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              _LabelCampo(
                                icono: Icons.draw,
                                label: 'Firma del funcionario',
                              ),
                              const SizedBox(height: 10),
                              FirmaPad(
                                onSave: (firma) {
                                  if (firma == null) return;
                                  setState(() {
                                    _firmaBytes = firma.buffer.asUint8List();
                                    _firmaLista = true;
                                  });
                                },
                              ),
                              if (_firmaLista)
                                Padding(
                                  padding: const EdgeInsets.only(top: 8),
                                  child: const Row(
                                    children: [
                                      Icon(
                                        Icons.check_circle,
                                        color: _teal,
                                        size: 16,
                                      ),
                                      SizedBox(width: 6),
                                      Text(
                                        'Firma capturada',
                                        style: TextStyle(
                                          color: _teal,
                                          fontSize: 13,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ],

                      const SizedBox(height: 24),
                      SizedBox(
                        width: double.infinity,
                        height: 52,
                        child: ElevatedButton.icon(
                          icon: const Icon(Icons.check),
                          label: const Text(
                            'GUARDAR DEVOLUCIÓN',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: _teal,
                            foregroundColor: Colors.white,
                            disabledBackgroundColor: Colors.grey.shade300,
                          ),
                          onPressed:
                              _guardando ||
                                  _seleccionado == null ||
                                  !_firmaLista
                              ? null
                              : _guardar,
                        ),
                      ),
                    ],
                  ),
                ),
        ],
      ),
    );
  }

  InputDecoration _inputDeco(String label) => InputDecoration(
    label: Text(label),
    border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(10),
      borderSide: BorderSide(color: _teal.withValues(alpha: 0.4)),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(10),
      borderSide: const BorderSide(color: _teal, width: 2),
    ),
  );
}

// ─── WIDGETS HELPER ───────────────────────────────────────────────────────
class _Tarjeta extends StatelessWidget {
  final Widget child;
  const _Tarjeta({required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.93),
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.08),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: child,
    );
  }
}

class _SeccionTitulo extends StatelessWidget {
  final IconData icono;
  final String titulo;
  final String subtitulo;
  const _SeccionTitulo({
    required this.icono,
    required this.titulo,
    required this.subtitulo,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: _tealLight,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(icono, color: _teal, size: 26),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                titulo,
                style: const TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.bold,
                  color: _tealDark,
                ),
              ),
              Text(
                subtitulo,
                style: const TextStyle(fontSize: 12, color: Color(0xFF777777)),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _LabelCampo extends StatelessWidget {
  final IconData icono;
  final String label;
  const _LabelCampo({required this.icono, required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icono, size: 18, color: _teal),
        const SizedBox(width: 8),
        Text(
          label,
          style: const TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.bold,
            color: _teal,
          ),
        ),
      ],
    );
  }
}

class _TarjetaDetalle extends StatelessWidget {
  final PrestamoActivo prestamo;
  const _TarjetaDetalle({required this.prestamo});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.95),
        borderRadius: BorderRadius.circular(14),
        border: Border(left: BorderSide(color: _teal, width: 4)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.07),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Nombre',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: Color(0xFF1a1a1a),
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              _detalle(Icons.badge, prestamo.cedula, 'Cédula'),
              const SizedBox(width: 16),
              _detalle(Icons.radio, prestamo.radio, 'Radio'),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              _detalle(Icons.calendar_today, prestamo.fechaFormato, 'Fecha'),
              const SizedBox(width: 16),
              Expanded(
                child: Row(
                  children: [
                    Icon(Icons.info, size: 14, color: _teal),
                    const SizedBox(width: 5),
                    Expanded(
                      child: Text(
                        prestamo.estado,
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF333333),
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _detalle(IconData icon, String valor, String label) => Expanded(
    child: Row(
      children: [
        Icon(icon, size: 14, color: _teal),
        const SizedBox(width: 5),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: const TextStyle(fontSize: 10, color: Colors.grey),
              ),
              Text(
                valor,
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF333333),
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ],
    ),
  );
}
