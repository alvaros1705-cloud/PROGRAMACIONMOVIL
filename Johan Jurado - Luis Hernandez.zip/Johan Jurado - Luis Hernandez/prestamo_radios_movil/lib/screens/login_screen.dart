import 'package:flutter/material.dart';
//import 'home_screen.dart';
import 'prestamos_registro_screen.dart';
import '../services/api_service.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController usuarioCtrl = TextEditingController();
  final TextEditingController claveCtrl = TextEditingController();
  bool _claveVisible = false;
  bool _cargando = false;

  // Colores institucionales AppPol
  static const Color _teal = Color(0xFF1A7A8A);
  static const Color _tealDark = Color(0xFF145F6E);

  void iniciarSesion() async {
    setState(() => _cargando = true);
    try {
      final data = await ApiService.login(usuarioCtrl.text, claveCtrl.text);
      if (!mounted) return;
      if (data != null) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => PrestamosRegistroScreen(
              nombreUsuario: data['usuario'] ?? usuarioCtrl.text,
              cargoUsuario: data['tecnico'] ?? 'Técnico OFTIC',
              tabInicial: 1,
            ),
          ),
        );
      } else {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text("Credenciales inválidas")));
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text("Error de conexión: $e")));
    } finally {
      if (mounted) setState(() => _cargando = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          // ── ENCABEZADO TEAL ──────────────────────────────────────
          const _Encabezado(teal: _teal, tealDark: _tealDark),

          // ── CUERPO CON FONDO ────────────────────────────────────
          Expanded(
            child: Stack(
              children: [
                // Fondo semitransparente (imagen de policía)
                Positioned.fill(
                  child: Image.asset(
                    'assets/images/fondo_policia.png',
                    fit: BoxFit.cover,
                    color: Colors.white.withValues(alpha: 0.18),
                    colorBlendMode: BlendMode.modulate,
                    errorBuilder: (_, __, ___) =>
                        Container(color: const Color(0xFFEEEEEE)),
                  ),
                ),

                // Contenido central
                SingleChildScrollView(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 20),

                        // Logo AppPol inferior
                        Center(
                          child: Image.asset(
                            'assets/images/logo_SINAR1.png',
                            height: 150,
                            width: 150,
                            fit: BoxFit.contain,
                            errorBuilder: (_, __, ___) =>
                                const SizedBox(height: 150, width: 150),
                          ),
                        ),

                        const SizedBox(height: 16),

                        // Campo Usuario
                        _CampoLogin(
                          controller: usuarioCtrl,
                          icono: Icons.person,
                          label: 'Usuario:',
                          teal: _teal,
                        ),

                        const Divider(thickness: 1, color: Colors.grey),

                        // Campo Clave
                        _CampoLogin(
                          controller: claveCtrl,
                          icono: Icons.lock,
                          label: 'Clave:',
                          teal: _teal,
                          obscure: !_claveVisible,
                          sufijo: IconButton(
                            icon: Icon(
                              _claveVisible
                                  ? Icons.visibility
                                  : Icons.visibility_off,
                              color: Colors.grey,
                            ),
                            onPressed: () =>
                                setState(() => _claveVisible = !_claveVisible),
                          ),
                        ),

                        const SizedBox(height: 28),

                        // Botón INICIAR SESIÓN
                        SizedBox(
                          width: double.infinity,
                          height: 52,
                          child: ElevatedButton(
                            onPressed: _cargando ? null : iniciarSesion,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: _teal,
                              foregroundColor: Colors.white,
                              shape: const StadiumBorder(),
                              elevation: 4,
                            ),
                            child: _cargando
                                ? const SizedBox(
                                    height: 22,
                                    width: 22,
                                    child: CircularProgressIndicator(
                                      color: Colors.white,
                                      strokeWidth: 2.5,
                                    ),
                                  )
                                : const Text(
                                    'Iniciar Sesión',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 1.2,
                                      fontSize: 15,
                                    ),
                                  ),
                          ),
                        ),

                        const SizedBox(height: 32),

                        // Imagen CAI + Slogan
                        _SeccionInferior(),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ── WIDGETS AUXILIARES ────────────────────────────────────────────────────────

/// Encabezado institucional con logo y nombre
class _Encabezado extends StatelessWidget {
  final Color teal;
  final Color tealDark;
  const _Encabezado({required this.teal, required this.tealDark});

  @override
  Widget build(BuildContext context) {
    // Ocupa el área del status bar
    final topPadding = MediaQuery.of(context).padding.top;
    return Container(
      width: double.infinity,
      padding: EdgeInsets.only(top: topPadding + 10, bottom: 14),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [tealDark, teal],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Logo — reemplaza con Image.asset si tienes el escudo
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.15),
              shape: BoxShape.circle,
            ),
            child: ClipOval(
              child: Image.asset(
                'assets/images/escudo_policia.png',
                fit: BoxFit.contain,
                errorBuilder: (_, __, ___) =>
                    const Icon(Icons.shield, color: Colors.white, size: 28),
              ),
            ),
          ),
          const SizedBox(width: 12),
          const Text(
            'Policía Nacional de Colombia',
            style: TextStyle(
              color: Colors.white,
              fontSize: 17,
              fontWeight: FontWeight.w600,
              letterSpacing: 0.3,
            ),
          ),
        ],
      ),
    );
  }
}

/// Campo de texto estilo AppPol (sin borde de caja, con ícono de color teal)
class _CampoLogin extends StatelessWidget {
  final TextEditingController controller;
  final IconData icono;
  final String label;
  final Color teal;
  final bool obscure;
  final Widget? sufijo;

  const _CampoLogin({
    required this.controller,
    required this.icono,
    required this.label,
    required this.teal,
    this.obscure = false,
    this.sufijo,
  });

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      obscureText: obscure,
      style: const TextStyle(fontSize: 15),
      decoration: InputDecoration(
        prefixIcon: Icon(icono, color: teal, size: 22),
        labelText: label,
        labelStyle: TextStyle(
          color: teal,
          fontWeight: FontWeight.w600,
          fontSize: 16,
        ),
        suffixIcon: sufijo,
        border: InputBorder.none,
        enabledBorder: InputBorder.none,
        focusedBorder: InputBorder.none,
        contentPadding: const EdgeInsets.symmetric(vertical: 12, horizontal: 4),
      ),
    );
  }
}

/// Sección inferior: imagen CAI + slogan + logo AppPol
class _SeccionInferior extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Imagen Pantalla inicio
        Center(
          child: Image.asset(
            'assets/images/MonedaCara1.png',
            height: 220,
            width: 220,
            fit: BoxFit.contain,
            errorBuilder: (_, __, ___) =>
                const SizedBox(height: 220, width: 220),
          ),
        ),

        // Slogan
        RichText(
          textAlign: TextAlign.center,
          text: const TextSpan(
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            children: [
              TextSpan(
                text: 'Modelo ',
                style: TextStyle(color: Color(0xFF1A1A1A)),
              ),
              TextSpan(
                text: 'del ',
                style: TextStyle(
                  color: Color(0xFF1A1A1A),
                  fontStyle: FontStyle.italic,
                  fontWeight: FontWeight.normal,
                ),
              ),
              TextSpan(
                text: 'Servicio ',
                style: TextStyle(color: Color(0xFFCC0000)),
              ),
              TextSpan(
                text: 'de ',
                style: TextStyle(
                  color: Color(0xFF1A1A1A),
                  fontStyle: FontStyle.italic,
                  fontWeight: FontWeight.normal,
                ),
              ),
              TextSpan(
                text: 'Policía',
                style: TextStyle(color: Color(0xFF1A7A8A)),
              ),
            ],
          ),
        ),
        const SizedBox(height: 4),
        const Text(
          'Orientado a las Personas',
          style: TextStyle(
            fontFamily: 'cursive',
            fontSize: 16,
            color: Color(0xFF1A1A1A),
            fontStyle: FontStyle.italic,
          ),
        ),

        const SizedBox(height: 20),
      ],
    );
  }
}
