import 'package:flutter/material.dart';
import 'prestamos_registro_screen.dart';
import 'devolucion_screen.dart';
import 'login_screen.dart';

import 'package:dio/dio.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';
import '../services/api_service.dart';

// ─── COLORES INSTITUCIONALES ───────────────────────────────────────────────
const Color _teal = Color(0xFF1A7A8A);
const Color _tealDark = Color(0xFF145F6E);
const Color _tealLight = Color(0xFFE0F4F7);
const Color _rojo = Color(0xFFCC0000);

class HomeScreen extends StatefulWidget {
  // Recibe los datos del usuario logueado desde LoginScreen
  final String nombreUsuario;
  final String cargoUsuario;
  final String? fotoPerfil; // ruta del asset o null

  const HomeScreen({
    super.key,
    this.nombreUsuario = 'Admin',
    this.cargoUsuario = 'Tecnico GUTIC',
    this.fotoPerfil,
  });

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  // ── Cerrar sesión ──────────────────────────────────────────────────────
  void _cerrarSesion() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Cerrar sesión'),
        content: const Text('¿Estás seguro de que deseas cerrar sesión?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: _rojo),
            onPressed: () {
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (_) => const LoginScreen()),
                (_) => false,
              );
            },
            child: const Text(
              'Cerrar sesión',
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  // ── Exportar reporte PDF de préstamos activos ──────────────────────────
  Future<void> _exportarReportes() async {
    // Cerrar drawer si está abierto
    if (_scaffoldKey.currentState?.isDrawerOpen ?? false) {
      Navigator.pop(context);
    }

    // Mostrar indicador de carga
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const AlertDialog(
        content: Row(
          children: [
            CircularProgressIndicator(color: _teal),
            SizedBox(width: 16),
            Text('Generando reporte PDF...'),
          ],
        ),
      ),
    );

    try {
      // Descargar PDF desde Flask
      final dir = await getTemporaryDirectory();
      final filePath = '${dir.path}/reporte_prestamos_activos.pdf';

      final dio = Dio();
      await dio.download(
        '${ApiService.baseUrl}/api/reporte/prestamos_activos',
        filePath,
        onReceiveProgress: (received, total) {
          // progreso opcional
        },
      );

      if (!mounted) return;
      Navigator.pop(context); // cerrar diálogo de carga

      // Abrir el PDF
      final result = await OpenFilex.open(filePath);
      if (result.type != ResultType.done) {
        _mostrarError(
          'No se pudo abrir el PDF. Revisa si tienes un lector instalado.',
        );
      }
    } catch (e) {
      if (!mounted) return;
      Navigator.pop(context); // cerrar diálogo de carga
      _mostrarError('Error al generar reporte: $e');
    }
  }

  void _mostrarError(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: _rojo,
        content: Row(
          children: [
            const Icon(Icons.error_outline, color: Colors.white),
            const SizedBox(width: 10),
            Expanded(child: Text(msg)),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      // ── DRAWER (menú hamburguesa izquierdo) ──────────────────────────
      drawer: _MenuLateral(
        nombre: widget.nombreUsuario,
        cargo: widget.cargoUsuario,
        foto: widget.fotoPerfil,
        onPrestamo: () => _navegar(
          PrestamosRegistroScreen(
            nombreUsuario: widget.nombreUsuario,
            cargoUsuario: widget.cargoUsuario,
            tabInicial: 0,
          ),
        ),
        onDevolucion: () => _navegar(const DevolucionScreen()),
        onExportar: _exportarReportes,
        onCerrar: _cerrarSesion,
      ),

      // ── APPBAR ───────────────────────────────────────────────────────
      appBar: _buildAppBar(context),

      // ── BODY ─────────────────────────────────────────────────────────
      body: Stack(
        children: [
          // Fondo con imagen
          Positioned.fill(
            child: Image.asset(
              'assets/images/MonedaCara1.png',
              fit: BoxFit.cover,
              color: Colors.white.withValues(alpha: 0.12),
              colorBlendMode: BlendMode.modulate,
              errorBuilder: (_, __, ___) =>
                  Container(color: const Color(0xFFEEEEEE)),
            ),
          ),

          // Contenido
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Saludo
                  _Saludo(nombre: widget.nombreUsuario),
                  const SizedBox(height: 28),

                  // Tarjetas de acceso rápido
                  const Text(
                    'Acceso rápido',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: Color(0xFF555555),
                      letterSpacing: 0.5,
                    ),
                  ),
                  const SizedBox(height: 14),

                  _TarjetaAccion(
                    icono: Icons.radio,
                    titulo: 'Nuevo préstamo',
                    subtitulo: 'Registrar préstamo de radio o equipo',
                    color: const Color.fromARGB(255, 252, 238, 83),
                    onTap: () => _navegar(
                      PrestamosRegistroScreen(
                        nombreUsuario: widget.nombreUsuario,
                        cargoUsuario: widget.cargoUsuario,
                        tabInicial: 0,
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),

                  _TarjetaAccion(
                    icono: Icons.assignment_return,
                    titulo: 'Registrar devolución',
                    subtitulo: 'Ingresar devolución de elemento tecnológico',
                    color: _tealDark,
                    onTap: () => _navegar(const DevolucionScreen()),
                  ),
                  const SizedBox(height: 14),

                  _TarjetaAccion(
                    icono: Icons.picture_as_pdf,
                    titulo: 'Exportar reportes',
                    subtitulo: 'Generar y descargar reportes en PDF',
                    color: _rojo,
                    onTap: _exportarReportes,
                  ),

                  const SizedBox(height: 32),

                  // Botón cerrar sesión
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      icon: const Icon(Icons.logout, color: _rojo),
                      label: const Text(
                        'Cerrar sesión',
                        style: TextStyle(
                          color: _rojo,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: _rojo),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      onPressed: _cerrarSesion,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── AppBar personalizado ───────────────────────────────────────────────
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return AppBar(
      backgroundColor: _teal,
      foregroundColor: Colors.white,
      elevation: 3,
      // Ícono hamburguesa (lo genera el Drawer automáticamente)
      // Logo + nombre app en el centro
      title: Row(
        children: [
          ClipOval(
            child: Image.asset(
              'assets/images/escudo_policia.png',
              height: 32,
              width: 32,
              fit: BoxFit.contain,
              errorBuilder: (_, __, ___) =>
                  const Icon(Icons.shield, color: Colors.white, size: 28),
            ),
          ),
          const SizedBox(width: 10),
          const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'SINAR',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              Text(
                'GUTIC MECUC',
                style: TextStyle(fontSize: 11, color: Colors.white70),
              ),
            ],
          ),
        ],
      ),
      // Usuario logueado en la derecha
      actions: [
        Padding(
          padding: const EdgeInsets.only(right: 12),
          child: Row(
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    widget.nombreUsuario,
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                  Text(
                    widget.cargoUsuario,
                    style: const TextStyle(fontSize: 10, color: Colors.white70),
                  ),
                ],
              ),
              const SizedBox(width: 8),
              // Avatar usuario
              CircleAvatar(
                radius: 18,
                backgroundColor: Colors.white24,
                backgroundImage: widget.fotoPerfil != null
                    ? AssetImage(widget.fotoPerfil!)
                    : null,
                child: widget.fotoPerfil == null
                    ? const Icon(Icons.person, color: Colors.white, size: 20)
                    : null,
              ),
            ],
          ),
        ),
      ],
    );
  }

  void _navegar(Widget screen) {
    // Solo cierra el drawer si está abierto
    if (_scaffoldKey.currentState?.isDrawerOpen ?? false) {
      _scaffoldKey.currentState!.closeDrawer();
    }
    Navigator.push(context, MaterialPageRoute(builder: (_) => screen));
  }
}

// ─── DRAWER LATERAL ────────────────────────────────────────────────────────
class _MenuLateral extends StatelessWidget {
  final String nombre;
  final String cargo;
  final String? foto;
  final VoidCallback onPrestamo;
  final VoidCallback onDevolucion;
  final VoidCallback onExportar;
  final VoidCallback onCerrar;

  const _MenuLateral({
    required this.nombre,
    required this.cargo,
    this.foto,
    required this.onPrestamo,
    required this.onDevolucion,
    required this.onExportar,
    required this.onCerrar,
  });

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Column(
        children: [
          // Cabecera del drawer
          UserAccountsDrawerHeader(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [_tealDark, _teal],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            accountName: Text(
              nombre,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
            ),
            accountEmail: Text(cargo),
            currentAccountPicture: CircleAvatar(
              backgroundColor: Colors.white24,
              backgroundImage: foto != null ? AssetImage(foto!) : null,
              child: foto == null
                  ? const Icon(Icons.person, color: Colors.white, size: 36)
                  : null,
            ),
            otherAccountsPictures: [
              ClipOval(
                child: Image.asset(
                  'assets/images/escudo_policia.png',
                  fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) =>
                      const Icon(Icons.shield, color: Colors.white),
                ),
              ),
            ],
          ),

          // Ítems del menú
          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                _ItemMenu(
                  icono: Icons.home,
                  titulo: 'Inicio',
                  onTap: () => Navigator.pop(context),
                ),
                const Divider(height: 1),
                _ItemMenu(
                  icono: Icons.radio,
                  titulo: 'Nuevo préstamo',
                  onTap: onPrestamo,
                ),
                _ItemMenu(
                  icono: Icons.assignment_return,
                  titulo: 'Registrar devolución',
                  onTap: onDevolucion,
                ),
                _ItemMenu(
                  icono: Icons.picture_as_pdf,
                  titulo: 'Exportar reportes',
                  onTap: onExportar,
                ),
                const Divider(height: 1),
                _ItemMenu(
                  icono: Icons.logout,
                  titulo: 'Cerrar sesión',
                  color: _rojo,
                  onTap: onCerrar,
                ),
              ],
            ),
          ),

          // Pie del drawer
          Container(
            padding: const EdgeInsets.all(12),
            color: _tealLight,
            child: const Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.info_outline, size: 14, color: _teal),
                SizedBox(width: 6),
                Text(
                  'SINAR v1.0.0 — GUTIC MECUC',
                  style: TextStyle(fontSize: 11, color: _teal),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─── ÍTEM DEL MENÚ LATERAL ─────────────────────────────────────────────────
class _ItemMenu extends StatelessWidget {
  final IconData icono;
  final String titulo;
  final VoidCallback onTap;
  final Color color;

  const _ItemMenu({
    required this.icono,
    required this.titulo,
    required this.onTap,
    this.color = _teal,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icono, color: color),
      title: Text(
        titulo,
        style: TextStyle(color: color, fontWeight: FontWeight.w500),
      ),
      onTap: onTap,
      horizontalTitleGap: 8,
    );
  }
}

// ─── SALUDO ────────────────────────────────────────────────────────────────
class _Saludo extends StatelessWidget {
  final String nombre;
  const _Saludo({required this.nombre});

  String _saludo() {
    final hora = DateTime.now().hour;
    if (hora < 12) return 'Buenos días';
    if (hora < 18) return 'Buenas tardes';
    return 'Buenas noches';
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '${_saludo()},',
          style: const TextStyle(fontSize: 14, color: Color(0xFF666666)),
        ),
        Text(
          nombre,
          style: const TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: _tealDark,
          ),
        ),
        const Text(
          'Policía Nacional de Colombia — OFTIC',
          style: TextStyle(fontSize: 12, color: Color(0xFF888888)),
        ),
      ],
    );
  }
}

// ─── TARJETA DE ACCIÓN ─────────────────────────────────────────────────────
class _TarjetaAccion extends StatelessWidget {
  final IconData icono;
  final String titulo;
  final String subtitulo;
  final Color color;
  final VoidCallback onTap;

  const _TarjetaAccion({
    required this.icono,
    required this.titulo,
    required this.subtitulo,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white.withValues(alpha: 0.92),
      borderRadius: BorderRadius.circular(14),
      elevation: 3,
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icono, color: color, size: 26),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      titulo,
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: color,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      subtitulo,
                      style: const TextStyle(
                        fontSize: 12,
                        color: Color(0xFF777777),
                      ),
                    ),
                  ],
                ),
              ),
              Icon(Icons.chevron_right, color: color),
            ],
          ),
        ),
      ),
    );
  }
}
