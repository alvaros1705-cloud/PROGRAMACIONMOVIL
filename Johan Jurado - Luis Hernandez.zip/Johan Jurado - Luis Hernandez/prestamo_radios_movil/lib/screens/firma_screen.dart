import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import '../widgets/firma_pad.dart';
import '../services/api_service.dart';

// ─── COLORES INSTITUCIONALES ───────────────────────────────────────────────
const Color _teal     = Color(0xFF1A7A8A);
const Color _tealDark = Color(0xFF145F6E);
const Color _tealLight= Color(0xFFE0F4F7);
const Color _rojo     = Color(0xFFCC0000);

class FirmaScreen extends StatefulWidget {
  final Map<String, dynamic> datosPrestamo;
  const FirmaScreen({super.key, required this.datosPrestamo});

  @override
  State<FirmaScreen> createState() => _FirmaScreenState();
}

class _FirmaScreenState extends State<FirmaScreen> {
  bool _guardando = false;

  @override
  Widget build(BuildContext context) {
    final d = widget.datosPrestamo;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: _teal,
        foregroundColor: Colors.white,
        elevation: 3,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Flexible(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('Firma del Funcionario',
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                  overflow: TextOverflow.ellipsis),
              Text('OFTIC — Policía Nacional',
                  style: TextStyle(fontSize: 10, color: Colors.white70),
                  overflow: TextOverflow.ellipsis),
            ],
          ),
        ),
      ),

      body: Stack(
        children: [
          // Fondo
          Positioned.fill(
            child: Image.asset(
              'assets/images/MonedaCara1.png',
              fit: BoxFit.cover,
              color: Colors.white.withOpacity(0.06),       // ✅ withOpacity
              colorBlendMode: BlendMode.modulate,
              errorBuilder: (_, __, ___) =>
                  Container(color: const Color(0xFFEEEEEE)),
            ),
          ),

          SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [

                // ── Resumen del préstamo ─────────────────────────────
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: _tealLight,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: _teal.withOpacity(0.3)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Row(
                        children: [
                          Icon(Icons.info_outline, size: 15, color: _teal),
                          SizedBox(width: 6),
                          Text('Resumen del préstamo',
                              style: TextStyle(fontSize: 12,
                                  fontWeight: FontWeight.bold, color: _teal)),
                        ],
                      ),
                      const SizedBox(height: 10),
                      _filaDetalle('Funcionario', d['apellidos_nombres'] ?? '—'),
                      _filaDetalle('Cédula',      d['cedula']            ?? '—'),
                      _filaDetalle('Grado',       d['grado']             ?? '—'),
                      _filaDetalle('Cargo',       d['cargo']             ?? '—'),
                      _filaDetalle('Unidad',      d['unidad']            ?? '—'),
                      _filaDetalle('Radio ID',    d['radio_id']?.toString() ?? '—'),
                      _filaDetalle('Técnico',     d['tecnico_nombre']    ?? '—'),
                      if ((d['observaciones'] ?? '').toString().isNotEmpty)
                        _filaDetalle('Observaciones', d['observaciones']),
                    ],
                  ),
                ),

                const SizedBox(height: 20),

                // ── Sección firma ────────────────────────────────────
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.95),
                    borderRadius: BorderRadius.circular(14),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.08),
                        blurRadius: 8, offset: const Offset(0, 3),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Row(
                        children: [
                          Icon(Icons.draw, size: 16, color: _teal),
                          SizedBox(width: 8),
                          Text('Firma del funcionario',
                              style: TextStyle(fontSize: 13,
                                  fontWeight: FontWeight.w600, color: _tealDark)),
                        ],
                      ),
                      const SizedBox(height: 12),
                      FirmaPad(
                        onSave: (firmaBytes) {
                          if (!_guardando) _guardarFirma(context, firmaBytes);
                        },
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 24),
              ],
            ),
          ),

          // Overlay cargando
          if (_guardando)
            Container(
              color: Colors.black.withOpacity(0.35),       // ✅ withOpacity
              child: const Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CircularProgressIndicator(color: Colors.white),
                    SizedBox(height: 16),
                    Text('Guardando préstamo...',
                        style: TextStyle(color: Colors.white,
                            fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _filaDetalle(String label, String valor) => Padding(
    padding: const EdgeInsets.only(bottom: 4),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('$label: ', style: const TextStyle(
            fontSize: 12, fontWeight: FontWeight.w600, color: _tealDark)),
        Expanded(
          child: Text(valor, style: const TextStyle(
              fontSize: 12, color: Color(0xFF444444))),
        ),
      ],
    ),
  );

  Future<void> _guardarFirma(BuildContext context, ByteData? firmaBytes) async {
    if (firmaBytes == null) {
      _mostrarError('No se capturó la firma.');
      return;
    }

    setState(() => _guardando = true);

    try {
      final png          = firmaBytes.buffer.asUint8List(0, firmaBytes.lengthInBytes);
      final firmaBase64  = base64Encode(png);

      // ✅ datosPrestamo ya contiene cedula, apellidos_nombres, etc.
      await ApiService.registrarPrestamo(widget.datosPrestamo, firmaBase64);

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Row(
            children: [
              Icon(Icons.check_circle, color: Colors.white),
              SizedBox(width: 10),
              Text('✅ Préstamo registrado y PDF generado'),
            ],
          ),
          backgroundColor: _teal,
          duration: Duration(seconds: 3),
        ),
      );

      if (!mounted) return;
      // Regresar a pantalla anterior después de éxito
      Future.delayed(const Duration(milliseconds: 600), () {
        if (mounted) Navigator.pop(context);
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _guardando = false);
      _mostrarError('Error al registrar: $e');
    }
  }

  void _mostrarError(String mensaje) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(mensaje),
        backgroundColor: _rojo,
        duration: const Duration(seconds: 5),
      ),
    );
  }
}
