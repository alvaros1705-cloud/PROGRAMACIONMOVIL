import 'package:flutter/material.dart';
import '../models/funcionario.dart';
import '../models/tecnico.dart';
import '../models/radio.dart' as radio_model;
import '../services/api_service.dart';
import 'devolucion_screen.dart';
import 'firma_screen.dart';
import 'login_screen.dart';
import 'reportes_screen.dart';

// ─── COLORES INSTITUCIONALES ───────────────────────────────────────────────
const Color _teal = Color(0xFF1A7A8A);
const Color _tealDark = Color(0xFF145F6E);
const Color _tealLight = Color(0xFFE0F4F7);
const Color _rojo = Color(0xFFCC0000);
const Color _verde = Color(0xFF1A6E3A);
const Color _amber = Color(0xFFF59E0B);

// ─── MODELO ───────────────────────────────────────────────────────────────
class PrestamoItem {
  final int id;
  final String funcionario;
  final String cedula;
  final String celular;
  final String radio;
  final String modelo;
  final String fecha;
  final String estado;
  final int dias;

  PrestamoItem({
    required this.id,
    required this.funcionario,
    required this.cedula,
    required this.celular,
    required this.radio,
    required this.modelo,
    required this.fecha,
    required this.estado,
    required this.dias,
  });

  // Método para convertir fecha UTC a zona de Bogotá (UTC-5)
  String get fechaFormato {
    try {
      DateTime? dt = DateTime.tryParse(fecha);
      if (dt == null) return fecha;

      // Convertir a zona de Bogotá (UTC-5)
      final bogotaTime = dt.subtract(const Duration(hours: 5));

      return "${bogotaTime.year.toString().padLeft(4, '0')}-"
          "${bogotaTime.month.toString().padLeft(2, '0')}-"
          "${bogotaTime.day.toString().padLeft(2, '0')} "
          "${bogotaTime.hour.toString().padLeft(2, '0')}:"
          "${bogotaTime.minute.toString().padLeft(2, '0')}";
    } catch (e) {
      return fecha;
    }
  }

  factory PrestamoItem.fromJson(Map<String, dynamic> j) => PrestamoItem(
    id: j['id'],
    funcionario: j['funcionario'] ?? '',
    cedula: j['cedula'] ?? '',
    celular: j['celular'] ?? '',
    radio: j['radio'] ?? '',
    modelo: j['modelo'] ?? '',
    fecha: j['fecha'] ?? '',
    estado: j['estado'] ?? 'activo',
    dias: j['dias'] ?? 0,
  );
}

// ─── PANTALLA PRINCIPAL ────────────────────────────────────────────────────
class PrestamosRegistroScreen extends StatefulWidget {
  final String nombreUsuario;
  final String cargoUsuario;
  final int tabInicial;

  const PrestamosRegistroScreen({
    super.key,
    required this.nombreUsuario,
    required this.cargoUsuario,
    this.tabInicial = 0,
  });

  @override
  State<PrestamosRegistroScreen> createState() =>
      _PrestamosRegistroScreenState();
}

class _PrestamosRegistroScreenState extends State<PrestamosRegistroScreen>
    with TickerProviderStateMixin {
  late TabController _tabController;
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  // ─── VARIABLES TAB 2: Listado ────────────────────────────────────────────
  List<PrestamoItem> _todos = [];
  List<PrestamoItem> _pagina = [];
  bool _cargandoLista = true;
  int _paginaActual = 1;
  int _totalPaginas = 1;
  bool _soloActivos = true;
  static const int _porPagina = 10;
  final TextEditingController _buscarCtrl = TextEditingController();
  String _busqueda = '';

  // ─── VARIABLES TAB 1: Formulario ─────────────────────────────────────────
  final TextEditingController _cedulaCtrl = TextEditingController();
  final TextEditingController _nombresCtrl = TextEditingController();
  final TextEditingController _celularCtrl = TextEditingController();
  final TextEditingController _gradoCtrl = TextEditingController();
  final TextEditingController _unidadCtrl = TextEditingController();
  final TextEditingController _cargoCtrl = TextEditingController();
  final TextEditingController _obsCtrl = TextEditingController();

  List<Tecnico> _tecnicos = [];
  List<radio_model.Radio> _radios = [];
  Funcionario? _funcionarioSeleccionado;
  Tecnico? _tecnicoSeleccionado;
  radio_model.Radio? _radioSeleccionado;
  bool _cargandoForm = true;
  bool _ingresarManualmente = false;

  /// Cuando es true los campos del funcionario están desbloqueados para editar
  bool _modoEdicion = false;
  bool _guardandoEdicion = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(
      length: 2,
      vsync: this,
      initialIndex: widget.tabInicial,
    );
    _cargarDatosFormulario();
    _cargarDatosLista();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _cedulaCtrl.dispose();
    _nombresCtrl.dispose();
    _celularCtrl.dispose();
    _gradoCtrl.dispose();
    _unidadCtrl.dispose();
    _cargoCtrl.dispose();
    _obsCtrl.dispose();
    _buscarCtrl.dispose();
    super.dispose();
  }

  // ═════════════════════════════════════════════════════════════════════════
  // MÉTODOS TAB 1: FORMULARIO
  // ═════════════════════════════════════════════════════════════════════════

  Future<void> _cargarDatosFormulario() async {
    try {
      final tecs = await ApiService.obtenerTecnicos();
      final rads = await ApiService.obtenerRadios();
      if (!mounted) return;
      setState(() {
        _tecnicos = tecs;
        _radios = rads;
        _cargandoForm = false;
      });
    } catch (e) {
      if (!mounted) return;
      _toast('Error al cargar datos: $e');
    }
  }

  Future<void> _buscar() async {
    if (_cedulaCtrl.text.isEmpty) {
      _toast('Ingresa una cédula');
      return;
    }
    try {
      final func = await ApiService.buscarFuncionario(_cedulaCtrl.text);
      if (!mounted) return;
      if (func == null) {
        _toast(
          'Funcionario no encontrado. Puedes ingresar los datos manualmente.',
        );
        setState(() {
          _funcionarioSeleccionado = null;
          _ingresarManualmente = true;
          _modoEdicion = false;
          _nombresCtrl.clear();
          _celularCtrl.clear();
          _gradoCtrl.clear();
          _unidadCtrl.clear();
          _cargoCtrl.clear();
        });
        return;
      }
      setState(() {
        _funcionarioSeleccionado = func;
        _ingresarManualmente = false;
        _modoEdicion = false;
        _nombresCtrl.text = func.nombres;
        _celularCtrl.text = func.celular;
        _gradoCtrl.text = func.grado;
        _unidadCtrl.text = func.unidad;
        _cargoCtrl.text = func.cargo;
      });
    } catch (e) {
      if (!mounted) return;
      _toast('Error: $e');
      setState(() => _funcionarioSeleccionado = null);
    }
  }

  /// Limpia por completo el campo de cédula y los datos del funcionario
  void _limpiarCedula() {
    setState(() {
      _cedulaCtrl.clear();
      _nombresCtrl.clear();
      _celularCtrl.clear();
      _gradoCtrl.clear();
      _unidadCtrl.clear();
      _cargoCtrl.clear();
      _funcionarioSeleccionado = null;
      _ingresarManualmente = false;
      _modoEdicion = false;
    });
  }

  /// Activa / desactiva el modo edición de los campos del funcionario
  void _toggleModoEdicion() {
    setState(() => _modoEdicion = !_modoEdicion);
  }

  /// Guarda los cambios del funcionario en el servidor
  Future<void> _guardarEdicion() async {
    if (_cedulaCtrl.text.isEmpty) return;
    setState(() => _guardandoEdicion = true);
    try {
      await ApiService.actualizarFuncionario(_cedulaCtrl.text.trim(), {
        'grado': _gradoCtrl.text.trim(),
        'apellidos_nombres': _nombresCtrl.text.trim(),
        'celular': _celularCtrl.text.trim(),
        'unidad': _unidadCtrl.text.trim(),
        'cargo': _cargoCtrl.text.trim(),
      });
      if (!mounted) return;
      setState(() {
        _modoEdicion = false;
        _guardandoEdicion = false;
      });
      _toast('✅ Datos actualizados correctamente', exito: true);
    } catch (e) {
      if (!mounted) return;
      setState(() => _guardandoEdicion = false);
      _toast('Error al actualizar: $e');
    }
  }

  void _mostrarFormularioFirma() {
    if (_funcionarioSeleccionado == null && !_ingresarManualmente) {
      _toast('⚠️ Busca o ingresa datos del funcionario');
      return;
    }

    if (_ingresarManualmente) {
      if (_cedulaCtrl.text.isEmpty ||
          _nombresCtrl.text.isEmpty ||
          _gradoCtrl.text.isEmpty ||
          _unidadCtrl.text.isEmpty ||
          _cargoCtrl.text.isEmpty) {
        _toast('⚠️ Completa todos los datos del funcionario');
        return;
      }
    }

    if (_tecnicoSeleccionado == null || _radioSeleccionado == null) {
      _toast('⚠️ Selecciona un técnico y una radio');
      return;
    }

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Confirmar Préstamo'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Datos del préstamo:'),
            const SizedBox(height: 12),
            _buildConfirmRow('Funcionario:', _nombresCtrl.text),
            _buildConfirmRow('Técnico:', _tecnicoSeleccionado!.nombre),
            _buildConfirmRow('Radio:', _radioSeleccionado!.serial),
            _buildConfirmRow('Modelo:', _radioSeleccionado!.modelo),
            if (_ingresarManualmente)
              _buildConfirmRow('Ingreso:', 'Manual (nuevo funcionario)'),
            if (_obsCtrl.text.isNotEmpty)
              _buildConfirmRow('Observaciones:', _obsCtrl.text),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(ctx);
              _irAFirmaScreen();
            },
            child: const Text('Continuar'),
          ),
        ],
      ),
    );
  }

  Widget _buildConfirmRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('$label ', style: const TextStyle(fontWeight: FontWeight.bold)),
          Expanded(child: Text(value, overflow: TextOverflow.ellipsis)),
        ],
      ),
    );
  }

  void _irAFirmaScreen() {
    final datosPrestamo = {
      'cedula': _cedulaCtrl.text.trim(),
      'grado': _gradoCtrl.text.trim(),
      'apellidos_nombres': _nombresCtrl.text.trim(),
      'celular': _celularCtrl.text.trim(),
      'unidad': _unidadCtrl.text.trim(),
      'cargo': _cargoCtrl.text.trim(),
      'tecnico_id': _tecnicoSeleccionado!.id,
      'tecnico_nombre': _tecnicoSeleccionado!.nombre,
      'radio_id': _radioSeleccionado!.id,
      'observaciones': _obsCtrl.text.trim(),
    };

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => FirmaScreen(datosPrestamo: datosPrestamo),
      ),
    ).then((_) {
      _limpiarFormulario();
      _cargarDatosLista();
    });
  }

  void _limpiarFormulario() {
    _cedulaCtrl.clear();
    _nombresCtrl.clear();
    _celularCtrl.clear();
    _gradoCtrl.clear();
    _unidadCtrl.clear();
    _cargoCtrl.clear();
    _obsCtrl.clear();
    setState(() {
      _funcionarioSeleccionado = null;
      _ingresarManualmente = false;
      _modoEdicion = false;
      _tecnicoSeleccionado = null;
      _radioSeleccionado = null;
    });
  }

  // ═════════════════════════════════════════════════════════════════════════
  // MÉTODOS TAB 2: LISTADO
  // ═════════════════════════════════════════════════════════════════════════

  Future<void> _cargarDatosLista() async {
    setState(() => _cargandoLista = true);
    try {
      final lista = await ApiService.obtenerPrestamosActivosMap();
      if (!mounted) return;
      final items = lista.map((e) => PrestamoItem.fromJson(e)).toList();
      setState(() {
        _todos = items;
        _cargandoLista = false;
        _paginaActual = 1;
        _actualizar();
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _cargandoLista = false);
      _toast('Error al cargar: $e');
    }
  }

  void _actualizar() {
    List<PrestamoItem> filtrados = _todos;
    if (_soloActivos) {
      filtrados = filtrados.where((p) => p.estado != 'devuelto').toList();
    }
    if (_busqueda.isNotEmpty) {
      final q = _busqueda.toLowerCase();
      filtrados = filtrados
          .where(
            (p) =>
                p.funcionario.toLowerCase().contains(q) ||
                p.cedula.contains(q) ||
                p.radio.toLowerCase().contains(q),
          )
          .toList();
    }
    _totalPaginas = ((filtrados.length) / _porPagina).ceil().clamp(1, 9999);
    _paginaActual = _paginaActual.clamp(1, _totalPaginas);
    final inicio = (_paginaActual - 1) * _porPagina;
    final fin = (inicio + _porPagina).clamp(0, filtrados.length);
    _pagina = filtrados.sublist(inicio, fin);
    setState(() {});
  }

  void _irPagina(int p) {
    setState(() {
      _paginaActual = p;
      _actualizar();
    });
  }

  void _cerrarSesion() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Cerrar sesión'),
        content: const Text('¿Estás seguro?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: _rojo),
            onPressed: () => Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (_) => const LoginScreen()),
              (_) => false,
            ),
            child: const Text('Salir', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  void _toast(String msg, {bool exito = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(backgroundColor: exito ? _teal : _rojo, content: Text(msg)),
    );
  }

  // ═════════════════════════════════════════════════════════════════════════
  // UI
  // ═════════════════════════════════════════════════════════════════════════

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        backgroundColor: _teal,
        foregroundColor: Colors.white,
        elevation: 3,
        leading: IconButton(
          icon: const Icon(Icons.menu),
          onPressed: () => _scaffoldKey.currentState?.openDrawer(),
        ),
        title: Row(
          children: [
            ClipOval(
              child: Image.asset(
                'assets/images/escudo_policia.png',
                height: 24,
                width: 24,
                fit: BoxFit.contain,
                errorBuilder: (_, __, ___) =>
                    const Icon(Icons.shield, color: Colors.white, size: 24),
              ),
            ),
            const SizedBox(width: 8),
            const Flexible(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'SINAR',
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                  ),
                  Text(
                    'GUTIC MECUC',
                    style: TextStyle(fontSize: 9, color: Colors.white70),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: Row(
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      widget.nombreUsuario,
                      style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Text(
                      widget.cargoUsuario,
                      style: const TextStyle(
                        fontSize: 10,
                        color: Colors.white70,
                      ),
                    ),
                  ],
                ),
                const SizedBox(width: 8),
                const CircleAvatar(
                  radius: 16,
                  backgroundColor: Colors.white24,
                  child: Icon(Icons.person, color: Colors.white, size: 18),
                ),
              ],
            ),
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white70,
          indicatorColor: const Color.fromARGB(255, 221, 159, 13),
          tabs: const [
            Tab(icon: Icon(Icons.add), text: 'Nuevo Préstamo'),
            Tab(icon: Icon(Icons.list), text: 'Mis Préstamos'),
          ],
        ),
      ),
      drawer: _buildDrawer(),
      body: Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              'assets/images/MonedaCara1.png',
              fit: BoxFit.cover,
              color: Colors.white.withValues(alpha: 0.06),
              colorBlendMode: BlendMode.modulate,
              errorBuilder: (_, __, ___) =>
                  Container(color: const Color(0xFFEEEEEE)),
            ),
          ),
          TabBarView(
            controller: _tabController,
            children: [_buildTabFormulario(), _buildTabListado()],
          ),
        ],
      ),
    );
  }

  // ─── TAB 1: FORMULARIO ─────────────────────────────────────────────────
  Widget _buildTabFormulario() {
    if (_cargandoForm) {
      return const Center(child: CircularProgressIndicator(color: _teal));
    }

    // Determina si los campos están en modo solo lectura
    // (funcionario encontrado y NO en modo edición)
    final bool camposBloqueados =
        _funcionarioSeleccionado != null && !_modoEdicion;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const _SeccionTitulo(
            icono: Icons.radio,
            titulo: 'Registrar Préstamo',
            subtitulo: 'Completa los datos del funcionario y equipo',
          ),
          const SizedBox(height: 20),
          const _EncabezadoSeccion(
            numero: '1',
            titulo: 'Datos del Funcionario',
          ),
          const SizedBox(height: 10),

          // ── Tarjeta búsqueda + datos funcionario ──────────────────
          _Tarjeta(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ── Fila cédula con botones Buscar y Limpiar ────────
                Row(
                  children: [
                    Expanded(
                      child: _CampoTexto(
                        ctrl: _cedulaCtrl,
                        label: 'Cédula',
                        icono: Icons.badge,
                        tipo: TextInputType.number,
                      ),
                    ),
                    const SizedBox(width: 8),
                    // Botón buscar
                    SizedBox(
                      height: 52,
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _teal,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          padding: const EdgeInsets.symmetric(horizontal: 12),
                        ),
                        icon: const Icon(Icons.search, size: 18),
                        label: const Text(
                          'Buscar',
                          style: TextStyle(fontSize: 12),
                        ),
                        onPressed: _buscar,
                      ),
                    ),
                    const SizedBox(width: 6),
                    // Botón limpiar cédula
                    SizedBox(
                      height: 52,
                      width: 48,
                      child: OutlinedButton(
                        style: OutlinedButton.styleFrom(
                          foregroundColor: _rojo,
                          side: const BorderSide(color: _rojo),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          padding: EdgeInsets.zero,
                        ),
                        onPressed: _limpiarCedula,
                        child: const Icon(Icons.backspace_outlined, size: 18),
                      ),
                    ),
                  ],
                ),

                // ── Campos del funcionario ───────────────────────────
                if (_funcionarioSeleccionado != null ||
                    _ingresarManualmente) ...[
                  const SizedBox(height: 12),

                  // Banner edición / solo lectura
                  if (_funcionarioSeleccionado != null)
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 7,
                      ),
                      decoration: BoxDecoration(
                        color: _modoEdicion
                            ? _amber.withValues(alpha: 0.15)
                            : _tealLight,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: _modoEdicion ? _amber : _teal,
                          width: 1,
                        ),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            _modoEdicion ? Icons.edit : Icons.lock_outline,
                            size: 14,
                            color: _modoEdicion ? _amber : _teal,
                          ),
                          const SizedBox(width: 6),
                          Expanded(
                            child: Text(
                              _modoEdicion
                                  ? 'Modo edición activo — modifica los datos y guarda'
                                  : 'Datos encontrados — toca ✏️ para editar',
                              style: TextStyle(
                                fontSize: 11,
                                color: _modoEdicion ? _amber : _tealDark,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          const SizedBox(width: 6),
                          // Botón editar / cancelar edición
                          GestureDetector(
                            onTap: _toggleModoEdicion,
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 4,
                              ),
                              decoration: BoxDecoration(
                                color: _modoEdicion ? _rojo : _teal,
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Text(
                                _modoEdicion ? 'Cancelar' : '✏️ Editar',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 11,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                  const SizedBox(height: 10),

                  _CampoTexto(
                    ctrl: _nombresCtrl,
                    label: 'Nombres',
                    icono: Icons.person,
                    readonly: camposBloqueados,
                  ),
                  const SizedBox(height: 10),
                  _CampoTexto(
                    ctrl: _gradoCtrl,
                    label: 'Grado',
                    icono: Icons.badge,
                    readonly: camposBloqueados,
                  ),
                  const SizedBox(height: 10),
                  _CampoTexto(
                    ctrl: _unidadCtrl,
                    label: 'Unidad',
                    icono: Icons.location_city,
                    readonly: camposBloqueados,
                  ),
                  const SizedBox(height: 10),
                  _CampoTexto(
                    ctrl: _cargoCtrl,
                    label: 'Cargo',
                    icono: Icons.work,
                    readonly: camposBloqueados,
                  ),
                  const SizedBox(height: 10),
                  _CampoTexto(
                    ctrl: _celularCtrl,
                    label: 'Celular',
                    icono: Icons.phone,
                    readonly: camposBloqueados,
                    tipo: TextInputType.phone,
                  ),

                  // Aviso ingreso manual
                  if (_ingresarManualmente)
                    Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Text(
                        'ℹ️ Modo ingreso manual: completa los datos del funcionario',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.orange[700],
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                    ),

                  // Botón guardar edición
                  if (_modoEdicion) ...[
                    const SizedBox(height: 14),
                    SizedBox(
                      width: double.infinity,
                      height: 44,
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _verde,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                        icon: _guardandoEdicion
                            ? const SizedBox(
                                height: 18,
                                width: 18,
                                child: CircularProgressIndicator(
                                  color: Colors.white,
                                  strokeWidth: 2,
                                ),
                              )
                            : const Icon(Icons.save, size: 18),
                        label: Text(
                          _guardandoEdicion
                              ? 'Guardando...'
                              : 'Guardar cambios',
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        onPressed: _guardandoEdicion ? null : _guardarEdicion,
                      ),
                    ),
                  ],
                ],
              ],
            ),
          ),

          const SizedBox(height: 16),
          const _EncabezadoSeccion(numero: '2', titulo: 'Equipo a Prestar'),
          const SizedBox(height: 10),
          _Tarjeta(
            child: Column(
              children: [
                DropdownButtonFormField<Tecnico>(
                  value: _tecnicoSeleccionado,
                  hint: const Text('Selecciona un técnico'),
                  isExpanded: true,
                  items: _tecnicos
                      .map(
                        (t) =>
                            DropdownMenuItem(value: t, child: Text(t.nombre)),
                      )
                      .toList(),
                  onChanged: (v) => setState(() => _tecnicoSeleccionado = v),
                  decoration: _inputDeco('Técnico', Icons.engineering),
                ),
                const SizedBox(height: 10),
                DropdownButtonFormField<radio_model.Radio>(
                  value: _radioSeleccionado,
                  hint: const Text('Selecciona un radio'),
                  isExpanded: true,
                  items: _radios
                      .map(
                        (r) =>
                            DropdownMenuItem(value: r, child: Text(r.serial)),
                      )
                      .toList(),
                  onChanged: (v) => setState(() => _radioSeleccionado = v),
                  decoration: _inputDeco('Radio', Icons.radio),
                ),
              ],
            ),
          ),

          const SizedBox(height: 16),
          const _EncabezadoSeccion(numero: '3', titulo: 'Observaciones'),
          const SizedBox(height: 10),
          _Tarjeta(
            child: _CampoTexto(
              ctrl: _obsCtrl,
              label: 'Observaciones',
              icono: Icons.note,
              maxLineas: 3,
            ),
          ),

          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            height: 48,
            child: ElevatedButton.icon(
              icon: const Icon(Icons.check),
              label: const Text('Registrar y Firmar'),
              onPressed: _mostrarFormularioFirma,
            ),
          ),
          const SizedBox(height: 30),
        ],
      ),
    );
  }

  // ─── TAB 2: LISTADO ────────────────────────────────────────────────────
  Widget _buildTabListado() {
    if (_cargandoLista) {
      return const Center(child: CircularProgressIndicator(color: _teal));
    }
    return Column(
      children: [
        Container(
          color: Colors.white.withValues(alpha: 0.95),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          child: Column(
            children: [
              TextField(
                controller: _buscarCtrl,
                onChanged: (v) => setState(() {
                  _busqueda = v;
                  _paginaActual = 1;
                  _actualizar();
                }),
                decoration: InputDecoration(
                  hintText: 'Buscar por nombre, cédula, serial...',
                  prefixIcon: const Icon(Icons.search, color: _teal),
                  suffixIcon: _busqueda.isNotEmpty
                      ? IconButton(
                          icon: const Icon(Icons.clear, color: _teal),
                          onPressed: () => setState(() {
                            _buscarCtrl.clear();
                            _busqueda = '';
                            _actualizar();
                          }),
                        )
                      : null,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  _btnFiltro('Solo activos', _soloActivos, () {
                    setState(() {
                      _soloActivos = true;
                      _paginaActual = 1;
                      _actualizar();
                    });
                  }),
                  const SizedBox(width: 8),
                  _btnFiltro('Todos', !_soloActivos, () {
                    setState(() {
                      _soloActivos = false;
                      _paginaActual = 1;
                      _actualizar();
                    });
                  }),
                  const Spacer(),
                  IconButton(
                    icon: const Icon(Icons.refresh, color: _teal, size: 20),
                    onPressed: _cargarDatosLista,
                  ),
                ],
              ),
            ],
          ),
        ),
        Expanded(
          child: _pagina.isEmpty
              ? Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.radio, size: 48, color: Colors.grey.shade300),
                      const SizedBox(height: 12),
                      Text(
                        'No hay préstamos',
                        style: TextStyle(color: Colors.grey.shade400),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(12, 12, 12, 80),
                  itemCount: _pagina.length,
                  itemBuilder: (_, i) => _TarjetaPrestamo(
                    item: _pagina[i],
                    onRecibir: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) =>
                            DevolucionScreen(prestamoIdInicial: _pagina[i].id),
                      ),
                    ).then((_) => _cargarDatosLista()),
                  ),
                ),
        ),
        if (_totalPaginas > 1) _buildPaginacion(),
      ],
    );
  }

  // ─── PAGINACIÓN ────────────────────────────────────────────────────────
  Widget _buildPaginacion() {
    return Container(
      color: Colors.white.withValues(alpha: 0.95),
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          _btnPag('‹', _paginaActual > 1, () => _irPagina(_paginaActual - 1)),
          const SizedBox(width: 8),
          ...List.generate(_totalPaginas, (i) {
            final p = i + 1;
            final activa = p == _paginaActual;
            return GestureDetector(
              onTap: () => _irPagina(p),
              child: Container(
                width: 32,
                height: 32,
                margin: const EdgeInsets.symmetric(horizontal: 3),
                decoration: BoxDecoration(
                  color: activa ? _teal : Colors.white,
                  border: Border.all(
                    color: activa ? _teal : Colors.grey.shade300,
                  ),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Center(
                  child: Text(
                    '$p',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: activa ? Colors.white : Colors.grey.shade600,
                    ),
                  ),
                ),
              ),
            );
          }),
          const SizedBox(width: 8),
          _btnPag(
            '›',
            _paginaActual < _totalPaginas,
            () => _irPagina(_paginaActual + 1),
          ),
        ],
      ),
    );
  }

  Widget _btnPag(String label, bool habilitado, VoidCallback onTap) =>
      GestureDetector(
        onTap: habilitado ? onTap : null,
        child: Container(
          width: 32,
          height: 32,
          decoration: BoxDecoration(
            color: habilitado ? Colors.white : Colors.grey.shade100,
            border: Border.all(color: Colors.grey.shade300),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Center(
            child: Text(
              label,
              style: TextStyle(
                fontSize: 16,
                color: habilitado ? _teal : Colors.grey.shade400,
              ),
            ),
          ),
        ),
      );

  Widget _btnFiltro(String label, bool activo, VoidCallback onTap) =>
      GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: activo ? _teal : Colors.white,
            border: Border.all(color: _teal),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(
            label,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: activo ? Colors.white : _teal,
            ),
          ),
        ),
      );

  // ─── DRAWER ─────────────────────────────────────────────────────────────
  Widget _buildDrawer() => Drawer(
    child: Column(
      children: [
        UserAccountsDrawerHeader(
          decoration: const BoxDecoration(
            gradient: LinearGradient(colors: [_teal, _tealDark]),
          ),
          accountName: Text(widget.nombreUsuario),
          accountEmail: Text(widget.cargoUsuario),
          currentAccountPicture: const CircleAvatar(
            backgroundColor: Colors.white24,
            child: Icon(Icons.person, color: Colors.white, size: 32),
          ),
        ),

        // Inicio
        ListTile(
          leading: const Icon(Icons.home, color: _teal),
          title: const Text('Inicio'),
          onTap: () => Navigator.pop(context),
        ),

        const Divider(height: 1),

        // ── Reportes ───────────────────────────────────────
        ListTile(
          leading: const Icon(Icons.bar_chart, color: _teal),
          title: const Text('Reportes & Estadísticas'),
          subtitle: const Text(
            'Gráficas y tendencias',
            style: TextStyle(fontSize: 11),
          ),
          trailing: Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            decoration: BoxDecoration(
              color: _teal,
              borderRadius: BorderRadius.circular(10),
            ),

            child: const Text(
              'Ver Graficas',
              style: TextStyle(
                color: Colors.white,
                fontSize: 9,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),

          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const ReportesScreen()),
            );
          },
        ),

        const Divider(height: 1),

        // Cerrar sesión
        ListTile(
          leading: const Icon(Icons.logout, color: _rojo),
          title: const Text('Cerrar sesión'),
          onTap: () {
            Navigator.pop(context);
            _cerrarSesion();
          },
        ),

        const Spacer(),

        // Versión
        Container(
          padding: const EdgeInsets.all(12),
          color: _tealLight,
          child: const Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.info_outline, size: 14, color: _teal),
              SizedBox(width: 6),
              Text(
                'SINAR v1.0.0',
                style: TextStyle(fontSize: 11, color: _teal),
              ),
            ],
          ),
        ),
      ],
    ),
  );

  InputDecoration _inputDeco(String label, IconData icono) => InputDecoration(
    labelText: label,
    prefixIcon: Icon(icono, color: _teal),
    border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(10),
      borderSide: const BorderSide(color: _tealLight),
    ),
  );
}

// ─── WIDGETS REUTILIZABLES ────────────────────────────────────────────────

class _Tarjeta extends StatelessWidget {
  final Widget child;
  const _Tarjeta({required this.child});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: Colors.white.withValues(alpha: 0.95),
      borderRadius: BorderRadius.circular(14),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withValues(alpha: 0.07),
          blurRadius: 8,
          offset: const Offset(0, 3),
        ),
      ],
    ),
    child: child,
  );
}

class _SeccionTitulo extends StatelessWidget {
  final IconData icono;
  final String titulo;
  final String subtitulo;
  const _SeccionTitulo({
    required this.icono,
    required this.titulo,
    required this.subtitulo,
  });

  @override
  Widget build(BuildContext context) => Row(
    children: [
      Icon(icono, color: _teal, size: 28),
      const SizedBox(width: 12),
      Expanded(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              titulo,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: _tealDark,
              ),
            ),
            Text(subtitulo, style: const TextStyle(fontSize: 12, color: _teal)),
          ],
        ),
      ),
    ],
  );
}

class _EncabezadoSeccion extends StatelessWidget {
  final String numero;
  final String titulo;
  const _EncabezadoSeccion({required this.numero, required this.titulo});

  @override
  Widget build(BuildContext context) => Row(
    children: [
      Container(
        width: 32,
        height: 32,
        decoration: const BoxDecoration(color: _teal, shape: BoxShape.circle),
        child: Center(
          child: Text(
            numero,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
      const SizedBox(width: 12),
      Text(
        titulo,
        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
      ),
    ],
  );
}

class _CampoTexto extends StatelessWidget {
  final TextEditingController ctrl;
  final String label;
  final IconData icono;
  final TextInputType tipo;
  final bool readonly;
  final int maxLineas;

  const _CampoTexto({
    required this.ctrl,
    required this.label,
    required this.icono,
    this.tipo = TextInputType.text,
    this.readonly = false,
    this.maxLineas = 1,
  });

  @override
  Widget build(BuildContext context) => TextField(
    controller: ctrl,
    keyboardType: tipo,
    readOnly: readonly,
    maxLines: maxLineas,
    minLines: maxLineas == 1 ? 1 : maxLineas,
    decoration: InputDecoration(
      labelText: label,
      prefixIcon: Icon(icono, color: readonly ? Colors.grey : _teal),
      filled: readonly,
      fillColor: readonly
          ? Colors.grey.withValues(alpha: 0.07)
          : Colors.transparent,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(
          color: readonly ? Colors.grey.shade300 : _tealLight,
        ),
      ),
    ),
  );
}

class _TarjetaPrestamo extends StatelessWidget {
  final PrestamoItem item;
  final VoidCallback onRecibir;

  const _TarjetaPrestamo({required this.item, required this.onRecibir});

  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 12),
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: Colors.white.withValues(alpha: 0.95),
      borderRadius: BorderRadius.circular(14),
      border: Border(left: BorderSide(color: _teal, width: 4)),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withValues(alpha: 0.07),
          blurRadius: 8,
          offset: const Offset(0, 3),
        ),
      ],
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item.funcionario,
                    style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    item.cedula,
                    style: const TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: item.estado == 'activo' ? _verde : Colors.orange,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                item.estado.toUpperCase(),
                style: const TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Text(
          '📻 ${item.radio} (${item.modelo})',
          style: const TextStyle(fontSize: 12),
        ),
        Text(
          '📅 ${item.fechaFormato} • ${item.dias} días',
          style: const TextStyle(fontSize: 11, color: Colors.grey),
        ),
        if (item.estado != 'devuelto') ...[
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            height: 36,
            child: ElevatedButton.icon(
              icon: const Icon(Icons.check_circle, size: 18),
              label: const Text('Registrar Devolución'),
              onPressed: onRecibir,
            ),
          ),
        ],
      ],
    ),
  );
}
