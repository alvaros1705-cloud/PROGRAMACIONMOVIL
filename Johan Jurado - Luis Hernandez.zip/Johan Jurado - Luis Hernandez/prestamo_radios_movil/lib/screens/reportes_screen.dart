import 'dart:math';
import 'package:flutter/material.dart';
import '../services/api_service.dart';

// ─── COLORES INSTITUCIONALES ───────────────────────────────────────────────
const Color _teal = Color(0xFF1A7A8A);
const Color _tealDark = Color(0xFF145F6E);
const Color _tealLight = Color(0xFFE0F4F7);
const Color _rojo = Color(0xFFCC0000);
const Color _verde = Color(0xFF1A6E3A);
const Color _amber = Color(0xFFF59E0B);
const Color _indigo = Color(0xFF4F46E5);

// ─── PALETA DE GRÁFICAS ────────────────────────────────────────────────────
const List<Color> _chartColors = [
  Color(0xFF1A7A8A),
  Color(0xFF145F6E),
  Color(0xFF1A6E3A),
  Color(0xFFCC0000),
  Color(0xFFF59E0B),
  Color(0xFF4F46E5),
  Color(0xFF9333EA),
  Color(0xFFEC4899),
  Color(0xFF0EA5E9),
  Color(0xFF10B981),
];

// ─── MODELO DE DATOS REPORTE ───────────────────────────────────────────────
class _DatoReporte {
  final String etiqueta;
  final int valor;
  final String? subtitulo;
  _DatoReporte(this.etiqueta, this.valor, {this.subtitulo});
}

class _EstadisticasGlobales {
  final int totalRadios;
  final int radiosDisponibles;
  final int radiosEnPrestamo;
  final int totalFuncionarios;
  final int totalTecnicos;
  final int totalPrestamos;
  final int prestamosActivos;
  final int prestamosDevueltos;
  final double tasaUso;

  _EstadisticasGlobales({
    required this.totalRadios,
    required this.radiosDisponibles,
    required this.radiosEnPrestamo,
    required this.totalFuncionarios,
    required this.totalTecnicos,
    required this.totalPrestamos,
    required this.prestamosActivos,
    required this.prestamosDevueltos,
    required this.tasaUso,
  });

  factory _EstadisticasGlobales.fromJson(Map<String, dynamic> j) =>
      _EstadisticasGlobales(
        totalRadios: j['total_radios'] ?? 0,
        radiosDisponibles: j['radios_disponibles'] ?? 0,
        radiosEnPrestamo: j['radios_en_prestamo'] ?? 0,
        totalFuncionarios: j['total_funcionarios'] ?? 0,
        totalTecnicos: j['total_tecnicos'] ?? 0,
        totalPrestamos: j['total_prestamos'] ?? 0,
        prestamosActivos: j['prestamos_activos'] ?? 0,
        prestamosDevueltos: j['prestamos_devueltos'] ?? 0,
        tasaUso: (j['tasa_uso_radios'] ?? 0).toDouble(),
      );
}

// ─── PANTALLA PRINCIPAL DE REPORTES ───────────────────────────────────────
class ReportesScreen extends StatefulWidget {
  const ReportesScreen({super.key});

  @override
  State<ReportesScreen> createState() => _ReportesScreenState();
}

class _ReportesScreenState extends State<ReportesScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabs;

  bool _cargando = true;
  String? _error;

  _EstadisticasGlobales? _stats;
  List<_DatoReporte> _radios = [];
  List<_DatoReporte> _funcionarios = [];
  List<_DatoReporte> _tecnicos = [];
  List<_DatoReporte> _unidades = [];

  // Filtro de fecha (solo informativo en UI, los endpoints reales del backend
  // podrían aceptarlo; aquí filtramos localmente como ejemplo preparado)
  DateTime? _fechaDesde;
  DateTime? _fechaHasta;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 4, vsync: this);
    _cargar();
  }

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  // ── Carga de datos ──────────────────────────────────────────────────────
  Future<void> _cargar() async {
    setState(() {
      _cargando = true;
      _error = null;
    });
    try {
      final results = await Future.wait([
        ApiService.obtenerEstadisticas(),
        ApiService.obtenerReporteRadios(),
        ApiService.obtenerReporteFuncionarios(),
        ApiService.obtenerReporteTecnicos(),
        ApiService.obtenerReporteUnidades(),
      ]);

      if (!mounted) return;

      final statsJson = results[0] as Map<String, dynamic>;
      final radiosJson = results[1] as List<Map<String, dynamic>>;
      final funcJson = results[2] as List<Map<String, dynamic>>;
      final tecJson = results[3] as List<Map<String, dynamic>>;
      final unidJson = results[4] as List<Map<String, dynamic>>;

      setState(() {
        _stats = _EstadisticasGlobales.fromJson(statsJson);

        _radios =
            radiosJson
                .map(
                  (e) => _DatoReporte(
                    e['serial'] ?? '',
                    e['total_asignaciones'] ?? 0,
                    subtitulo: e['modelo'] ?? '',
                  ),
                )
                .where((e) => e.valor > 0)
                .toList()
              ..sort((a, b) => b.valor.compareTo(a.valor));

        _funcionarios =
            funcJson
                .map(
                  (e) => _DatoReporte(
                    _nombreCorto(e['nombre'] ?? ''),
                    e['total_prestamos'] ?? 0,
                    subtitulo: e['unidad'] ?? '',
                  ),
                )
                .where((e) => e.valor > 0)
                .toList()
              ..sort((a, b) => b.valor.compareTo(a.valor));

        _tecnicos =
            tecJson
                .map(
                  (e) => _DatoReporte(
                    e['nombre'] ?? '',
                    e['total_entregas'] ?? 0,
                    subtitulo: 'Recepciones: ${e['total_recepciones'] ?? 0}',
                  ),
                )
                .where((e) => e.valor > 0)
                .toList()
              ..sort((a, b) => b.valor.compareTo(a.valor));

        _unidades =
            unidJson
                .map(
                  (e) => _DatoReporte(
                    _abreviarUnidad(e['unidad'] ?? 'SIN UNIDAD'),
                    e['cantidad_radios'] ?? 0,
                  ),
                )
                .where((e) => e.valor > 0)
                .toList()
              ..sort((a, b) => b.valor.compareTo(a.valor));

        _cargando = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = 'Error al cargar reportes: $e';
        _cargando = false;
      });
    }
  }

  String _nombreCorto(String nombre) {
    final partes = nombre.trim().split(' ');
    if (partes.length <= 2) return nombre;
    return '${partes[0]} ${partes[1]}';
  }

  String _abreviarUnidad(String u) {
    if (u.length <= 14) return u;
    return '${u.substring(0, 12)}…';
  }

  // ── Selector de fecha ────────────────────────────────────────────────────
  Future<void> _seleccionarFecha(bool esDesde) async {
    final inicial = esDesde
        ? (_fechaDesde ?? DateTime.now().subtract(const Duration(days: 30)))
        : (_fechaHasta ?? DateTime.now());

    final picked = await showDatePicker(
      context: context,
      initialDate: inicial,
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
      builder: (ctx, child) => Theme(
        data: ThemeData.light().copyWith(
          colorScheme: const ColorScheme.light(primary: _teal),
        ),
        child: child!,
      ),
    );
    if (picked != null) {
      setState(() {
        if (esDesde) {
          _fechaDesde = picked;
        } else {
          _fechaHasta = picked;
        }
      });
      _cargar();
    }
  }

  void _limpiarFiltros() {
    setState(() {
      _fechaDesde = null;
      _fechaHasta = null;
    });
    _cargar();
  }

  // ── Build ────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: _teal,
        foregroundColor: Colors.white,
        elevation: 3,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Reportes & Estadísticas',
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
            ),
            Text(
              'SINAR — OFTIC',
              style: TextStyle(fontSize: 9, color: Colors.white70),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'Actualizar',
            onPressed: _cargar,
          ),
        ],
        bottom: TabBar(
          controller: _tabs,
          isScrollable: true,
          indicatorColor: Colors.white,
          labelStyle: const TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w700,
          ),
          unselectedLabelStyle: const TextStyle(fontSize: 11),
          tabs: const [
            Tab(icon: Icon(Icons.dashboard, size: 16), text: 'Resumen'),
            Tab(icon: Icon(Icons.radio, size: 16), text: 'Radios'),
            Tab(icon: Icon(Icons.people, size: 16), text: 'Funcionarios'),
            Tab(icon: Icon(Icons.engineering, size: 16), text: 'Técnicos'),
          ],
        ),
      ),
      body: Column(
        children: [
          _buildFiltroFechas(),
          Expanded(
            child: _cargando
                ? const Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        CircularProgressIndicator(color: _teal),
                        SizedBox(height: 12),
                        Text(
                          'Cargando reportes...',
                          style: TextStyle(color: _teal),
                        ),
                      ],
                    ),
                  )
                : _error != null
                ? _buildError()
                : TabBarView(
                    controller: _tabs,
                    children: [
                      _buildTabResumen(),
                      _buildTabGrafica(
                        datos: _radios,
                        titulo: 'Radios más prestados',
                        subtitulo: 'Por número de asignaciones',
                        icono: Icons.radio,
                        tipoGrafica: _TipoGrafica.barras,
                      ),
                      _buildTabGrafica(
                        datos: _funcionarios,
                        titulo: 'Funcionarios con más préstamos',
                        subtitulo: 'Por total de radios recibidos',
                        icono: Icons.person,
                        tipoGrafica: _TipoGrafica.circular,
                        datosExtra: _unidades,
                        tituloExtra: 'Unidades con más radios activos',
                      ),
                      _buildTabGrafica(
                        datos: _tecnicos,
                        titulo: 'Técnicos más activos',
                        subtitulo: 'Por total de entregas',
                        icono: Icons.engineering,
                        tipoGrafica: _TipoGrafica.barrasHorizontal,
                      ),
                    ],
                  ),
          ),
        ],
      ),
    );
  }

  // ── Filtro de fechas ─────────────────────────────────────────────────────
  Widget _buildFiltroFechas() {
    final fmt = (DateTime? d) => d != null
        ? '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}'
        : 'Seleccionar';
    final activo = _fechaDesde != null || _fechaHasta != null;

    return Container(
      color: _tealLight,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      child: Row(
        children: [
          const Icon(Icons.date_range, size: 16, color: _tealDark),
          const SizedBox(width: 6),
          _chipFecha(
            'Desde: ${fmt(_fechaDesde)}',
            () => _seleccionarFecha(true),
          ),
          const SizedBox(width: 6),
          _chipFecha(
            'Hasta: ${fmt(_fechaHasta)}',
            () => _seleccionarFecha(false),
          ),
          const Spacer(),
          if (activo)
            GestureDetector(
              onTap: _limpiarFiltros,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: _rojo.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.clear, size: 12, color: _rojo),
                    SizedBox(width: 4),
                    Text(
                      'Limpiar',
                      style: TextStyle(
                        fontSize: 11,
                        color: _rojo,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _chipFecha(String label, VoidCallback onTap) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _teal.withValues(alpha: 0.4)),
      ),
      child: Text(
        label,
        style: const TextStyle(
          fontSize: 11,
          color: _tealDark,
          fontWeight: FontWeight.w600,
        ),
      ),
    ),
  );

  // ── Error ────────────────────────────────────────────────────────────────
  Widget _buildError() => Center(
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.cloud_off, size: 48, color: _rojo),
          const SizedBox(height: 12),
          Text(
            _error!,
            textAlign: TextAlign.center,
            style: const TextStyle(color: _rojo),
          ),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            icon: const Icon(Icons.refresh),
            label: const Text('Reintentar'),
            style: ElevatedButton.styleFrom(backgroundColor: _teal),
            onPressed: _cargar,
          ),
        ],
      ),
    ),
  );

  // ── TAB RESUMEN ──────────────────────────────────────────────────────────
  Widget _buildTabResumen() {
    final s = _stats;
    if (s == null) return const SizedBox();

    final h = MediaQuery.of(context).size.height;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 8,
            crossAxisSpacing: 8,
            childAspectRatio: 1.6,
            children: [
              _kpi(
                'Préstamos activos',
                s.prestamosActivos.toString(),
                Icons.radio,
                _teal,
              ),
              _kpi(
                'Radios disponibles',
                s.radiosDisponibles.toString(),
                Icons.check_circle,
                _verde,
              ),
              _kpi(
                'Funcionarios',
                s.totalFuncionarios.toString(),
                Icons.people,
                _indigo,
              ),
              _kpi(
                'Total préstamos',
                s.totalPrestamos.toString(),
                Icons.history,
                _amber,
              ),
            ],
          ),

          _seccionTitulo(Icons.donut_large, 'Estado total flota'),
          const SizedBox(height: 6),

          _Tarjeta(
            child: Column(
              children: [
                SizedBox(
                  height: h * 0.22,
                  child: _GraficaCircular(
                    datos: [
                      _DatoReporte('En préstamo', s.radiosEnPrestamo),
                      _DatoReporte('Disponibles', s.radiosDisponibles),
                    ],
                    colores: const [_rojo, _verde],
                  ),
                ),

                const SizedBox(height: 6),

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _statItem('Total', s.totalRadios.toString()),
                    _statItem('Uso', '${s.tasaUso.toStringAsFixed(1)}%'),
                    _statItem('Devueltos', s.prestamosDevueltos.toString()),
                  ],
                ),
              ],
            ),
          ),

          const SizedBox(height: 12),

          // Top 5 radios más usados
          // _seccionTitulo(Icons.star, 'Top 5 radios más usados'),
          // const SizedBox(height: 6),
          // _Tarjeta(
          //   child: SizedBox(
          //     height: h * 0.25,
          //     child: _GraficaTopRadios(
          //       datos: s.topRadios,
          //     ),
          //   ),
          // ),
          // const SizedBox(height: 20),
        ],
      ),
    );
  }

  // ── TAB GENÉRICO CON GRÁFICA ─────────────────────────────────────────────
  Widget _buildTabGrafica({
    required List<_DatoReporte> datos,
    required String titulo,
    required String subtitulo,
    required IconData icono,
    required _TipoGrafica tipoGrafica,
    List<_DatoReporte>? datosExtra,
    String? tituloExtra,
  }) {
    if (datos.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icono, size: 48, color: Colors.grey.shade300),
            const SizedBox(height: 12),
            Text(
              'Sin datos disponibles',
              style: TextStyle(color: Colors.grey.shade400),
            ),
          ],
        ),
      );
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _seccionTitulo(icono, titulo, subtitulo: subtitulo),
          const SizedBox(height: 12),

          // Gráfica principal
          _Tarjeta(
            child: tipoGrafica == _TipoGrafica.barras
                ? _GraficaBarras(datos: datos)
                : tipoGrafica == _TipoGrafica.barrasHorizontal
                ? _GraficaBarrasHorizontal(datos: datos)
                : Column(
                    children: [
                      SizedBox(
                        height: 220,
                        child: _GraficaCircular(
                          datos: datos.take(8).toList(),
                          colores: _chartColors,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Wrap(
                        spacing: 12,
                        runSpacing: 6,
                        children: [
                          for (int i = 0; i < min(datos.length, 8); i++)
                            _leyenda(
                              datos[i].etiqueta,
                              _chartColors[i % _chartColors.length],
                            ),
                        ],
                      ),
                    ],
                  ),
          ),

          const SizedBox(height: 20),

          // Tabla de ranking
          _seccionTitulo(Icons.leaderboard, 'Ranking detallado'),
          const SizedBox(height: 10),
          _Tarjeta(child: _TablaRanking(datos: datos)),

          // Sección extra (unidades en tab funcionarios)
          if (datosExtra != null && datosExtra.isNotEmpty) ...[
            const SizedBox(height: 20),
            _seccionTitulo(Icons.location_city, tituloExtra ?? ''),
            const SizedBox(height: 12),
            _Tarjeta(
              child: Column(
                children: [
                  SizedBox(
                    height: 200,
                    child: _GraficaCircular(
                      datos: datosExtra.take(6).toList(),
                      colores: _chartColors,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 12,
                    runSpacing: 6,
                    children: [
                      for (int i = 0; i < min(datosExtra.length, 6); i++)
                        _leyenda(
                          datosExtra[i].etiqueta,
                          _chartColors[i % _chartColors.length],
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  // ── Helpers UI ───────────────────────────────────────────────────────────
  Widget _kpi(String label, String valor, IconData icono, Color color) =>
      Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: color.withValues(alpha: 0.15),
              blurRadius: 8,
              offset: const Offset(0, 3),
            ),
          ],
          border: Border(left: BorderSide(color: color, width: 4)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icono, color: color, size: 22),
            const SizedBox(height: 6),
            Text(
              valor,
              style: TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
            Text(
              label,
              style: const TextStyle(fontSize: 11, color: Colors.grey),
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      );

  Widget _seccionTitulo(IconData icono, String titulo, {String? subtitulo}) =>
      Row(
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: _teal.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icono, color: _teal, size: 18),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  titulo,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: _tealDark,
                  ),
                ),
                if (subtitulo != null)
                  Text(
                    subtitulo,
                    style: const TextStyle(fontSize: 11, color: Colors.grey),
                  ),
              ],
            ),
          ),
        ],
      );

  Widget _statItem(String label, String valor) => Column(
    children: [
      Text(
        valor,
        style: const TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
          color: _tealDark,
        ),
      ),
      Text(label, style: const TextStyle(fontSize: 10, color: Colors.grey)),
    ],
  );

  Widget _leyenda(String label, Color color) => Row(
    mainAxisSize: MainAxisSize.min,
    children: [
      Container(
        width: 10,
        height: 10,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(2),
        ),
      ),
      const SizedBox(width: 4),
      Text(label, style: const TextStyle(fontSize: 10, color: Colors.black87)),
    ],
  );
}

// ─── TIPOS DE GRÁFICA ──────────────────────────────────────────────────────
enum _TipoGrafica { barras, barrasHorizontal, circular }

// ─── TARJETA CONTENEDOR ────────────────────────────────────────────────────
class _Tarjeta extends StatelessWidget {
  final Widget child;
  const _Tarjeta({required this.child});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(14),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withValues(alpha: 0.06),
          blurRadius: 8,
          offset: const Offset(0, 3),
        ),
      ],
    ),
    child: child,
  );
}

// ─── GRÁFICA CIRCULAR (PIE CHART) ─────────────────────────────────────────
class _GraficaCircular extends StatelessWidget {
  final List<_DatoReporte> datos;
  final List<Color> colores;

  const _GraficaCircular({required this.datos, required this.colores});

  @override
  Widget build(BuildContext context) {
    if (datos.isEmpty) return const SizedBox();
    return CustomPaint(
      painter: _PiePainter(datos: datos, colores: colores),
      child: const SizedBox.expand(),
    );
  }
}

class _PiePainter extends CustomPainter {
  final List<_DatoReporte> datos;
  final List<Color> colores;

  _PiePainter({required this.datos, required this.colores});

  @override
  void paint(Canvas canvas, Size size) {
    final total = datos.fold<int>(0, (s, d) => s + d.valor);
    if (total == 0) return;

    final center = Offset(size.width / 2, size.height / 2);
    final radius = min(size.width, size.height) / 2 - 10;
    double startAngle = -pi / 2;

    final paintSlice = Paint()..style = PaintingStyle.fill;
    final paintBorder = Paint()
      ..style = PaintingStyle.stroke
      ..color = Colors.white
      ..strokeWidth = 2;

    final textPainter = TextPainter(textDirection: TextDirection.ltr);

    for (int i = 0; i < datos.length; i++) {
      final sweep = (datos[i].valor / total) * 2 * pi;
      paintSlice.color = colores[i % colores.length];

      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        startAngle,
        sweep,
        true,
        paintSlice,
      );
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        startAngle,
        sweep,
        true,
        paintBorder,
      );

      // Porcentaje dentro del sector si es suficientemente grande
      if (sweep > 0.3) {
        final midAngle = startAngle + sweep / 2;
        final textOffset = Offset(
          center.dx + (radius * 0.65) * cos(midAngle),
          center.dy + (radius * 0.65) * sin(midAngle),
        );
        final pct = (datos[i].valor / total * 100).toStringAsFixed(0);
        textPainter.text = TextSpan(
          text: '$pct%',
          style: const TextStyle(
            color: Colors.white,
            fontSize: 10,
            fontWeight: FontWeight.bold,
          ),
        );
        textPainter.layout();
        textPainter.paint(
          canvas,
          textOffset - Offset(textPainter.width / 2, textPainter.height / 2),
        );
      }

      startAngle += sweep;
    }

    // Círculo interior (donut)
    canvas.drawCircle(
      center,
      radius * 0.42,
      Paint()
        ..color = Colors.white
        ..style = PaintingStyle.fill,
    );

    // Total en el centro
    textPainter.text = TextSpan(
      text: '$total',
      style: const TextStyle(
        fontSize: 18,
        fontWeight: FontWeight.bold,
        color: _tealDark,
      ),
    );
    textPainter.layout();
    textPainter.paint(
      canvas,
      center - Offset(textPainter.width / 2, textPainter.height / 2 + 6),
    );
    textPainter.text = const TextSpan(
      text: 'total',
      style: TextStyle(fontSize: 9, color: Colors.grey),
    );
    textPainter.layout();
    textPainter.paint(canvas, center - Offset(textPainter.width / 2, -10));
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

// ─── GRÁFICA DE BARRAS VERTICAL ────────────────────────────────────────────
class _GraficaBarras extends StatelessWidget {
  final List<_DatoReporte> datos;
  final bool compact;

  const _GraficaBarras({required this.datos, this.compact = false});

  @override
  Widget build(BuildContext context) {
    final maxVal = datos.fold<int>(0, (m, d) => max(m, d.valor));
    if (maxVal == 0) return const SizedBox(height: 80);

    return SizedBox(
      height: compact ? 150 : 200,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          for (int i = 0; i < datos.length; i++) ...[
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    datos[i].valor.toString(),
                    style: const TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                      color: _tealDark,
                    ),
                  ),
                  const SizedBox(height: 2),
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 600),
                    curve: Curves.easeOut,
                    height: compact
                        ? (datos[i].valor / maxVal) * 100
                        : (datos[i].valor / maxVal) * 150,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.bottomCenter,
                        end: Alignment.topCenter,
                        colors: [
                          _chartColors[i % _chartColors.length],
                          _chartColors[i % _chartColors.length].withValues(
                            alpha: 0.6,
                          ),
                        ],
                      ),
                      borderRadius: const BorderRadius.vertical(
                        top: Radius.circular(6),
                      ),
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    datos[i].etiqueta,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 9, color: Colors.grey),
                  ),
                ],
              ),
            ),
            if (i < datos.length - 1) const SizedBox(width: 4),
          ],
        ],
      ),
    );
  }
}

// ─── GRÁFICA DE BARRAS HORIZONTAL ─────────────────────────────────────────
class _GraficaBarrasHorizontal extends StatelessWidget {
  final List<_DatoReporte> datos;

  const _GraficaBarrasHorizontal({required this.datos});

  @override
  Widget build(BuildContext context) {
    final maxVal = datos.fold<int>(0, (m, d) => max(m, d.valor));
    if (maxVal == 0) return const SizedBox(height: 80);

    return Column(
      children: [
        for (int i = 0; i < min(datos.length, 8); i++) ...[
          _BarraHorizontal(
            dato: datos[i],
            maxVal: maxVal,
            color: _chartColors[i % _chartColors.length],
          ),
          if (i < datos.length - 1) const SizedBox(height: 10),
        ],
      ],
    );
  }
}

class _BarraHorizontal extends StatelessWidget {
  final _DatoReporte dato;
  final int maxVal;
  final Color color;

  const _BarraHorizontal({
    required this.dato,
    required this.maxVal,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                dato.etiqueta,
                style: const TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
            const SizedBox(width: 8),
            Text(
              '${dato.valor}',
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        LayoutBuilder(
          builder: (ctx, constraints) {
            final pct = dato.valor / maxVal;
            return Stack(
              children: [
                Container(
                  height: 14,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: color.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(7),
                  ),
                ),
                AnimatedContainer(
                  duration: const Duration(milliseconds: 600),
                  curve: Curves.easeOut,
                  height: 14,
                  width: constraints.maxWidth * pct,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [color, color.withValues(alpha: 0.7)],
                    ),
                    borderRadius: BorderRadius.circular(7),
                  ),
                ),
              ],
            );
          },
        ),
        if (dato.subtitulo != null && dato.subtitulo!.isNotEmpty)
          Text(
            dato.subtitulo!,
            style: const TextStyle(fontSize: 9, color: Colors.grey),
          ),
      ],
    );
  }
}

// ─── TABLA DE RANKING ─────────────────────────────────────────────────────
class _TablaRanking extends StatelessWidget {
  final List<_DatoReporte> datos;

  const _TablaRanking({required this.datos});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 10),
          decoration: const BoxDecoration(
            color: _teal,
            borderRadius: BorderRadius.vertical(top: Radius.circular(8)),
          ),
          child: const Row(
            children: [
              SizedBox(
                width: 28,
                child: Text(
                  '#',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              Expanded(
                child: Text(
                  'Nombre',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              SizedBox(
                width: 50,
                child: Text(
                  'Total',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ),
        for (int i = 0; i < datos.length; i++)
          Container(
            padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 10),
            color: i.isEven ? Colors.white : _tealLight,
            child: Row(
              children: [
                SizedBox(
                  width: 28,
                  child: Container(
                    width: 22,
                    height: 22,
                    decoration: BoxDecoration(
                      color: i < 3
                          ? [_amber, Colors.grey.shade400, _teal][i]
                          : Colors.grey.shade200,
                      shape: BoxShape.circle,
                    ),
                    child: Center(
                      child: Text(
                        '${i + 1}',
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          color: i < 3 ? Colors.white : Colors.grey,
                        ),
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        datos[i].etiqueta,
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                      if (datos[i].subtitulo != null &&
                          datos[i].subtitulo!.isNotEmpty)
                        Text(
                          datos[i].subtitulo!,
                          style: const TextStyle(
                            fontSize: 10,
                            color: Colors.grey,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                    ],
                  ),
                ),
                SizedBox(
                  width: 50,
                  child: Text(
                    '${datos[i].valor}',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                      color: _chartColors[i % _chartColors.length],
                    ),
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }
}

class _GraficaTopRadios extends StatelessWidget {
  final List<_DatoReporte> datos;

  const _GraficaTopRadios({required this.datos});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: datos.length,
      itemBuilder: (_, i) {
        final d = datos[i];
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Row(
            children: [
              SizedBox(
                width: 80,
                child: Text(
                  d.etiqueta,
                  style: const TextStyle(fontSize: 10),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Expanded(
                child: Container(
                  height: 8,
                  decoration: BoxDecoration(
                    color: _amber,
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
              ),
              const SizedBox(width: 6),
              Text('${d.valor}', style: const TextStyle(fontSize: 10)),
            ],
          ),
        );
      },
    );
  }
}
