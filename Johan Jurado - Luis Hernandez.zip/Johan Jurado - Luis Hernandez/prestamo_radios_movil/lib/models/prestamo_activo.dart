class PrestamoActivo {
  final int id;
  final String cedula;
  final String funcionario;
  final String radio;
  final String fecha;
  final String estado;
  final String? modelo; // Modelo del radio
  final String? celular; // Celular del funcionario
  final int? dias; // Días desde asignación

  PrestamoActivo({
    required this.id,
    required this.cedula,
    required this.funcionario,
    required this.radio,
    required this.fecha,
    required this.estado,
    this.modelo,
    this.celular,
    this.dias,
  });

  // Método para convertir fecha UTC a zona de Bogotá (UTC-5)
  String get fechaFormato {
    try {
      // Intentar parsear la fecha del servidor (generalmente viene en UTC)
      DateTime? dt = DateTime.tryParse(fecha);

      if (dt == null) {
        // Si no se puede parsear, retornar la fecha tal como viene
        return fecha;
      }

      // Si la fecha viene en UTC, convertir a zona de Bogotá (UTC-5)
      // Restar 5 horas
      final bogotaTime = dt.subtract(const Duration(hours: 5));

      // Formato: "2024-05-26 15:26"
      return "${bogotaTime.year.toString().padLeft(4, '0')}-"
          "${bogotaTime.month.toString().padLeft(2, '0')}-"
          "${bogotaTime.day.toString().padLeft(2, '0')} "
          "${bogotaTime.hour.toString().padLeft(2, '0')}:"
          "${bogotaTime.minute.toString().padLeft(2, '0')}";
    } catch (e) {
      return fecha;
    }
  }

  factory PrestamoActivo.fromJson(Map<String, dynamic> json) {
    return PrestamoActivo(
      id: json['id'],
      cedula: json['cedula'] ?? '',
      funcionario: json['funcionario'] ?? '',
      radio: json['radio'] ?? '',
      fecha: json['fecha'] ?? 'N/A',
      estado: json['estado'] ?? 'Activo',
      modelo: json['modelo'],
      celular: json['celular'],
      dias: json['dias'],
    );
  }
}
