class Funcionario {
  final int id;
  final String grado;
  final String nombres;
  final String celular;
  final String unidad;
  final String cargo;
  final String cedula; // Mapeo de identificacion desde API

  Funcionario({
    required this.id,
    required this.grado,
    required this.nombres,
    required this.celular,
    required this.unidad,
    required this.cargo,
    this.cedula = '',
  });

  factory Funcionario.fromJson(Map<String, dynamic> json) {
    return Funcionario(
      id: json['id'] ?? 0,
      grado: json['grado'] ?? '',
      nombres: json['apellidos_nombres'] ?? json['nombres'] ?? '',
      celular: json['celular'] ?? '',
      unidad: json['unidad'] ?? '',
      cargo: json['cargo'] ?? '',
      cedula: json['identificacion'] ?? json['cedula'] ?? '',
    );
  }
}
