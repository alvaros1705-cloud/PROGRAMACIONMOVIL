class Tecnico {
  final int id;
  final String nombre;

  Tecnico({required this.id, required this.nombre});

  factory Tecnico.fromJson(Map<String, dynamic> json) {
    return Tecnico(id: json['id'], nombre: json['nombre']);
  }
}
