class Radio {
  final int id;
  final String serial;
  final String modelo;
  final String accesorios;

  Radio({
    required this.id,
    required this.serial,
    required this.modelo,
    required this.accesorios,
  });

  factory Radio.fromJson(Map<String, dynamic> json) {
    return Radio(
      id: json['id'],
      serial: json['serial'],
      modelo: json['modelo'] ?? '',
      accesorios: json['accesorios'] ?? '',
    );
  }
}
