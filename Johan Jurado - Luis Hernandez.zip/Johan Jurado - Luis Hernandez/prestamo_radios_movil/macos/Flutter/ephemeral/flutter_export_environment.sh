#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=C:\Users\luish\OneDrive\Escritorio\flutter_windows_3.41.6-stable\flutter"
export "FLUTTER_APPLICATION_PATH=C:\Users\luish\OneDrive\Escritorio\UNISIMON\7 SEMESTRE\movil aplicaciones\prestamo_radios_movil\prestamo_radios_movil"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=1.0.0"
export "FLUTTER_BUILD_NUMBER=1"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
