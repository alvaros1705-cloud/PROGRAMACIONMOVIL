# 🔧 Configuración de Migración a XAMPP - App SINAR

## ✅ Cambios Realizados

### 1. **URL Base de la API**
- ❌ Anterior: `http://10.249.52.217:5000` (IP antigua)
- ✅ Nuevo: `http://localhost:5000` (XAMPP local)
- **Archivo**: `lib/services/api_service.dart` (línea 18)

### 2. **Modelos Actualizados**
- ✅ `Funcionario.dart`: Agregado campo `cedula` (mapeo de `identificacion`)
- ✅ `PrestamoActivo.dart`: Agregados campos `modelo`, `celular`, `dias`
- ✅ `api_service.dart`: Mejorado manejo de errores en `registrarDevolucion()`

### 3. **Endpoints Verificados en Flask**
Todos los endpoints usados en la app están implementados en `mecuc_radios_flask_v2.3`:
- ✅ `/api/login` - Autenticación
- ✅ `/api/funcionario/<cedula>` - Búsqueda de funcionarios
- ✅ `/api/tecnicos` - Lista de técnicos
- ✅ `/api/radios_disponibles` - Radios sin préstamo activo
- ✅ `/api/prestamo` - Crear nuevo préstamo (POST)
- ✅ `/api/devolucion` - Registrar devolución (POST)
- ✅ `/api/prestamos_activos` - Lista de préstamos activos
- ✅ `/api/reportes/estadisticas` - Estadísticas generales
- ✅ `/api/reportes/radios_mas_asignadas` - Radios más usados
- ✅ `/api/reportes/funcionarios_mas_radios` - Funcionarios con más préstamos
- ✅ `/api/reportes/tecnicos_mas_radios` - Técnicos más activos
- ✅ `/api/reportes/radios_por_unidad` - Radios agrupados por unidad

---

## 🚀 Guía de Ejecución

### **Paso 1: Verificar Base de Datos XAMPP**
```bash
# 1. Abre phpMyAdmin
http://localhost/phpmyadmin/

# 2. Verifica que exista la BD: prestamos_radios
# 3. Verifica las tablas:
#    - funcionarios
#    - tecnicos
#    - radios
#    - prestamos
#    - usuarios
```

### **Paso 2: Configurar Flask en XAMPP**

#### Opción A: Ejecutar Flask en Paralelo con XAMPP
```bash
# 1. Abre PowerShell en la ruta del proyecto Flask
cd "C:\Users\luish\OneDrive\Escritorio\PRESTAMO RADIOS MECUC\DESARROLLO_WEB\mecuc_radios_flask_v2.3"

# 2. Activa el ambiente virtual (si existe)
.\venv\Scripts\Activate

# 3. Instala dependencias si no están (solo primera vez)
pip install -r requirements.txt

# 4. Ejecuta Flask en puerto 5000
python app.py
```

**Salida esperada:**
```
 * Serving Flask app 'app'
 * Debug mode: on
 * Running on http://0.0.0.0:5000
```

#### Opción B: Usar Docker (Alternativa)
```bash
# Si tienes Docker instalado
docker run -e DATABASE_URL=mysql+pymysql://root:@localhost/prestamos_radios -p 5000:5000 flask_app
```

### **Paso 3: Compilar y Ejecutar la App Flutter**

```bash
# 1. Abre una terminal en la carpeta de la app
cd "C:\Users\luish\OneDrive\Escritorio\UNISIMON\7 SEMESTRE\movil aplicaciones\prestamo_radios_movil\prestamo_radios_movil"

# 2. Obtén dependencias
flutter pub get

# 3. Ejecuta el análisis para verificar que no hay errores
flutter analyze

# 4. Ejecuta en emulador o dispositivo
flutter run
```

---

## 🧪 Pruebas de Funcionamiento

### **Test 1: Verificar Conexión a la API**
1. Abre la app
2. Ve a **Login**
3. Intenta autenticarte con un usuario de BD
4. Deberías ver: "Bienvenido [usuario]"

### **Test 2: Búsqueda de Funcionario**
1. En la pestaña de **Registro de Préstamo**
2. Ingresa la cédula de un funcionario existente en BD
3. Los campos deben completarse automáticamente

### **Test 3: Crear Préstamo**
1. Completa todos los datos
2. Selecciona un técnico y un radio
3. Dibuja la firma
4. Haz clic en **Guardar Préstamo**
5. El sistema debe generar el PDF y mostrar "Éxito"

### **Test 4: Registrar Devolución**
1. Ve a la pestaña **Devoluciones**
2. Selecciona un préstamo activo
3. Dibuja la firma
4. Haz clic en **Guardar Devolución**

### **Test 5: Ver Reportes**
1. Ve a la pestaña **Reportes**
2. Verifica que las estadísticas se carguen correctamente
3. Comprueba las gráficas de:
   - Radios más asignados
   - Funcionarios con más préstamos
   - Técnicos más activos
   - Unidades con más radios

---

## 🔍 Solución de Problemas

### **Error: "Connection refused"**
- **Causa**: Flask no está ejecutándose en `localhost:5000`
- **Solución**: 
  1. Verifica que Flask esté corriendo: `python app.py`
  2. Comprueba en `http://localhost:5000` desde el navegador

### **Error: "Database connection error"**
- **Causa**: XAMPP no tiene la BD `prestamos_radios` o no está iniciado
- **Solución**:
  1. Inicia Apache y MySQL en XAMPP Control Panel
  2. Verifica: `http://localhost/phpmyadmin/`
  3. Si falta BD, importa desde el script SQL del Flask

### **Error: "Invalid credentials"**
- **Causa**: Usuario no existe en BD de usuarios
- **Solución**:
  1. Verifica en phpMyAdmin → tabla `usuarios`
  2. Si está vacía, ejecuta: `python crear_usuarios.py` (en la ruta Flask)

### **Error: "Imagen no encontrada" (app.png, logo, etc.)**
- **Causa**: Los assets están en ruta incorrecta
- **Solución**: Verifica que `pubspec.yaml` tenga:
```yaml
flutter:
  assets:
    - assets/images/
```

### **Error: "Dart Analysis Errors"**
```bash
# Limpia cache y reanaliza
flutter clean
flutter pub get
flutter analyze
```

---

## 📋 Checklist de Configuración Final

- [ ] XAMPP está corriendo (Apache + MySQL)
- [ ] BD `prestamos_radios` existe con todas las tablas
- [ ] Flask ejecutándose en `http://localhost:5000`
- [ ] URL en `api_service.dart` es `http://localhost:5000`
- [ ] Flutter dependencies actualizadas (`flutter pub get`)
- [ ] No hay errores en `flutter analyze`
- [ ] App compila sin errores (`flutter run`)
- [ ] Puedo hacer login en la app
- [ ] Puedo crear un préstamo y generar PDF
- [ ] Los reportes se cargan correctamente

---

## 📱 Notas Importantes

### **Para Acceso desde Otro Dispositivo (en red)**
Si necesitas acceder desde un teléfono/tablet en la misma red:

1. Encuentra tu IP local:
```bash
# En PowerShell
ipconfig
# Busca IPv4 Address (ej: 192.168.x.x)
```

2. Cambia en `api_service.dart`:
```dart
static const String baseUrl = 'http://192.168.x.x:5000';
```

3. Asegúrate que Flask use `host="0.0.0.0"` en `app.py`

### **Base de Datos de Ejemplo**
Si necesitas datos de prueba:
```bash
# Desde la ruta del Flask, ejecuta los scripts en este orden:
python importar_funcionarios.py
python importar_tecnicos.py
python importar_radios.py
python crear_usuarios.py
```

---

## 📞 Soporte

En caso de errores específicos:
1. Revisa los logs de Flask en la terminal
2. Revisa los logs de Flutter con `flutter logs`
3. Inspecciona la BD en phpMyAdmin
4. Verifica la conexión de red con `ping localhost:5000`

---

**Fecha de Migración**: Mayo 26, 2026
**Estado**: ✅ Configurado y Listo para Pruebas
