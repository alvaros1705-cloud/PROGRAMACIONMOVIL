import pandas as pd
import pymysql

# ===== CONEXION MYSQL =====
conexion = pymysql.connect(
    host="localhost",
    user="root",
    password="",
    database="prestamos_radios"
)

cursor = conexion.cursor()

# ===== ARCHIVO =====
archivo = "LIBRO CONTROL PRESTAMO DE RADIOS MECUC.xlsm"

df = pd.read_excel(archivo, sheet_name="RADIOS")

contador = 0

for _, row in df.iterrows():
    serial = str(row["SERIE"]).strip()

    if serial == "nan":
        continue

    # ===== EVITAR DUPLICADOS =====
    cursor.execute(
        "SELECT id FROM radios WHERE serial=%s",
        (serial,)
    )
    existe = cursor.fetchone()

    if existe:
        continue

    # ===== INSERT =====
    sql = """
    INSERT INTO radios 
    (serial, modelo, accesorios, observaciones)
    VALUES (%s, %s, %s, %s)
    """

    valores = (
        serial,
        str(row["MODELO"]),
        str(row["ACCESORIOS"]),
        str(row["OBSERVACIONES"])
    )

    cursor.execute(sql, valores)
    contador += 1

conexion.commit()
cursor.close()
conexion.close()

print(f"✅ RADIOS INSERTADOS: {contador}")