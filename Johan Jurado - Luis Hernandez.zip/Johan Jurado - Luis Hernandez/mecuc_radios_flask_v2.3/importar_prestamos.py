import pandas as pd
import pymysql

conexion = pymysql.connect(
    host="localhost",
    user="root",
    password="",
    database="prestamos_radios"
)

cursor = conexion.cursor()

archivo = "LIBRO CONTROL PRESTAMO DE RADIOS MECUC.xlsm"

df = pd.read_excel(archivo, sheet_name="LIBRO_CONTROL")

contador = 0

def limpiar(valor):
    if pd.isna(valor):
        return ""
    return str(valor).strip()

for _, row in df.iterrows():
    try:
        cedula = limpiar(row["NRO DE CEDULA"])
        serial = limpiar(row["SERIAL DEL RADIO"])
        tecnico_presta_nom = limpiar(row["TECNICO QUE PRESTA EL RADIO"])
        tecnico_recibe_nom = limpiar(row["TECNICO QUE RECIBE"])

        if not cedula or not serial:
            continue

        # ===== FUNCIONARIO =====
        cursor.execute(
            "SELECT id FROM funcionarios WHERE identificacion=%s",
            (cedula,)
        )
        func = cursor.fetchone()
        if not func:
            continue
        funcionario_id = func[0]

        # ===== RADIO =====
        cursor.execute(
            "SELECT id FROM radios WHERE serial=%s",
            (serial,)
        )
        radio = cursor.fetchone()
        if not radio:
            continue
        radio_id = radio[0]

        # ===== TECNICO PRESTA =====
        cursor.execute(
            "SELECT id FROM tecnicos WHERE nombre LIKE %s",
            (f"%{tecnico_presta_nom}%",)
        )
        t1 = cursor.fetchone()
        if not t1:
            continue
        tecnico_presta_id = t1[0]

        # ===== TECNICO RECIBE =====
        tecnico_recibe_id = None

        if tecnico_recibe_nom:
            cursor.execute(
                "SELECT id FROM tecnicos WHERE nombre LIKE %s",
                (f"%{tecnico_recibe_nom}%",)
            )
            t2 = cursor.fetchone()
            if t2:
                tecnico_recibe_id = t2[0]

        # ===== FECHAS =====
        fecha_asig = row["FECHA DE ASIGNACION"]
        fecha_dev = row["FECHA DE DEVOLUCION"]

        # ===== DATOS =====
        accesorios = limpiar(row["ACCESORIOS"])
        observaciones = limpiar(row["OBSERVACIONES"])

        # ===== EVITAR DUPLICADOS =====
        cursor.execute("""
            SELECT id FROM prestamos 
            WHERE funcionario_id=%s 
            AND radio_id=%s 
            AND fecha_asignacion=%s
        """, (funcionario_id, radio_id, fecha_asig))

        existe = cursor.fetchone()
        if existe:
            continue

        # ===== INSERT =====
        sql = """
        INSERT INTO prestamos
        (funcionario_id, radio_id, tecnico_presta_id, tecnico_recibe_id,
         fecha_asignacion, fecha_devolucion, accesorios_radio, novedades)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """

        valores = (
            funcionario_id,
            radio_id,
            tecnico_presta_id,
            tecnico_recibe_id,
            fecha_asig,
            fecha_dev if not pd.isna(fecha_dev) else None,
            accesorios,
            observaciones
        )

        cursor.execute(sql, valores)
        contador += 1

    except Exception as e:
        print("⚠️ Error en fila:", e)

conexion.commit()
cursor.close()
conexion.close()

print(f"✅ PRESTAMOS INSERTADOS: {contador}")