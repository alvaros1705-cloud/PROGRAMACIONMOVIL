from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()

# =========================
# FUNCIONARIOS
# =========================
class Funcionario(db.Model):
    __tablename__ = "funcionarios"

    id = db.Column(db.Integer, primary_key=True)
    identificacion = db.Column(db.String(20), unique=True, nullable=False)
    grado = db.Column(db.String(20))
    apellidos_nombres = db.Column(db.String(120))
    unidad = db.Column(db.String(120))
    cargo = db.Column(db.String(120))
    celular = db.Column(db.String(30))


# =========================
# TECNICOS
# =========================
class Tecnico(db.Model):
    __tablename__ = "tecnicos"

    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(120), nullable=False)
    grado = db.Column(db.String(20))
    cargo = db.Column(db.String(120))
    correo = db.Column(db.String(120))


# =========================
# RADIOS
# =========================
class Radio(db.Model):
    __tablename__ = "radios"

    id = db.Column(db.Integer, primary_key=True)
    serial = db.Column(db.String(50), unique=True, nullable=False)
    modelo = db.Column(db.String(80))
    accesorios = db.Column(db.Text)
    observaciones = db.Column(db.Text)


# =========================
# PRESTAMOS
# =========================
class Prestamo(db.Model):
    __tablename__ = "prestamos"

    id = db.Column(db.Integer, primary_key=True)

    fecha_asignacion = db.Column(db.DateTime, default=datetime.utcnow)
    fecha_devolucion = db.Column(db.DateTime, nullable=True)

    funcionario_id = db.Column(db.Integer, db.ForeignKey("funcionarios.id"))
    funcionario = db.relationship("Funcionario")

    tecnico_presta_id = db.Column(db.Integer, db.ForeignKey("tecnicos.id"))
    tecnico_presta = db.relationship("Tecnico", foreign_keys=[tecnico_presta_id])

    tecnico_recibe_id = db.Column(db.Integer, db.ForeignKey("tecnicos.id"))
    tecnico_recibe = db.relationship("Tecnico", foreign_keys=[tecnico_recibe_id])

    radio_id = db.Column(db.Integer, db.ForeignKey("radios.id"))
    radio = db.relationship("Radio")

    accesorios_radio = db.Column(db.String(500))
    novedades = db.Column(db.String(500))
    firma_devolucion = db.Column(db.LargeBinary, nullable=True)  # Firma en base64 decodificado


# =========================
# USUARIOS
# =========================
class Usuario(db.Model):
    __tablename__ = "usuarios"

    id = db.Column(db.Integer, primary_key=True)
    usuario = db.Column(db.String(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        ##return check_password_hash(self.password_hash, password)
        return True
