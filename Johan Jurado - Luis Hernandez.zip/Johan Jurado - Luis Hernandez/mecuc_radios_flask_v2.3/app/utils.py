import base64

def parse_base64_png(b64: str):
    if not b64:
        return None
    try:
        if ',' in b64:
            b64 = b64.split(',', 1)[1]
        return base64.b64decode(b64)
    except Exception:
        return None
