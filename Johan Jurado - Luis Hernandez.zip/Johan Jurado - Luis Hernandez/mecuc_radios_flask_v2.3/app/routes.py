from flask import session
from flask import Blueprint, render_template, request, redirect, url_for, flash, current_app, send_from_directory
from .models import db, Funcionario, Tecnico, Radio, Prestamo, Usuario
from .pdf_generator import generar_pdf_1dt_fr_0018
from .utils import parse_base64_png
from datetime import datetime
from sqlalchemy import and_, func, desc
from config import Config
from flask import request, redirect, url_for, flash

from flask import Blueprint, jsonify
from app.models import Funcionario

bp = Blueprint("main", __name__)

@bp.route("/funcionarios")
def funcionarios():
    data = Funcionario.query.all()

    return jsonify([
        {
            "id": f.id,
            "nombre": f.apellidos_nombres,
            "cedula": f.identificacion,
            "unidad": f.unidad
        }
        for f in data
    ])

BASE_DOWNLOAD = Config.BASE_DOWNLOAD

import base64
import os
from io import BytesIO

@bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        usuario  = request.form.get('usuario', '').strip()
        password = request.form.get('password', '').strip()
        user = Usuario.query.filter_by(usuario=usuario).first()
        if user and user.check_password(password):
            session['usuario'] = user.usuario
            return redirect(url_for('main.index'))
        flash('Usuario o contraseña incorrectos.', 'danger')
    return render_template('login.html')

@bp.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('main.login'))


@bp.route('/')
def index():
    if 'usuario' not in session:
        return redirect(url_for('main.login'))
    tecnicos = Tecnico.query.order_by(Tecnico.nombre.asc()).all()
    subq = db.session.query(Prestamo.radio_id).filter(Prestamo.fecha_devolucion.is_(None))
    radios = Radio.query.filter(~Radio.id.in_(subq)).order_by(Radio.serial.asc()).all()
    return render_template('prestamo_form.html', tecnicos=tecnicos, radios=radios)

@bp.route('/api/funcionario/<cedula>')
def api_funcionario(cedula):
    f = Funcionario.query.filter_by(identificacion=cedula).first()
    if not f:
        return {"exists": False}, 200
    return {
        "exists": True,
        "grado": f.grado or "",
        "nombres": f.apellidos_nombres or "",
        "celular": f.celular or "",
        "unidad": f.unidad or "",
        "cargo": f.cargo or ""
    }, 200

@bp.route('/api/radio/<int:radio_id>')
def api_radio(radio_id):
    r = Radio.query.get_or_404(radio_id)
    return {
        'serial': r.serial,
        'modelo': r.modelo or '',
        'accesorios': r.accesorios or '',
        'observaciones': r.observaciones or ''
    }, 200

@bp.route('/prestamo', methods=['POST'])
def crear_prestamo():
    cedula = request.form.get('cedula', '').strip()
    grado = request.form.get('grado', '').strip()
    nombres = request.form.get('nombres', '').strip()
    celular = request.form.get('celular', '').strip()
    unidad = request.form.get('unidad', '').strip()
    cargo = request.form.get('cargo', '').strip()

    funcionario = Funcionario.query.filter_by(identificacion=cedula).first()
    if not funcionario:
        funcionario = Funcionario(
            identificacion=cedula,
            grado=grado,
            apellidos_nombres=nombres,
            unidad=unidad,
            cargo=cargo,
            celular=celular
        )
        db.session.add(funcionario)
        db.session.flush()

    tecnico_presta_id = int(request.form.get('tecnico_presta'))
    radio_id = int(request.form.get('radio_id'))
    radio = Radio.query.get_or_404(radio_id)

    ya_activo = Prestamo.query.filter(and_(Prestamo.radio_id == radio_id, Prestamo.fecha_devolucion.is_(None))).first()
    if ya_activo:
        flash('El radio seleccionado ya tiene un préstamo activo.', 'danger')
        return redirect(url_for('main.index'))

    accesorios_radio = request.form.get('accesorios_radio', '').strip()
    novedades = request.form.get('novedades', '').strip()

    firma_b64 = request.form.get("firma_png_base64")
    if not firma_b64:
        flash("Debe firmar antes de guardar", "danger")
        return redirect(url_for("main.index"))

    # La firma llega como: data:image/png;base64,XXXX
    firma_bytes = base64.b64decode(
        firma_b64.split(",")[1] if "," in firma_b64 else firma_b64
    )

    prestamo = Prestamo(
        funcionario=funcionario,
        tecnico_presta_id=tecnico_presta_id,
        radio=radio,
        accesorios_radio=accesorios_radio or radio.accesorios,
        novedades=novedades
    )
    db.session.add(prestamo)
    db.session.commit()

    downloads = current_app.config['BASE_DOWNLOAD']
    os.makedirs(downloads, exist_ok=True)
    filename = f"{radio.serial}-{funcionario.identificacion}.pdf"
    pdf_path = os.path.join(downloads, filename)

    data_pdf = {
        'lugar_asignacion': 'GUTIC MECUC',
        'unidad': funcionario.unidad,
        'area_grupo': funcionario.unidad,
        'grado': funcionario.grado,
        'nombres_apellidos': funcionario.apellidos_nombres,
        'cargo': funcionario.cargo,
        'cedula': funcionario.identificacion,
        'tipo_servicio': '',
        'telefono': funcionario.celular,
        'item': 1,
        'linea_id': 'NO APLICA',
        'descripcion': radio.modelo or '',
        'numero_serie': radio.serial,
        'no_inventario': 'NO APLICA',
        'operador': 'NO APLICA',
        'unidad_radio': funcionario.unidad,
        'dependencia': funcionario.unidad,
        'accesorios': accesorios_radio or '',
        'observaciones': novedades or '',
        'tecnico_presta': Tecnico.query.get(tecnico_presta_id).nombre
    }

    generar_pdf_1dt_fr_0018(data=data_pdf, firma_png_bytes=firma_bytes, output_path=pdf_path)
    flash(f'Préstamo generado y PDF guardado: {filename}', 'success')
    return redirect(url_for('main.lista_prestamos'))

@bp.route('/prestamos')
def lista_prestamos():
    prestamos = Prestamo.query.order_by(Prestamo.fecha_asignacion.desc()).all()
    hoy = datetime.now()
    rows = []
    for p in prestamos:
        if p.fecha_devolucion is None:
            dias = (hoy - p.fecha_asignacion).days
            color = 'secondary'
            if dias > 2 and dias < 3:
                color = 'warning'
            elif dias >= 3:
                color = 'danger'
        else:
            color = 'success'
        rows.append((p, color))
    return render_template('prestamos_lista.html', items=rows)

@bp.route('/devolucion/<int:prestamo_id>', methods=['GET','POST'])
def devolucion(prestamo_id):
    if 'usuario' not in session:
        return redirect(url_for('main.login'))
    p = Prestamo.query.get_or_404(prestamo_id)
    if request.method == 'POST':
        p.fecha_devolucion = datetime.now()
        p.tecnico_recibe_id = int(request.form.get('tecnico_recibe'))
        db.session.commit()
        flash('Devolución registrada.', 'success')
        return redirect(url_for('main.lista_prestamos'))

    tecnicos = Tecnico.query.order_by(Tecnico.nombre.asc()).all()
    return render_template('devolucion_form.html', p=p, tecnicos=tecnicos)

@bp.route("/api/tecnicos")
def api_tecnicos():
    tecnicos = Tecnico.query.order_by(Tecnico.nombre.asc()).all()
    return [{"id": t.id, "nombre": t.nombre} for t in tecnicos]

@bp.route("/api/radios_disponibles")
def api_radios_disponibles():
    subq = db.session.query(Prestamo.radio_id).filter(Prestamo.fecha_devolucion.is_(None))
    radios = Radio.query.filter(~Radio.id.in_(subq)).order_by(Radio.serial.asc()).all()
    return [{
        "id": r.id,
        "serial": r.serial,
        "modelo": r.modelo,
        "accesorios": r.accesorios
    } for r in radios]

@bp.route("/api/prestamo", methods=["POST"])
def registrar_prestamo_api():
    data = request.json

    # ===== DATOS BÁSICOS =====
    cedula = data["cedula"]
    tecnico_id = data["tecnico_id"]
    radio_id = data["radio_id"]

    # ===== FUNCIONARIO (CREAR O ACTUALIZAR) =====
    funcionario = Funcionario.query.filter_by(
        identificacion=cedula
    ).first()

    if not funcionario:
        funcionario = Funcionario(
            identificacion=cedula,
            grado=data.get("grado"),
            apellidos_nombres=data.get("apellidos_nombres"),
            unidad=data.get("unidad"),
            cargo=data.get("cargo"),
            celular=data.get("celular"),
        )
        db.session.add(funcionario)
    else:
        funcionario.grado = data.get("grado")
        funcionario.apellidos_nombres = data.get("apellidos_nombres")
        funcionario.unidad = data.get("unidad")
        funcionario.cargo = data.get("cargo")
        funcionario.celular = data.get("celular")

    db.session.flush()  # ✅ necesario para relaciones

    # ===== VALIDAR RADIO DISPONIBLE =====
    radio = Radio.query.get_or_404(radio_id)

    ya_activo = Prestamo.query.filter(
        Prestamo.radio_id == radio_id,
        Prestamo.fecha_devolucion.is_(None)
    ).first()

    if ya_activo:
        return {"error": "El radio ya tiene un préstamo activo"}, 400

    tecnico = Tecnico.query.get_or_404(tecnico_id)

    # ===== DECODIFICAR FIRMA =====
    firma_bytes = base64.b64decode(data["firma"])

    # ===== CREAR PRÉSTAMO (ESTO FALTABA) =====
    prestamo = Prestamo(
        funcionario=funcionario,
        tecnico_presta_id=tecnico.id,
        radio=radio,
        accesorios_radio=radio.accesorios,
        novedades=data.get("observaciones", "")
    )

    db.session.add(prestamo)
    db.session.commit()  # ✅ aquí ya existe el préstamo

    # ===== GENERAR PDF =====
    os.makedirs(BASE_DOWNLOAD, exist_ok=True)
    nombre_pdf = f"{radio.serial}-{cedula}.pdf"
    output_path = os.path.join(BASE_DOWNLOAD, nombre_pdf)

    data_pdf = {
        "lugar_asignacion": "GUTIC MECUC",
        "unidad":           funcionario.unidad,
        "area_grupo":       funcionario.unidad,
        "grado":            funcionario.grado,
        "nombres_apellidos":funcionario.apellidos_nombres,
        "cargo":            funcionario.cargo,
        "cedula":           funcionario.identificacion,
        "tipo_servicio":    "",
        "telefono":         funcionario.celular,
        "item":             1,
        "linea_id":         "NO APLICA",
        "descripcion":      radio.modelo or "",
        "numero_serie":     radio.serial,
        "no_inventario":    "NO APLICA",
        "operador":         "NO APLICA",
        "unidad_radio":     funcionario.unidad,
        "dependencia":      funcionario.unidad,
        "accesorios":       radio.accesorios or "",
        "observaciones":    data.get("observaciones", ""),
        # ── Datos del técnico que ENTREGA (sección "Entrega" del PDF) ──
        "tecnico_presta":   tecnico.nombre,
        "tecnico_grado":    tecnico.grado if hasattr(tecnico, 'grado') else "",
        "tecnico_cargo":    tecnico.cargo if hasattr(tecnico, 'cargo') else "",
    }
    generar_pdf_1dt_fr_0018(
        data=data_pdf,
        firma_png_bytes=firma_bytes,
        output_path=output_path
    )

    return {
        "status": "ok",
        "pdf": nombre_pdf
    }
@bp.route("/api/pdf/<nombre_pdf>")
def obtener_pdf(nombre_pdf):
    try:
        return send_from_directory(
            BASE_DOWNLOAD,
            nombre_pdf,
            as_attachment=False  # False = abrir, True = forzar descarga
        )
    except FileNotFoundError:
        return {"error": "Archivo no encontrado"}, 404


@bp.route("/api/login", methods=["POST"])
def api_login():
    data = request.json
    usuario = data.get("usuario")
    password = data.get("password")

    user = Usuario.query.filter_by(usuario=usuario).first()

    if not user or not user.check_password(password):
        return {"error": "Credenciales inválidas"}, 401

    return {
        "status": "ok",
        "tecnico": user.usuario
    }


from datetime import datetime

@bp.route("/api/devolucion", methods=["POST"])
def registrar_devolucion():
    data = request.json

    prestamo = Prestamo.query.get(data["prestamo_id"])

    if not prestamo:
        return {"error": "Préstamo no encontrado"}, 404

    prestamo.fecha_devolucion = datetime.utcnow()
    prestamo.tecnico_recibe_id = int(data["tecnico"])
    prestamo.firma_devolucion = base64.b64decode(data["firma"])

    db.session.commit()

    return {"status": "ok"}

@bp.route('/api/radio/serial/<serial>')
def api_radio_por_serial(serial):
    """Busca un radio por serial y verifica si está disponible"""
    r = Radio.query.filter(Radio.serial.ilike(f'%{serial}%')).first()
    if not r:
        return {"error": "No encontrado"}, 404
    # Verificar si tiene préstamo activo
    activo = Prestamo.query.filter(
        Prestamo.radio_id == r.id,
        Prestamo.fecha_devolucion.is_(None)
    ).first()
    return {
        "id":          r.id,
        "serial":      r.serial,
        "modelo":      r.modelo or '',
        "accesorios":  r.accesorios or '',
        "disponible":  activo is None
    }, 200


@bp.route('/api/prestamo/serial/<serial>')
def api_prestamo_por_serial(serial):
    """Busca el préstamo activo de un radio por su serial"""
    r = Radio.query.filter(Radio.serial.ilike(f'%{serial}%')).first()
    if not r:
        return {"error": "Radio no encontrado"}, 404
    p = Prestamo.query.filter(
        Prestamo.radio_id == r.id,
        Prestamo.fecha_devolucion.is_(None)
    ).first()
    if not p:
        return {"error": "No hay préstamo activo para ese radio"}, 404
    return {
        "prestamo_id": p.id,
        "radio":       r.serial,
        "funcionario": p.funcionario.apellidos_nombres,
        "cedula":      p.funcionario.identificacion,
        "fecha":       p.fecha_asignacion.strftime('%d/%m/%Y %H:%M')
    }, 200

    from datetime import datetime, timedelta

def _color_prestamo(fecha_asignacion, fecha_devolucion):
    """Retorna el estado según días transcurridos."""
    if fecha_devolucion:
        return 'devuelto'
    dias = (datetime.utcnow() - fecha_asignacion).days
    if dias >= 3:
        return 'vencido'
    if dias >= 2:
        return 'alerta'
    return 'activo'


# ── Ruta para la app Flutter (todos los activos, sin paginar) ──
@bp.route("/api/prestamos_activos")
def prestamos_activos():
    prestamos = Prestamo.query.filter(
        Prestamo.fecha_devolucion == None
    ).order_by(Prestamo.fecha_asignacion.desc()).all()

    return [{
        "id":           p.id,
        "funcionario":  p.funcionario.apellidos_nombres,
        "cedula":       p.funcionario.identificacion,
        "celular":      p.funcionario.celular or "",
        "radio":        p.radio.serial,
        "modelo":       p.radio.modelo or "",
        "fecha":        p.fecha_asignacion.strftime('%d/%m/%Y %H:%M'),
        "estado":       _color_prestamo(p.fecha_asignacion, p.fecha_devolucion),
        "dias":         (datetime.utcnow() - p.fecha_asignacion).days,
    } for p in prestamos]


# ── Ruta paginada para web Flask (10 por página) ──────────────
@bp.route("/api/prestamos")
def api_prestamos():
    pagina   = request.args.get('pagina', 1, type=int)
    por_pag  = 10
    solo_activos = request.args.get('activos', 'false').lower() == 'true'

    query = Prestamo.query
    if solo_activos:
        query = query.filter(Prestamo.fecha_devolucion == None)

    total    = query.count()
    prestamos = query.order_by(
        Prestamo.fecha_asignacion.desc()
    ).offset((pagina - 1) * por_pag).limit(por_pag).all()

    return {
        "total":    total,
        "pagina":   pagina,
        "paginas":  (total + por_pag - 1) // por_pag,
        "items": [{
            "id":          p.id,
            "funcionario": p.funcionario.apellidos_nombres,
            "cedula":      p.funcionario.identificacion,
            "celular":     p.funcionario.celular or "",
            "radio":       p.radio.serial,
            "modelo":      p.radio.modelo or "",
            "fecha":       p.fecha_asignacion.strftime('%d/%m/%Y %H:%M'),
            "devolucion":  p.fecha_devolucion.strftime('%d/%m/%Y %H:%M') if p.fecha_devolucion else None,
            "estado":      _color_prestamo(p.fecha_asignacion, p.fecha_devolucion),
            "dias":        (datetime.utcnow() - p.fecha_asignacion).days,
        } for p in prestamos]
    }
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from flask import send_file
import io

@bp.route('/api/reporte/prestamos_activos')
def reporte_prestamos_activos():
    """Genera y devuelve un PDF con los préstamos activos."""
    prestamos = Prestamo.query.filter(
        Prestamo.fecha_devolucion == None
    ).order_by(Prestamo.fecha_asignacion.desc()).all()

    buffer = io.BytesIO()
    doc    = SimpleDocTemplate(buffer, pagesize=A4,
                               rightMargin=15*mm, leftMargin=15*mm,
                               topMargin=20*mm, bottomMargin=15*mm)
    styles = getSampleStyleSheet()
    story  = []

    # Título
    story.append(Paragraph(
        '<b>POLICÍA NACIONAL DE COLOMBIA — OFTIC</b>', styles['Title']))
    story.append(Paragraph(
        'GUTIC MECUC — Reporte de Préstamos Activos', styles['Normal']))
    story.append(Paragraph(
        f'Generado: {datetime.now().strftime("%d/%m/%Y %H:%M")}', styles['Normal']))
    story.append(Spacer(1, 8*mm))

    # Encabezados tabla
    data = [['Fecha', 'Funcionario', 'Cédula', 'Celular', 'Radio', 'Días']]

    for p in prestamos:
        dias = (datetime.utcnow() - p.fecha_asignacion).days
        data.append([
            p.fecha_asignacion.strftime('%d/%m/%Y'),
            p.funcionario.apellidos_nombres,
            p.funcionario.identificacion,
            p.funcionario.celular or '—',
            p.radio.serial,
            str(dias),
        ])

    t = Table(data, colWidths=[25*mm, 55*mm, 28*mm, 28*mm, 28*mm, 14*mm])
    t.setStyle(TableStyle([
        ('BACKGROUND',  (0,0), (-1,0),  colors.Color(0.1, 0.47, 0.54)),
        ('TEXTCOLOR',   (0,0), (-1,0),  colors.white),
        ('FONTNAME',    (0,0), (-1,0),  'Helvetica-Bold'),
        ('FONTSIZE',    (0,0), (-1,-1), 8),
        ('ALIGN',       (0,0), (-1,-1), 'CENTER'),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, colors.Color(0.94,0.98,0.99)]),
        ('GRID',        (0,0), (-1,-1), 0.4, colors.grey),
        ('VALIGN',      (0,0), (-1,-1), 'MIDDLE'),
        ('ROWPADDING',  (0,0), (-1,-1), 4),
    ]))
    story.append(t)

    # Total
    story.append(Spacer(1, 6*mm))
    story.append(Paragraph(f'<b>Total préstamos activos: {len(prestamos)}</b>', styles['Normal']))

    doc.build(story)
    buffer.seek(0)

    return send_file(
        buffer,
        mimetype='application/pdf',
        as_attachment=False,
        download_name='reporte_prestamos_activos.pdf'
    )


# ════════════════════════════════════════════════════════════════════════════
# ────────────────────── ENDPOINTS DE REPORTES ──────────────────────────────
# ════════════════════════════════════════════════════════════════════════════

@bp.route('/api/reportes/radios_mas_asignadas')
def reporte_radios_mas_asignados():
    """Retorna los radios que más veces han sido asignados."""
    resultado = db.session.query(
        Radio.id,
        Radio.serial,
        Radio.modelo,
        func.count(Prestamo.id).label('total_asignaciones')
    ).outerjoin(
        Prestamo, Radio.id == Prestamo.radio_id
    ).group_by(
        Radio.id
    ).order_by(
        desc('total_asignaciones')
    ).all()

    return [{
        'id': r[0],
        'serial': r[1],
        'modelo': r[2] or '',
        'total_asignaciones': r[3]
    } for r in resultado]


@bp.route('/api/reportes/funcionarios_mas_radios')
def reporte_funcionarios_mas_radios():
    """Retorna los funcionarios que más radios han recibido en préstamo."""
    resultado = db.session.query(
        Funcionario.id,
        Funcionario.identificacion,
        Funcionario.apellidos_nombres,
        Funcionario.unidad,
        func.count(Prestamo.id).label('total_prestamos')
    ).outerjoin(
        Prestamo, Funcionario.id == Prestamo.funcionario_id
    ).group_by(
        Funcionario.id
    ).order_by(
        desc('total_prestamos')
    ).all()

    return [{
        'id': r[0],
        'cedula': r[1],
        'nombre': r[2] or '',
        'unidad': r[3] or '',
        'total_prestamos': r[4]
    } for r in resultado]


@bp.route('/api/reportes/tecnicos_mas_radios')
def reporte_tecnicos_mas_radios():
    """Retorna los técnicos que más radios han entregado y recibido."""
    # Técnicos que entregan
    entrega = db.session.query(
        Tecnico.id,
        Tecnico.nombre,
        func.count(Prestamo.id).label('total_entregas')
    ).outerjoin(
        Prestamo, Tecnico.id == Prestamo.tecnico_presta_id
    ).group_by(Tecnico.id)

    # Técnicos que reciben
    recepcion = db.session.query(
        Tecnico.id,
        Tecnico.nombre,
        func.count(Prestamo.id).label('total_recepciones')
    ).outerjoin(
        Prestamo, Tecnico.id == Prestamo.tecnico_recibe_id
    ).group_by(Tecnico.id)

    # Combinar datos
    tecnicos_dict = {}
    for t_id, nombre, count in entrega.all():
        if t_id:
            tecnicos_dict[t_id] = {'id': t_id, 'nombre': nombre, 'entregas': count, 'recepciones': 0}

    for t_id, nombre, count in recepcion.all():
        if t_id:
            if t_id in tecnicos_dict:
                tecnicos_dict[t_id]['recepciones'] = count
            else:
                tecnicos_dict[t_id] = {'id': t_id, 'nombre': nombre, 'entregas': 0, 'recepciones': count}

    resultado = sorted(
        tecnicos_dict.values(),
        key=lambda x: (x['entregas'] + x['recepciones']),
        reverse=True
    )
    
    return [{
        'id': r['id'],
        'nombre': r['nombre'],
        'total_entregas': r['entregas'],
        'total_recepciones': r['recepciones'],
        'total_operaciones': r['entregas'] + r['recepciones']
    } for r in resultado]


@bp.route('/api/reportes/estadisticas')
def reporte_estadisticas():
    """Retorna estadísticas generales del sistema."""
    total_radios = db.session.query(func.count(Radio.id)).scalar() or 0
    total_funcionarios = db.session.query(func.count(Funcionario.id)).scalar() or 0
    total_tecnicos = db.session.query(func.count(Tecnico.id)).scalar() or 0
    total_prestamos = db.session.query(func.count(Prestamo.id)).scalar() or 0
    prestamos_activos = db.session.query(
        func.count(Prestamo.id)
    ).filter(Prestamo.fecha_devolucion.is_(None)).scalar() or 0
    
    prestamos_devueltos = db.session.query(
        func.count(Prestamo.id)
    ).filter(Prestamo.fecha_devolucion.isnot(None)).scalar() or 0

    radios_disponibles = db.session.query(func.count(Radio.id)).filter(
        ~Radio.id.in_(
            db.session.query(Prestamo.radio_id).filter(
                Prestamo.fecha_devolucion.is_(None)
            )
        )
    ).scalar() or 0

    radios_en_prestamo = total_radios - radios_disponibles

    return {
        'total_radios': total_radios,
        'radios_disponibles': radios_disponibles,
        'radios_en_prestamo': radios_en_prestamo,
        'total_funcionarios': total_funcionarios,
        'total_tecnicos': total_tecnicos,
        'total_prestamos': total_prestamos,
        'prestamos_activos': prestamos_activos,
        'prestamos_devueltos': prestamos_devueltos,
        'tasa_uso_radios': round((radios_en_prestamo / total_radios * 100), 2) if total_radios > 0 else 0
    }


@bp.route('/api/reportes/radios_por_unidad')
def reporte_radios_por_unidad():
    """Retorna los radios agrupados por unidad de los funcionarios que los tienen."""
    resultado = db.session.query(
        Funcionario.unidad,
        func.count(Prestamo.id).label('cantidad'),
        func.group_concat(Radio.serial).label('seriales')
    ).join(
        Prestamo, Funcionario.id == Prestamo.funcionario_id
    ).join(
        Radio, Radio.id == Prestamo.radio_id
    ).filter(
        Prestamo.fecha_devolucion.is_(None)
    ).group_by(
        Funcionario.unidad
    ).order_by(
        desc('cantidad')
    ).all()

    return [{
        'unidad': r[0] or 'SIN UNIDAD',
        'cantidad_radios': r[1],
        'seriales': r[2].split(',') if r[2] else []
    } for r in resultado]


# ════════════════════════════════════════════════════════════════════════════
# ────────────────────── ENDPOINT DE ACTUALIZACIÓN ──────────────────────────
# ════════════════════════════════════════════════════════════════════════════

@bp.route('/api/funcionario/<cedula>', methods=['PUT'])
def actualizar_funcionario(cedula):
    """Actualiza los datos de un funcionario."""
    funcionario = Funcionario.query.filter_by(identificacion=cedula).first()
    
    if not funcionario:
        return {'error': 'Funcionario no encontrado'}, 404

    data = request.json

    # Actualizar solo los campos que se proporcionen
    if 'grado' in data:
        funcionario.grado = data['grado']
    if 'apellidos_nombres' in data:
        funcionario.apellidos_nombres = data['apellidos_nombres']
    if 'unidad' in data:
        funcionario.unidad = data['unidad']
    if 'cargo' in data:
        funcionario.cargo = data['cargo']
    if 'celular' in data:
        funcionario.celular = data['celular']

    try:
        db.session.commit()
        return {
            'status': 'ok',
            'message': f'Funcionario {cedula} actualizado correctamente',
            'funcionario': {
                'cedula': funcionario.identificacion,
                'nombre': funcionario.apellidos_nombres,
                'grado': funcionario.grado,
                'unidad': funcionario.unidad,
                'cargo': funcionario.cargo,
                'celular': funcionario.celular
            }
        }, 200
    except Exception as e:
        db.session.rollback()
        return {'error': f'Error al actualizar: {str(e)}'}, 500
    


@bp.route("/radios")
def radios():
    data = Radio.query.all()

    resultado = []
    for r in data:
        resultado.append({
            "id": r.id,
            "serial": r.serial,
            "modelo": r.modelo
        })

    return jsonify(resultado)

@bp.route("/prestamos")
def prestamos():
    data = Prestamo.query.all()

    resultado = []
    for p in data:
        resultado.append({
            "id": p.id,
            "funcionario_id": p.funcionario_id,
            "radio_id": p.radio_id,
            "fecha": str(p.fecha_asignacion),
            "devuelto": p.fecha_devolucion is not None
        })

    return jsonify(resultado)