import os
from flask import Flask
from app.models import db
from app.routes import bp

def create_app():
    template_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'templates'))
    static_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'static'))
    app = Flask(__name__, template_folder=template_dir, static_folder=static_dir)

    app.config.from_object("config.Config") 

    db.init_app(app) 

    app.register_blueprint(bp) 

    return app
