from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, HRFlowable
from reportlab.lib.enums import TA_LEFT, TA_JUSTIFY, TA_CENTER
from io import BytesIO
from datetime import datetime


# ──────────────────────────────────────────────
# ESTILOS GLOBALES
# ──────────────────────────────────────────────
def _estilos():
    styles = getSampleStyleSheet()

    normal = ParagraphStyle(
        'MiNormal',
        parent=styles['Normal'],
        fontSize=9,
        leading=11,
    )
    negrita = ParagraphStyle(
        'MiNegrita',
        parent=normal,
        fontName='Helvetica-Bold',
    )
    titulo_seccion = ParagraphStyle(
        'TituloSeccion',
        parent=normal,
        fontName='Helvetica-Bold',
        fontSize=10,
        spaceAfter=4,
    )
    centrado = ParagraphStyle(
        'Centrado',
        parent=normal,
        alignment=TA_CENTER,
    )
    bullet = ParagraphStyle(
        'Bullet',
        parent=styles['Normal'],
        fontSize=9,
        leading=11,
        leftIndent=14,
        firstLineIndent=-14,
        spaceAfter=4,
        alignment=TA_JUSTIFY,
    )
    return {
        'base': styles,
        'normal': normal,
        'negrita': negrita,
        'titulo': titulo_seccion,
        'centrado': centrado,
        'bullet': bullet,
    }


# ──────────────────────────────────────────────
# HELPER: celda vacía con texto
# ──────────────────────────────────────────────
def _p(text, style):
    return Paragraph(text, style)


def _linea(label, style):
    """Retorna 'Label: ___________________' como Paragraph."""
    return Paragraph(f"{label}: {'_' * 28}", style)


# ──────────────────────────────────────────────
# ENCABEZADO INSTITUCIONAL
# ──────────────────────────────────────────────
def _tabla_encabezado(data, st):
    """
    3 columnas:
    [info doc] | [título central] | [logo / nombre institución]
    """
    col_iz = [
        _p(f"Página {data.get('pagina','1')} de {data.get('total_paginas','2')}", st['normal']),
        _p('DIRECCIONAMIENTO TECNOLÓGICO', st['normal']),
        _p(f"Código: 1DT-FR-0018", st['normal']),
        _p(f"Fecha: {data.get('fecha_doc', datetime.now().strftime('%d/%m/%Y'))}", st['normal']),
        _p(f"Versión: {data.get('version','MECUC - GUDES - GUTIC – 2.19')}", st['normal']),
    ]

    col_centro = _p(
        '<b>ASIGNACIÓN INDIVIDUAL DE<br/>ELEMENTOS TECNOLÓGICOS</b>',
        ParagraphStyle('enc_centro', parent=st['normal'], alignment=TA_CENTER, fontSize=11, leading=14)
    )

    col_der = _p('<b>POLICÍA NACIONAL</b>', ParagraphStyle(
        'enc_der', parent=st['normal'], alignment=TA_CENTER, fontName='Helvetica-Bold', fontSize=10))

    ancho_total = 174 * mm  # A4 - márgenes
    t = Table(
        [[col_iz, col_centro, col_der]],
        colWidths=[55 * mm, 79 * mm, 40 * mm],
        rowHeights=[28 * mm],
    )
    t.setStyle(TableStyle([
        ('BOX', (0, 0), (-1, -1), 0.8, colors.black),
        ('INNERGRID', (0, 0), (-1, -1), 0.5, colors.black),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('ALIGN', (1, 0), (1, 0), 'CENTER'),
        ('ALIGN', (2, 0), (2, 0), 'CENTER'),
        ('FONTSIZE', (0, 0), (-1, -1), 9),
    ]))
    return t


# ──────────────────────────────────────────────
# TABLA 1: ASIGNACIÓN DE RESPONSABLE
# ──────────────────────────────────────────────
def _tabla_responsable(data, st):
    def fila(label1, val1, label2, val2):
        return [
            _p(label1, st['normal']),
            _p(val1, st['normal']),
            _p(label2, st['normal']),
            _p(val2, st['normal']),
        ]

    d = data
    rows = [
        # Fila de encabezado (span completo)
        [_p('<b>ASIGNACIÓN DE RESPONSABLE</b>', st['negrita']), '', '', ''],
        # Lugar de asignación (span 3 columnas de valor)
        [
            _p('Lugar de asignación elemento tecnológico:', st['normal']),
            _p(d.get('lugar_asignacion', ''), st['normal']),
            '', '',
        ],
        fila('Unidad:', d.get('unidad', ''), 'Área o Grupo:', d.get('area_grupo', '')),
        fila('Grado:', d.get('grado', ''), 'Nombres y Apellidos:', d.get('nombres_apellidos', '')),
        fila('Cargo:', d.get('cargo', ''), 'No. de cédula:', d.get('cedula', '')),
        fila('Tipo de servicio:', d.get('tipo_servicio', ''), 'Teléfono de contacto:', d.get('telefono', '')),
    ]

    col_w = [42 * mm, 45 * mm, 42 * mm, 45 * mm]
    t = Table(rows, colWidths=col_w)
    t.setStyle(TableStyle([
        # Encabezado
        ('SPAN', (0, 0), (3, 0)),
        ('BACKGROUND', (0, 0), (3, 0), colors.lightgrey),
        ('ALIGN', (0, 0), (3, 0), 'CENTER'),
        # Lugar de asignación
        ('SPAN', (1, 1), (3, 1)),
        # Bordes
        ('BOX', (0, 0), (-1, -1), 0.8, colors.black),
        ('INNERGRID', (0, 0), (-1, -1), 0.4, colors.grey),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('FONTSIZE', (0, 0), (-1, -1), 9),
        ('ROWPADDING', (0, 0), (-1, -1), 3),
    ]))
    return t


# ──────────────────────────────────────────────
# TABLA 2: INFORMACIÓN ELEMENTO TECNOLÓGICO
# ──────────────────────────────────────────────
def _tabla_elemento(data, st):
    d = data
    sm = ParagraphStyle('sm', parent=st['normal'], fontSize=8, leading=10)
    sm_bold = ParagraphStyle('smb', parent=sm, fontName='Helvetica-Bold')

    encab_cols = [
        _p('<b>ÍTEM</b>', sm_bold), _p('<b>LÍNEA O ID</b>', sm_bold),
        _p('<b>DESCRIPCIÓN</b>', sm_bold), _p('<b>NÚMERO DE SERIE O IMEI</b>', sm_bold),
        _p('<b>No. INVENTARIO</b>', sm_bold), _p('<b>OPERADOR</b>', sm_bold),
        _p('<b>UNIDAD</b>', sm_bold), _p('<b>DEPENDENCIA</b>', sm_bold),
    ]

    fila_dato = [
        _p(str(d.get('item', 1)), sm),
        _p(d.get('linea_id', 'NO APLICA'), sm),
        _p(d.get('descripcion', ''), sm),
        _p(d.get('numero_serie', ''), sm),
        _p(d.get('no_inventario', 'NO APLICA'), sm),
        _p(d.get('operador', 'NO APLICA'), sm),
        _p(d.get('unidad_radio', ''), sm),
        _p(d.get('dependencia', ''), sm),
    ]

    def fila_extra(label, valor):
        """Celda única que abarca las 8 columnas: 'Label: valor'"""
        texto = f'<b>{label}:</b> {valor}'
        return [_p(texto, sm)] + ['']*7

    rows = [
        [_p('<b>INFORMACIÓN ELEMENTO TECNOLÓGICO</b>', sm_bold)] + ['']*7,
        encab_cols,
        fila_dato,
        fila_extra('Información adicional', d.get('info_adicional', 'NO APLICA')),
        fila_extra('Accesorios', d.get('accesorios', '')),
        fila_extra('Observaciones', d.get('observaciones', '')),
    ]

    colw = [10*mm, 20*mm, 28*mm, 28*mm, 24*mm, 24*mm, 20*mm, 20*mm]
    t = Table(rows, colWidths=colw, repeatRows=2)
    t.setStyle(TableStyle([
        ('SPAN', (0, 0), (7, 0)),
        ('BACKGROUND', (0, 0), (7, 0), colors.lightgrey),
        ('ALIGN', (0, 0), (7, 0), 'CENTER'),
        ('BACKGROUND', (0, 1), (7, 1), colors.Color(0.88, 0.88, 0.88)),
        ('ALIGN', (0, 1), (7, 1), 'CENTER'),
        # Filas extra: celda única de col 0 a 7
        ('SPAN', (0, 3), (7, 3)),
        ('SPAN', (0, 4), (7, 4)),
        ('SPAN', (0, 5), (7, 5)),
        # Bordes
        ('BOX', (0, 0), (-1, -1), 0.8, colors.black),
        ('INNERGRID', (0, 0), (-1, -1), 0.4, colors.grey),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('FONTSIZE', (0, 0), (-1, -1), 8),
        ('ROWPADDING', (0, 0), (-1, -1), 3),
    ]))
    return t


# ──────────────────────────────────────────────
# RECOMENDACIONES Y COMPROMISOS
# ──────────────────────────────────────────────
RECOMENDACIONES = [
    "Con el fin de garantizar el adecuado funcionamiento de los elementos tecnológicos asignados, se recomienda seguir las instrucciones y recomendaciones contenidas en el manual de usuario.",
    "Los jefes de Grupo de Tecnologías de la Información y las Comunicaciones deberán impartir instrucción a los responsables de los equipos tecnológicos, ya que está prohibido realizar cambio de las claves y configuración a otras cuentas, diferentes a las asignadas desde la Oficina de Tecnologías de la Información y las Comunicaciones.",
    "Será responsabilidad del funcionario depositario del bien, el cuidado, administración y custodia de los elementos, por tal motivo cualquier daño, o perdida de los mismos, exceptuando causas de desgaste natural por uso, su responsabilidad subsanarlos; así mismo informar cualquier cambio o movimiento del elemento a otra dependencia por novedades administrativas, a los funcionarios del Grupo de Tecnologías de la Información y las Comunicaciones en cada unidad, con el fin de proceder a realizar los ajustes y actualizaciones respectivos en los inventarios.",
    "Sustituir los accesorios deteriorados únicamente con los autorizados por el fabricante.",
    "Disponer la utilización del equipo para actividades propias de la institución y/o servicio.",
    "En caso de inmersión, apagar el equipo y solicitar la asistencia y asesoría técnica del personal autorizado.",
    'La Ley 599 del 24/07/2000 "Por la cual se expide el Código Penal.", determina como delito en su Título XV Delitos contra la administración pública, Capítulo Primero (del peculado), aquellos actos en donde el servidor público se apropie en provecho suyo o de un tercero de bienes del Estado o de empresas o instituciones en que éste tenga parte o de bienes o fondos parafiscales, o de bienes de particulares cuya administración, tenencia o custodia se le haya confiado por razón o con ocasión de sus funciones.',
    'La Ley 1407 de 2010 "Por la cual se expide el Código Penal Militar" define el delito de Peculado sobre bienes de dotación, en el cual incurre el servidor público que se apropie en provecho suyo o de un tercero de bienes de dotación que se le hayan confiado o entregado por un título no traslaticio de dominio.',
    'La Ley 1476 del 19/07/2011 "Por la cual se expide el régimen de responsabilidad administrativa por pérdida o daño de bienes de propiedad o al servicio del Ministerio de Defensa Nacional, sus entidades adscritas o vinculadas o la Fuerza Pública".',
    'La Ley 2196 del 18/01/2022 "Por medio de la cual se expide el estatuto disciplinario policial", establece en el artículo 45 (faltas gravísimas) numeral 22. Respecto de los bienes de la Policía Nacional, o de otros puestos bajo su responsabilidad, uso, custodia, administración o transporte.',
    'La Resolución 05884 del 27/12/2019 "Por la cual se expide el Manual para la administración de los Recursos Logísticos de la Policía Nacional de Colombia", Capítulo 8. Subcomponente Tecnologías de la Información y las Comunicaciones, numeral 8.5. Administración servicios tecnológicos de telefonía móvil celular, push to talk y fija.',
]


# ──────────────────────────────────────────────
# TABLA DE FIRMAS  (Recibe | Huella | Entrega)
# ──────────────────────────────────────────────
def _tabla_firmas(data, firma_png_bytes, st):
    d = data
    sm = ParagraphStyle('sm2', parent=st['normal'], fontSize=9, leading=13)
    sm_c = ParagraphStyle('sm_c', parent=sm, alignment=TA_CENTER, fontName='Helvetica-Bold')

    LINEA = '_' * 30

    def bloque_firma(titulo, datos_campo):
        """Construye el contenido de una celda de firma."""
        items = [_p(f'<b>{titulo}</b>', sm_c), Spacer(1, 18*mm)]
        for label in datos_campo:
            items.append(_p(f'{label}: {LINEA}', sm))
            items.append(Spacer(1, 2))
        return items

    # Imagen de firma si existe
    if firma_png_bytes:
        firma_img = Image(BytesIO(firma_png_bytes), width=50*mm, height=20*mm)
    else:
        firma_img = Spacer(1, 20*mm)

    # Datos del funcionario que RECIBE
    grado_recibe  = d.get('grado', '')
    cargo_recibe  = d.get('cargo', '')
    nombre_recibe = d.get('nombres_apellidos', '')

    # Datos del técnico que ENTREGA
    tecnico_nombre = d.get('tecnico_presta', '')
    tecnico_grado  = d.get('tecnico_grado', '')
    tecnico_cargo  = d.get('tecnico_cargo', '')

    recibe_content = [
        _p('<b>Recibe:</b>', sm_c),
        Spacer(1, 2*mm),
        firma_img,
        Spacer(1, 2*mm),
        _p(f'<b>Nombre:</b> {nombre_recibe}', sm),
        _p(f'<b>Grado:</b> {grado_recibe}', sm),
        _p(f'<b>Cargo:</b> {cargo_recibe}', sm),
        _p(f'Firma: {LINEA}', sm),
        _p(f'Postfirma: {LINEA}', sm),
    ]

    huella_content = [
        _p('<b>HUELLA DACTILAR DEL QUE RECIBE</b>',
           ParagraphStyle('hc', parent=sm, alignment=TA_CENTER, fontSize=8, leading=10)),
        Spacer(1, 30*mm),
    ]

    entrega_content = [
        _p('<b>Entrega:</b>', sm_c),
        Spacer(1, 2*mm),
        Spacer(1, 20*mm),
        Spacer(1, 2*mm),
        _p(f'<b>Nombre:</b> {tecnico_nombre}', sm),
        _p(f'<b>Grado:</b> {tecnico_grado}', sm),
        _p(f'<b>Cargo:</b> {tecnico_cargo}', sm),
        _p(f'Firma: {LINEA}', sm),
        _p(f'Postfirma: {LINEA}', sm),
    ]

    # Convertimos listas de flowables a tablas internas de 1 col para poder
    # usarlas dentro de celdas de la tabla principal
    def _inner(contents, w):
        inner = Table([[c] for c in contents], colWidths=[w])
        inner.setStyle(TableStyle([
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('LEFTPADDING', (0, 0), (-1, -1), 2),
            ('RIGHTPADDING', (0, 0), (-1, -1), 2),
        ]))
        return inner

    w_recibe = 68*mm
    w_huella = 38*mm
    w_entrega = 68*mm

    t = Table(
        [[_inner(recibe_content, w_recibe),
          _inner(huella_content, w_huella),
          _inner(entrega_content, w_entrega)]],
        colWidths=[w_recibe, w_huella, w_entrega],
    )
    t.setStyle(TableStyle([
        ('BOX', (0, 0), (-1, -1), 0.8, colors.black),
        ('INNERGRID', (0, 0), (-1, -1), 0.5, colors.black),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
    ]))
    return t


# ──────────────────────────────────────────────
# FUNCIÓN PRINCIPAL
# ──────────────────────────────────────────────
def generar_pdf_1dt_fr_0018(data: dict, firma_png_bytes: bytes, output_path: str):
    """
    Genera el formulario 1DT-FR-0018 fiel al documento oficial de la Policía Nacional.

    Args:
        data: Diccionario con los campos del formulario.
        firma_png_bytes: Bytes PNG de la firma (puede ser None).
        output_path: Ruta del archivo PDF a generar.
    """
    buffer = BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        rightMargin=18*mm, leftMargin=18*mm,
        topMargin=16*mm, bottomMargin=16*mm,
    )

    st = _estilos()
    Story = []

    # 1. ENCABEZADO INSTITUCIONAL
    Story.append(_tabla_encabezado(data, st))
    Story.append(Spacer(1, 4*mm))

    # 2. Versión / metadatos debajo del encabezado
    Story.append(_p(f"<b>{data.get('version', 'MECUC - GUDES - GUTIC – 2.19')}</b>", st['normal']))
    Story.append(Spacer(1, 2*mm))
    Story.append(_p(f"<b>Fecha:</b> {'_' * 30}", st['normal']))
    Story.append(Spacer(1, 4*mm))

    # 3. TABLA ASIGNACIÓN DE RESPONSABLE
    Story.append(_tabla_responsable(data, st))
    Story.append(Spacer(1, 4*mm))

    # 4. TABLA INFORMACIÓN ELEMENTO TECNOLÓGICO
    Story.append(_tabla_elemento(data, st))
    Story.append(Spacer(1, 4*mm))

    # 5. RECOMENDACIONES Y COMPROMISOS
    Story.append(_p('<b>RECOMENDACIONES Y COMPROMISOS:</b>', st['titulo']))
    Story.append(Spacer(1, 2*mm))
    for texto in RECOMENDACIONES:
        Story.append(Paragraph(f'\u2713  {texto}', st['bullet']))

    Story.append(Spacer(1, 6*mm))

    # 6. TABLA DE FIRMAS
    Story.append(_tabla_firmas(data, firma_png_bytes, st))
    Story.append(Spacer(1, 6*mm))

    # 7. INFORMACIÓN PÚBLICA
    Story.append(_p('<b>INFORMACIÓN PÚBLICA</b>', ParagraphStyle(
        'ip', parent=st['normal'], alignment=TA_CENTER, fontName='Helvetica-Bold', fontSize=10)))

    # Construir y guardar
    doc.build(Story)
    with open(output_path, 'wb') as f:
        f.write(buffer.getvalue())
    return output_path


# ──────────────────────────────────────────────
# EJEMPLO DE USO
# ──────────────────────────────────────────────
if __name__ == '__main__':
    data = {
        'pagina': '1',
        'total_paginas': '2',
        'fecha_doc': datetime.now().strftime('%d/%m/%Y'),
        'version': 'MECUC - GUDES - GUTIC – 2.19',
        'lugar_asignacion': 'GUTIC MECUC',
        'unidad': 'Unidad Especial',
        'area_grupo': 'Grupo de TIC',
        'grado': 'Subintendente',
        'nombres_apellidos': 'Juan Pérez García',
        'cargo': 'Analista de Sistemas',
        'cedula': '1234567890',
        'tipo_servicio': 'Permanente',
        'telefono': '3001234567',
        'item': 1,
        'linea_id': 'NO APLICA',
        'descripcion': 'Laptop Dell XPS 13',
        'numero_serie': 'ABC123XYZ',
        'no_inventario': 'NO APLICA',
        'operador': 'NO APLICA',
        'unidad_radio': 'UNI-001',
        'dependencia': 'Dirección de TIC',
        'info_adicional': 'NO APLICA',
        'accesorios': 'Cargador, Mouse, Maletín',
        'observaciones': 'Equipo en buen estado',
        'tecnico_presta': 'Carlos López',
        'tecnico_grado': 'Intendente',
        'tecnico_cargo': 'Técnico de TIC',
    }

    salida = generar_pdf_1dt_fr_0018(data, None, '/mnt/user-data/outputs/1DT-FR-0018_generado.pdf')
    print(f'✅ PDF generado: {salida}')
