from app import create_app
from app.models import db, Usuario, Tecnico

app = create_app()

with app.app_context():
    tecnico = Tecnico.query.first()

    if not tecnico:
        print("❌ No hay técnicos registrados.")
    else:
        user = Usuario.query.filter_by(usuario="admin").first()

        if user:
            # Si ya existe, resetea la contraseña
            user.set_password("1234")
            db.session.commit()
            print("✅ Contraseña de admin actualizada a 1234")
        else:
            user = Usuario(usuario="admin", tecnico=tecnico)
            user.set_password("1234")
            db.session.add(user)
            db.session.commit()
            print("✅ Usuario admin creado correctamente")