import os

class Config:
    # Clave secreta para sesiones y CSRF
    SECRET_KEY = os.environ.get('SECRET_KEY', 'SINAR-GUTIC-MECUC-2026')
    
    # Base de datos
    SQLALCHEMY_DATABASE_URI = "mysql+pymysql://root:@localhost/prestamos_radios"
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # Directorio de descargas
    BASE_DOWNLOAD = os.path.join(os.path.expanduser('~'), 'Downloads', 'prestamos_radios')

# Crear directorio de descargas si no existe
os.makedirs(Config.BASE_DOWNLOAD, exist_ok=True)