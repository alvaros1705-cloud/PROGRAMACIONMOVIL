import pandas as pd
import pymysql

# ===== CONEXION A MYSQL (XAMPP) =====
conexion = pymysql.connect(
    host="localhost",
    user="root",
    password="",
    database="prestamos_radios"
)

cursor = conexion.cursor()

# ===== ARCHIVO EXCEL =====
archivo = "LIBRO CONTROL PRESTAMO DE RADIOS MECUC.xlsm"

df = pd.read_excel(archivo, sheet_name="BD")

contador = 0

for _, row in df.iterrows():
    cedula = str(row["IDENTIFICACION"]).strip()

    if cedula == "nan":
        continue

    # ===== EVITAR DUPLICADOS =====
    cursor.execute(
        "SELECT id FROM funcionarios WHERE identificacion=%s",
        (cedula,)
    )
    existe = cursor.fetchone()

    if existe:
        continue

    # ===== INSERTAR =====
    
    sql = """
        
        INSERT INTO funcionarios 
        (identificacion, grado, apellidos_nombres, unidad, cargo, celular)

        VALUES (%s, %s, %s, %s, %s, %s)
        """


    valores = (
        cedula,
        str(row["GR"]),
        str(row["APELLIDOS Y NOMBRES"]),
        str(row["UNIDAD"]),
        str(row["CARGO"]),
        str(row["NRO CELULAR"])
    )

    cursor.execute(sql, valores)
    contador += 1

conexion.commit()
cursor.close()
conexion.close()

print(f"✅ FUNCIONARIOS INSERTADOS: {contador}")