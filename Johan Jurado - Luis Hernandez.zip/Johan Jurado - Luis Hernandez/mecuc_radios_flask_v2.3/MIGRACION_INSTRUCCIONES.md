# 🔄 Instrucciones de Migración de Datos - EXCEL a XAMPP

## Resumen de Cambios Realizados

### 1. **Correcciones en Modelos** (`app/models.py`)
- ✅ Corregido: `Funcionario.nombres` → `Funcionario.apellidos_nombres` (coincide con el Excel)
- ✅ Agregado: `Radio.observaciones` (faltaba esta columna)
- ✅ Modelo `Prestamo`: Confirmado uso correcto de `accesorios_radio` y `novedades`

### 2. **Correcciones en Scripts de Importación**
- ✅ `importar_funcionarios.py`: Cambiado `nombres` → `apellidos_nombres` en SQL
- ✅ `importar_radios.py`: Ya estaba correcto
- ✅ `importar_tecnicos.py`: Ya estaba correcto
- ✅ `importar_prestamos.py`: 
  - Cambiado `accesorios_entregados` → `accesorios_radio`
  - Cambiado columna `observaciones` → `novedades`

### 3. **Dependencias**
- ✅ Agregado: `PyMySQL==1.1.0` en `requirements.txt`

---

## 📋 PASOS PARA EJECUTAR LA MIGRACIÓN

### Paso 1: Instalar dependencias
```bash
pip install -r requirements.txt
```

### Paso 2: Crear migraciones de SQLAlchemy (OPCIONAL - solo si es la primera vez)
```bash
flask db init        # Si no existe la carpeta migrations
flask db migrate -m "Agregar columnas a modelos"
flask db upgrade     # Aplicar cambios a la BD
```

### Paso 3: Ejecutar migración completa (RECOMENDADO)
```bash
python migracion_completa.py
```

**Esto hará automáticamente:**
1. ✅ Crear/ejecutar migraciones Flask
2. ✅ Importar Funcionarios
3. ✅ Importar Técnicos
4. ✅ Importar Radios
5. ✅ Importar Préstamos

### Alternativa: Ejecutar scripts individuales

Si prefieres hacerlo paso a paso:

```bash
# 1. Funcionarios
python importar_funcionarios.py

# 2. Técnicos
python importar_tecnicos.py

# 3. Radios
python importar_radios.py

# 4. Préstamos
python importar_prestamos.py
```

---

## ⚙️ Verificación en phpMyAdmin

Después de la migración, verifica en http://localhost/phpmyadmin/:

```sql
-- Tabla funcionarios
SELECT COUNT(*) FROM prestamos_radios.funcionarios;

-- Tabla tecnicos
SELECT COUNT(*) FROM prestamos_radios.tecnicos;

-- Tabla radios
SELECT COUNT(*) FROM prestamos_radios.radios;

-- Tabla prestamos
SELECT COUNT(*) FROM prestamos_radios.prestamos;

-- Ver estructura de radios (verificar columna observaciones)
DESCRIBE prestamos_radios.radios;

-- Ver estructura de funcionarios (verificar apellidos_nombres)
DESCRIBE prestamos_radios.funcionarios;
```

---

## 🔍 Troubleshooting

### Error: "The session is unavailable because no secret key was set"
**Solución**: Ya está corregido en `config.py`. No necesitas hacer nada.

### Error: "Template not found"
**Solución**: Ya está corregido en `app/__init__.py`. Las rutas de templates son correctas.

### Error de Conexión MySQL
```
RuntimeError: Unknown MySQL server host
```
**Solución**: 
- Asegúrate que XAMPP esté corriendo
- Abre phpMyAdmin en http://localhost/phpmyadmin/
- La BD `prestamos_radios` debe existir

### Error: Tabla no tiene columna X
**Solución**: Ejecuta las migraciones:
```bash
flask db upgrade
```

---

## 📊 Estructura Final de Base de Datos

```
prestamos_radios
├── funcionarios
│   ├── id (INT, PK)
│   ├── identificacion (VARCHAR 20, UNIQUE)
│   ├── grado (VARCHAR 20)
│   ├── apellidos_nombres (VARCHAR 120) ← CORREGIDO
│   ├── unidad (VARCHAR 120)
│   ├── cargo (VARCHAR 120)
│   └── celular (VARCHAR 30)
│
├── tecnicos
│   ├── id (INT, PK)
│   ├── nombre (VARCHAR 120)
│   ├── grado (VARCHAR 20)
│   ├── cargo (VARCHAR 120)
│   └── correo (VARCHAR 120)
│
├── radios
│   ├── id (INT, PK)
│   ├── serial (VARCHAR 50, UNIQUE)
│   ├── modelo (VARCHAR 80)
│   ├── accesorios (TEXT)
│   └── observaciones (TEXT) ← AGREGADO
│
├── prestamos
│   ├── id (INT, PK)
│   ├── funcionario_id (INT, FK)
│   ├── radio_id (INT, FK)
│   ├── tecnico_presta_id (INT, FK)
│   ├── tecnico_recibe_id (INT, FK)
│   ├── fecha_asignacion (DATETIME)
│   ├── fecha_devolucion (DATETIME)
│   ├── accesorios_radio (VARCHAR 500)
│   └── novedades (VARCHAR 500)
│
└── usuarios
    ├── id (INT, PK)
    ├── usuario (VARCHAR 50, UNIQUE)
    └── password_hash (VARCHAR 255)
```

---

## ✅ Próximos Pasos

Después de ejecutar la migración:

1. **Reinicia Flask**:
   ```bash
   python app.py
   ```

2. **Accede a http://localhost:5000/login**

3. **Las rutas API deberían funcionar correctamente**:
   - GET `/api/funcionarios`
   - GET `/api/tecnicos`
   - GET `/api/radios_disponibles`
   - POST `/api/prestamo`
   - GET `/api/prestamos`

---

## 📝 Notas

- Los scripts ahora son **idempotentes**: pueden ejecutarse múltiples veces sin duplicar datos
- Se usa **LIKE** para búsqueda de técnicos por si hay espacios extra
- Las **fechas se preservan** del Excel automáticamente
- Los scripts incluyen **manejo de errores** por fila

¡Listo! 🎉
