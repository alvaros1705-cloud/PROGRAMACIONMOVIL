#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Script para agregar columnas faltantes a la tabla prestamos
"""

import pymysql

print("=" * 80)
print("AGREGANDO COLUMNAS FALTANTES A TABLA PRESTAMOS")
print("=" * 80)

try:
    conexion = pymysql.connect(
        host="localhost",
        user="root",
        password="",
        database="prestamos_radios"
    )
    cursor = conexion.cursor()
    print("✅ Conexión exitosa")

    # Verificar si la columna accesorios_radio existe
    cursor.execute("""
        SELECT COLUMN_NAME 
        FROM INFORMATION_SCHEMA.COLUMNS 
        WHERE TABLE_NAME = 'prestamos' AND COLUMN_NAME = 'accesorios_radio'
    """)
    
    if not cursor.fetchone():
        print("\n➕ Agregando columna accesorios_radio...")
        cursor.execute("""
            ALTER TABLE prestamos 
            ADD COLUMN accesorios_radio VARCHAR(500) DEFAULT NULL
        """)
        print("✅ Columna accesorios_radio agregada")
    else:
        print("✓ Columna accesorios_radio ya existe")

    # Verificar si la columna novedades existe
    cursor.execute("""
        SELECT COLUMN_NAME 
        FROM INFORMATION_SCHEMA.COLUMNS 
        WHERE TABLE_NAME = 'prestamos' AND COLUMN_NAME = 'novedades'
    """)
    
    if not cursor.fetchone():
        print("➕ Agregando columna novedades...")
        cursor.execute("""
            ALTER TABLE prestamos 
            ADD COLUMN novedades VARCHAR(500) DEFAULT NULL
        """)
        print("✅ Columna novedades agregada")
    else:
        print("✓ Columna novedades ya existe")

    # Verificar si firma_devolucion existe (opcional)
    cursor.execute("""
        SELECT COLUMN_NAME 
        FROM INFORMATION_SCHEMA.COLUMNS 
        WHERE TABLE_NAME = 'prestamos' AND COLUMN_NAME = 'firma_devolucion'
    """)
    
    if not cursor.fetchone():
        print("➕ Agregando columna firma_devolucion...")
        cursor.execute("""
            ALTER TABLE prestamos 
            ADD COLUMN firma_devolucion LONGBLOB DEFAULT NULL
        """)
        print("✅ Columna firma_devolucion agregada")
    else:
        print("✓ Columna firma_devolucion ya existe")

    conexion.commit()
    cursor.close()
    conexion.close()

    print("\n" + "=" * 80)
    print("✅ PROCESO COMPLETADO")
    print("=" * 80)
    print("\nLa tabla prestamos está lista. Reinicia Flask para continuar.")

except Exception as e:
    print(f"\n❌ ERROR: {e}")
    import traceback
    traceback.print_exc()
