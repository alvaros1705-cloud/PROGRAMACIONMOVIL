import pandas as pd
from datetime import datetime
import base64

from app import create_app
from app.models import db, Funcionario, Radio, Tecnico, Prestamo

# ===== CONFIG =====
ARCHIVO = "LIBRO CONTROL PRESTAMO DE RADIOS MECUC.xlsm"

app = create_app()

def limpiar(valor):
    if pd.isna(valor):
        return ""
    return str(valor).strip()

with app.app_context():
    print("🔄 Iniciando importación...")

    # =====================================
    # 1. IMPORTAR FUNCIONARIOS (HOJA BD)
    # =====================================
    df_func = pd.read_excel(ARCHIVO, sheet_name="BD")

    for _, row in df_func.iterrows():
        cedula = limpiar(row.get("IDENTIFICACION"))

        if not cedula:
            continue

        existe = Funcionario.query.filter_by(identificacion=cedula).first()
        if existe:
            continue

        f = Funcionario(
            identificacion=cedula,
            grado=limpiar(row.get("GR")),
            apellidos_nombres=limpiar(row.get("APELLIDOS Y NOMBRES")),
            unidad=limpiar(row.get("UNIDAD")),
            cargo=limpiar(row.get("CARGO")),
            celular=limpiar(row.get("NRO CELULAR")),
        )
        db.session.add(f)

    db.session.commit()
    print("✅ Funcionarios importados")

    # =====================================
    # 2. IMPORTAR RADIOS
    # =====================================
    df_radios = pd.read_excel(ARCHIVO, sheet_name="RADIOS")

    for _, row in df_radios.iterrows():
        serial = limpiar(row.get("SERIE"))

        if not serial:
            continue

        existe = Radio.query.filter_by(serial=serial).first()
        if existe:
            continue

        r = Radio(
            serial=serial,
            modelo=limpiar(row.get("MODELO")),
            accesorios=limpiar(row.get("ACCESORIOS")),
            observaciones=limpiar(row.get("OBSERVACIONES")),
        )
        db.session.add(r)

    db.session.commit()
    print("✅ Radios importados")

    # =====================================
    # 3. IMPORTAR LIBRO CONTROL (PRÉSTAMOS)
    # =====================================
    df_libro = pd.read_excel(ARCHIVO, sheet_name="LIBRO_CONTROL")

    for _, row in df_libro.iterrows():
        try:
            cedula = limpiar(row.get("NRO DE CEDULA"))
            serial = limpiar(row.get("SERIAL DEL RADIO"))
            tecnico_presta_nombre = limpiar(row.get("TECNICO QUE PRESTA EL RADIO"))
            tecnico_recibe_nombre = limpiar(row.get("TECNICO QUE RECIBE"))

            if not cedula or not serial:
                continue

            # ===== FUNCIONARIO =====
            funcionario = Funcionario.query.filter_by(
                identificacion=cedula
            ).first()

            if not funcionario:
                funcionario = Funcionario(
                    identificacion=cedula,
                    grado=limpiar(row.get("GRADO")),
                    apellidos_nombres=limpiar(row.get("APELLIDOS Y NOMBRES")),
                    unidad=limpiar(row.get("UNIDAD")),
                    celular=limpiar(row.get("NRO DE CELULAR")),
                    cargo=""
                )
                db.session.add(funcionario)
                db.session.flush()

            # ===== RADIO =====
            radio = Radio.query.filter_by(serial=serial).first()

            if not radio:
                radio = Radio(
                    serial=serial,
                    modelo=limpiar(row.get("MODELO DEL RADIO")),
                    accesorios=limpiar(row.get("ACCESORIOS")),
                    observaciones=limpiar(row.get("OBSERVACIONES")),
                )
                db.session.add(radio)
                db.session.flush()

            # ===== TECNICO PRESTA =====
            tecnico_presta = Tecnico.query.filter_by(
                nombre=tecnico_presta_nombre
            ).first()

            if not tecnico_presta:
                tecnico_presta = Tecnico(nombre=tecnico_presta_nombre)
                db.session.add(tecnico_presta)
                db.session.flush()

            # ===== TECNICO RECIBE =====
            tecnico_recibe = None
            if tecnico_recibe_nombre:
                tecnico_recibe = Tecnico.query.filter_by(
                    nombre=tecnico_recibe_nombre
                ).first()

                if not tecnico_recibe:
                    tecnico_recibe = Tecnico(nombre=tecnico_recibe_nombre)
                    db.session.add(tecnico_recibe)
                    db.session.flush()

            # ===== FECHAS =====
            fecha_asignacion = row.get("FECHA DE ASIGNACION")
            fecha_devolucion = row.get("FECHA DE DEVOLUCION")

            if pd.isna(fecha_asignacion):
                continue

            # ===== VALIDAR DUPLICADO =====
            existe = Prestamo.query.filter_by(
                funcionario_id=funcionario.id,
                radio_id=radio.id,
                fecha_asignacion=fecha_asignacion
            ).first()

            if existe:
                continue

            # ===== CREAR PRESTAMO =====
            prestamo = Prestamo(
                funcionario_id=funcionario.id,
                radio_id=radio.id,
                tecnico_presta_id=tecnico_presta.id,
                tecnico_recibe_id=tecnico_recibe.id if tecnico_recibe else None,
                fecha_asignacion=fecha_asignacion,
                fecha_devolucion=fecha_devolucion if not pd.isna(fecha_devolucion) else None,
                accesorios_radio=limpiar(row.get("ACCESORIOS")),
                novedades=limpiar(row.get("OBSERVACIONES")),
                firma=None,  # Excel no tiene firma digital usable
                firma_devolucion=None
            )

            db.session.add(prestamo)

        except Exception as e:
            print(f"⚠️ Error en fila: {e}")
            continue

    db.session.commit()
    print("✅ Préstamos importados")

    print("🎉 IMPORTACIÓN COMPLETA FINALIZADA")