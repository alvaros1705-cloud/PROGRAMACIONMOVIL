import pandas as pd
import pymysql

# ===== CONEXIÓN MYSQL =====
conexion = pymysql.connect(
    host="localhost",
    user="root",
    password="",
    database="prestamos_radios"
)

cursor = conexion.cursor()

# ===== ARCHIVO =====
archivo = "LIBRO CONTROL PRESTAMO DE RADIOS MECUC.xlsm"

# ===== HOJA TECNICOS =====
df = pd.read_excel(archivo, sheet_name="TECNICOS")

contador = 0

for _, row in df.iterrows():

    grado = str(row["GRADO"]).strip()
    nombre = str(row["NOMBRE"]).strip()
    cargo = str(row["CARGO"]).strip()
    correo = str(row["CORREO"]).strip()

    if nombre == "nan" or nombre == "":
        continue

    # ===== EVITAR DUPLICADOS =====
    cursor.execute(
        "SELECT id FROM tecnicos WHERE nombre=%s",
        (nombre,)
    )
    existe = cursor.fetchone()

    if existe:
        continue

    # ===== INSERT =====
    sql = """
    INSERT INTO tecnicos (grado, nombre, cargo, correo)
    VALUES (%s, %s, %s, %s)
    """

    cursor.execute(sql, (grado, nombre, cargo, correo))

    contador += 1

# ===== GUARDAR =====
conexion.commit()
cursor.close()
conexion.close()

print(f"✅ TECNICOS INSERTADOS: {contador}")