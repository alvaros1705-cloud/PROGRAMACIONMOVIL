#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Script maestro de migración desde Excel a XAMPP
Realiza migraciones de BD y luego importa datos en orden
"""

import os
import sys
import subprocess
import pandas as pd
import pymysql
from datetime import datetime

print("=" * 80)
print("INICIANDO MIGRACIÓN COMPLETA DESDE EXCEL A XAMPP")
print("=" * 80)

# ============================================================================
# PASO 1: CREAR MIGRACIONES Y ACTUALIZAR BD
# ============================================================================
print("\n📋 PASO 1: Actualizando esquema de base de datos...")

try:
    # Crear migración
    result = subprocess.run(
        ["flask", "db", "migrate", "-m", "Agregar columnas observaciones y apellidos_nombres"],
        capture_output=True,
        text=True
    )
    print("✓ Migración creada")
    
    # Aplicar migración
    result = subprocess.run(
        ["flask", "db", "upgrade"],
        capture_output=True,
        text=True
    )
    print("✓ Esquema actualizado")
except Exception as e:
    print(f"⚠️ Advertencia en migraciones: {e}")

# ============================================================================
# PASO 2: CONEXIÓN A MYSQL
# ============================================================================
print("\n📌 PASO 2: Conectando a base de datos XAMPP...")

try:
    conexion = pymysql.connect(
        host="localhost",
        user="root",
        password="",
        database="prestamos_radios"
    )
    cursor = conexion.cursor()
    print("✅ Conexión exitosa a MySQL")
except Exception as e:
    print(f"❌ ERROR: No se pudo conectar a MySQL: {e}")
    sys.exit(1)

# ============================================================================
# FUNCIÓN AUXILIAR
# ============================================================================
def limpiar(valor):
    """Limpia valores de celdas Excel"""
    if pd.isna(valor):
        return ""
    return str(valor).strip()

# ============================================================================
# PASO 3: IMPORTAR FUNCIONARIOS
# ============================================================================
print("\n👥 PASO 3: Importando FUNCIONARIOS...")

archivo = "LIBRO CONTROL PRESTAMO DE RADIOS MECUC.xlsm"

try:
    df = pd.read_excel(archivo, sheet_name="BD")
    contador = 0

    for _, row in df.iterrows():
        cedula = limpiar(row["IDENTIFICACION"])

        if not cedula or cedula == "nan":
            continue

        # Evitar duplicados
        cursor.execute(
            "SELECT id FROM funcionarios WHERE identificacion=%s",
            (cedula,)
        )
        if cursor.fetchone():
            continue

        sql = """
            INSERT INTO funcionarios 
            (identificacion, grado, apellidos_nombres, unidad, cargo, celular)
            VALUES (%s, %s, %s, %s, %s, %s)
        """

        valores = (
            cedula,
            limpiar(row["GR"]),
            limpiar(row["APELLIDOS Y NOMBRES"]),
            limpiar(row["UNIDAD"]),
            limpiar(row["CARGO"]),
            limpiar(row["NRO CELULAR"])
        )

        try:
            cursor.execute(sql, valores)
            contador += 1
        except Exception as e:
            print(f"⚠️ Error en funcionario {cedula}: {e}")

    conexion.commit()
    print(f"✅ {contador} funcionarios importados")

except Exception as e:
    print(f"❌ Error importando funcionarios: {e}")
    conexion.rollback()

# ============================================================================
# PASO 4: IMPORTAR TÉCNICOS
# ============================================================================
print("\n🔧 PASO 4: Importando TÉCNICOS...")

try:
    df = pd.read_excel(archivo, sheet_name="TECNICOS")
    contador = 0

    for _, row in df.iterrows():
        nombre = limpiar(row["NOMBRE"])

        if not nombre or nombre == "nan":
            continue

        # Evitar duplicados
        cursor.execute(
            "SELECT id FROM tecnicos WHERE nombre=%s",
            (nombre,)
        )
        if cursor.fetchone():
            continue

        sql = """
            INSERT INTO tecnicos (grado, nombre, cargo, correo)
            VALUES (%s, %s, %s, %s)
        """

        valores = (
            limpiar(row["GRADO"]),
            nombre,
            limpiar(row["CARGO"]),
            limpiar(row["CORREO"])
        )

        try:
            cursor.execute(sql, valores)
            contador += 1
        except Exception as e:
            print(f"⚠️ Error en técnico {nombre}: {e}")

    conexion.commit()
    print(f"✅ {contador} técnicos importados")

except Exception as e:
    print(f"❌ Error importando técnicos: {e}")
    conexion.rollback()

# ============================================================================
# PASO 5: IMPORTAR RADIOS
# ============================================================================
print("\n📻 PASO 5: Importando RADIOS...")

try:
    df = pd.read_excel(archivo, sheet_name="RADIOS")
    contador = 0

    for _, row in df.iterrows():
        serial = limpiar(row["SERIE"])

        if not serial or serial == "nan":
            continue

        # Evitar duplicados
        cursor.execute(
            "SELECT id FROM radios WHERE serial=%s",
            (serial,)
        )
        if cursor.fetchone():
            continue

        sql = """
            INSERT INTO radios 
            (serial, modelo, accesorios, observaciones)
            VALUES (%s, %s, %s, %s)
        """

        valores = (
            serial,
            limpiar(row["MODELO"]),
            limpiar(row["ACCESORIOS"]),
            limpiar(row["OBSERVACIONES"])
        )

        try:
            cursor.execute(sql, valores)
            contador += 1
        except Exception as e:
            print(f"⚠️ Error en radio {serial}: {e}")

    conexion.commit()
    print(f"✅ {contador} radios importados")

except Exception as e:
    print(f"❌ Error importando radios: {e}")
    conexion.rollback()

# ============================================================================
# PASO 6: IMPORTAR PRÉSTAMOS
# ============================================================================
print("\n📋 PASO 6: Importando PRÉSTAMOS...")

try:
    df = pd.read_excel(archivo, sheet_name="LIBRO_CONTROL")
    contador = 0

    for idx, row in df.iterrows():
        try:
            cedula = limpiar(row["NRO DE CEDULA"])
            serial = limpiar(row["SERIAL DEL RADIO"])
            tecnico_presta_nom = limpiar(row["TECNICO QUE PRESTA EL RADIO"])
            tecnico_recibe_nom = limpiar(row["TECNICO QUE RECIBE"])

            if not cedula or not serial:
                continue

            # Obtener IDs
            cursor.execute(
                "SELECT id FROM funcionarios WHERE identificacion=%s",
                (cedula,)
            )
            func_result = cursor.fetchone()
            if not func_result:
                continue
            funcionario_id = func_result[0]

            cursor.execute(
                "SELECT id FROM radios WHERE serial=%s",
                (serial,)
            )
            radio_result = cursor.fetchone()
            if not radio_result:
                continue
            radio_id = radio_result[0]

            cursor.execute(
                "SELECT id FROM tecnicos WHERE nombre LIKE %s",
                (f"%{tecnico_presta_nom}%",)
            )
            tecnico_result = cursor.fetchone()
            if not tecnico_result:
                continue
            tecnico_presta_id = tecnico_result[0]

            tecnico_recibe_id = None
            if tecnico_recibe_nom:
                cursor.execute(
                    "SELECT id FROM tecnicos WHERE nombre LIKE %s",
                    (f"%{tecnico_recibe_nom}%",)
                )
                tecnico_result = cursor.fetchone()
                if tecnico_result:
                    tecnico_recibe_id = tecnico_result[0]

            # Evitar duplicados
            cursor.execute("""
                SELECT id FROM prestamos 
                WHERE funcionario_id=%s 
                AND radio_id=%s 
                AND fecha_asignacion=%s
            """, (funcionario_id, radio_id, row["FECHA DE ASIGNACION"]))

            if cursor.fetchone():
                continue

            # Insertar
            sql = """
                INSERT INTO prestamos
                (funcionario_id, radio_id, tecnico_presta_id, tecnico_recibe_id,
                 fecha_asignacion, fecha_devolucion, accesorios_radio, novedades)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """

            fecha_dev = row["FECHA DE DEVOLUCION"]
            valores = (
                funcionario_id,
                radio_id,
                tecnico_presta_id,
                tecnico_recibe_id,
                row["FECHA DE ASIGNACION"],
                fecha_dev if not pd.isna(fecha_dev) else None,
                limpiar(row["ACCESORIOS"]),
                limpiar(row["OBSERVACIONES"])
            )

            cursor.execute(sql, valores)
            contador += 1

        except Exception as e:
            print(f"⚠️ Error en fila {idx}: {e}")
            continue

    conexion.commit()
    print(f"✅ {contador} préstamos importados")

except Exception as e:
    print(f"❌ Error importando préstamos: {e}")
    conexion.rollback()

# ============================================================================
# FINALIZAR
# ============================================================================
cursor.close()
conexion.close()

print("\n" + "=" * 80)
print("✅ MIGRACIÓN COMPLETADA")
print("=" * 80)
print("\n⏱️  Hora de finalización:", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
