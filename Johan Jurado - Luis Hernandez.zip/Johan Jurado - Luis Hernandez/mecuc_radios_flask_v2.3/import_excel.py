import os
import pandas as pd

from app import create_app
from app.models import db, Funcionario, Tecnico, Radio

EXCEL_FILE = "LIBRO CONTROL PRESTAMO DE RADIOS MECUC.xlsm"


def safe_str(val):
    return "" if pd.isna(val) else str(val).strip()


def run_import():
    if not os.path.exists(EXCEL_FILE):
        raise FileNotFoundError(f"No se encontró el archivo: {EXCEL_FILE}")

    # ================== BD (FUNCIONARIOS) ==================
    df_bd = pd.read_excel(EXCEL_FILE, sheet_name="BD", engine="openpyxl")
    cols_bd = ["IDENTIFICACION", "GR", "APELLIDOS Y NOMBRES", "UNIDAD", "CARGO", "NRO CELULAR"]

    for col in cols_bd:
        if col not in df_bd.columns:
            raise RuntimeError(f"Falta columna '{col}' en hoja BD")

    for _, row in df_bd.iterrows():
        ident = safe_str(row["IDENTIFICACION"])
        if not ident:
            continue

        if not Funcionario.query.filter_by(identificacion=ident).first():
            db.session.add(
                Funcionario(
                    identificacion=ident,
                    grado=safe_str(row["GR"]),
                    apellidos_nombres=safe_str(row["APELLIDOS Y NOMBRES"]),
                    unidad=safe_str(row["UNIDAD"]),
                    cargo=safe_str(row["CARGO"]),
                    celular=safe_str(row["NRO CELULAR"]),
                )
            )

    # ================== RADIOS ==================
    df_rad = pd.read_excel(EXCEL_FILE, sheet_name="RADIOS", engine="openpyxl")
    cols_r = ["SERIE", "MODELO", "ACCESORIOS", "OBSERVACIONES"]

    for col in cols_r:
        if col not in df_rad.columns:
            raise RuntimeError(f"Falta columna '{col}' en hoja RADIOS")

    for _, row in df_rad.iterrows():
        serial = safe_str(row["SERIE"])
        if not serial:
            continue

        if not Radio.query.filter_by(serial=serial).first():
            db.session.add(
                Radio(
                    serial=serial,
                    modelo=safe_str(row["MODELO"]),
                    accesorios=safe_str(row["ACCESORIOS"]),
                    observaciones=safe_str(row["OBSERVACIONES"]),
                )
            )

    # ================== TECNICOS  ==================
    df_tec = pd.read_excel(EXCEL_FILE, sheet_name="TECNICOS", engine="openpyxl")
    df_tec.columns = [c.strip().upper() for c in df_tec.columns]

    col_grado = next((c for c in df_tec.columns if c in ["GR", "GRADO"]), None)
    col_nombres = next((c for c in df_tec.columns if "NOMBRE" in c), None)
    col_apellidos = next((c for c in df_tec.columns if "APELLIDO" in c), None)

    if not col_grado or not col_nombres:
        raise RuntimeError("La hoja TECNICOS debe tener columnas GR y NOMBRE")

    for _, row in df_tec.iterrows():
        grado = safe_str(row[col_grado])
        nombres = safe_str(row[col_nombres])
        apellidos = safe_str(row[col_apellidos]) if col_apellidos else ""

        nombre_completo = f"{grado} {nombres} {apellidos}".strip()
        if not nombre_completo:
            continue

        if not Tecnico.query.filter_by(nombre=nombre_completo).first():
            db.session.add(Tecnico(nombre=nombre_completo))

    # ================== COMMIT FINAL ==================
    db.session.commit()
    print("✅ Importación completada correctamente.")


if __name__ == "__main__":
    app = create_app()
    with app.app_context():
        run_import()