from django.shortcuts import render

from pedidos.models import Pedido, Mesa

from facturacion.models import Factura

from django.db.models import Sum

from datetime import date

# 🔐 PROTEGER DASHBOARD
from django.contrib.auth.decorators import login_required


# 🔐 SI NO ESTÁ LOGUEADO -> ENVÍA A /login/
@login_required(login_url='/login/')
def index(request):

    # 📅 fecha actual
    hoy = date.today()

    # 💰 ventas del día
    ventas_hoy = Factura.objects.filter(
        fecha__date=hoy
    ).aggregate(
        total=Sum('total')
    )['total']

    if ventas_hoy is None:
        ventas_hoy = 0

    # 🧾 pedidos
    total_pedidos = Pedido.objects.count()

    # 🍽 mesas ocupadas
    mesas_ocupadas = Mesa.objects.filter(
        estado='ocupada'
    ).count()

    # 📈 total facturas
    total_facturas = Factura.objects.count()

    # 🧾 últimas facturas
    ultimas_facturas = Factura.objects.order_by(
        '-id'
    )[:5]

    return render(
        request,
        'dashboard/index.html',
        {
            'ventas_hoy': ventas_hoy,
            'total_pedidos': total_pedidos,
            'mesas_ocupadas': mesas_ocupadas,
            'total_facturas': total_facturas,
            'ultimas_facturas': ultimas_facturas,
        }
    )