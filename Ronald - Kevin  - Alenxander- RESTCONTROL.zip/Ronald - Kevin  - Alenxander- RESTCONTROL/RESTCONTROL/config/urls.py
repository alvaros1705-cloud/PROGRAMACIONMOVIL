from django.contrib import admin

from django.urls import path, include

# 🔥 MEDIA
from django.conf import settings
from django.conf.urls.static import static


urlpatterns = [

    # 🔥 ADMIN
    path(
        'admin/',
        admin.site.urls
    ),

    # 🔵 LOGIN GOOGLE / ALLAUTH
    path(
        'accounts/',
        include('allauth.urls')
    ),

    # 🍽 DASHBOARD
    path(
        '',
        include('dashboard.urls')
    ),

    # 🔐 USUARIOS
    path(
        '',
        include('usuarios.urls')
    ),

    # 🧾 PEDIDOS
    path(
        'pedidos/',
        include('pedidos.urls')
    ),

    # 👨‍🍳 COCINA
    path(
        'cocina/',
        include('cocina.urls')
    ),

    # 💳 FACTURACIÓN
    path(
        'facturacion/',
        include('facturacion.urls')
    ),

    # 📦 INVENTARIO
    path(
        'inventario/',
        include('inventario.urls')
    ),

    # 📊 REPORTES
    path(
        'reportes/',
        include('reportes.urls')
    ),

    # 💰 CAJA
    path(
        'caja/',
        include('caja.urls')
    ),

    # 👥 CLIENTES
    path(
        'clientes/',
        include('clientes.urls')
    ),

    # ⚙️ CONFIGURACIÓN
    path(
        'configuracion/',
        include('configuracion.urls')
    ),
    path(
    'inteligencia/',
    include('inteligencia.urls')
),

]


# 🔥 MOSTRAR IMÁGENES EN DESARROLLO
urlpatterns += static(

    settings.MEDIA_URL,

    document_root=settings.MEDIA_ROOT

)