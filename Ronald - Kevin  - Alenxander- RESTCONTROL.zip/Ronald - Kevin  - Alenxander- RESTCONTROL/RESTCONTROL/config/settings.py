"""
Django settings for config project.
"""

from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent


# 🔐 SEGURIDAD
SECRET_KEY = 'django-insecure-sc_vg*(+bhhqzr06^g_96-$x)-susf&k!*xu$e)70^m+_s+*jf'

DEBUG = True


# 📱 PERMITIR CONEXIONES
ALLOWED_HOSTS = [
    '*'
]


# 📦 APPS
INSTALLED_APPS = [

    # 🔥 DJANGO
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'django.contrib.sites',

    # 🔐 ALLAUTH
    'allauth',
    'allauth.account',
    'allauth.socialaccount',

    # 🔵 GOOGLE
    'allauth.socialaccount.providers.google',

    # 🍽 RESTCONTROL
    'dashboard',
    'pedidos',
    'cocina',
    'facturacion',
    'usuarios',
    'inventario',
    'reportes',
    'caja',
    'clientes',
    'configuracion',
       'inteligencia',
]


# ⚙️ MIDDLEWARE
MIDDLEWARE = [

    'django.middleware.security.SecurityMiddleware',

    'django.contrib.sessions.middleware.SessionMiddleware',

    'django.middleware.common.CommonMiddleware',

    'django.middleware.csrf.CsrfViewMiddleware',

    'django.contrib.auth.middleware.AuthenticationMiddleware',

    # 🔵 ALLAUTH
    'allauth.account.middleware.AccountMiddleware',

    'django.contrib.messages.middleware.MessageMiddleware',

    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]


# 🌐 URLS
ROOT_URLCONF = 'config.urls'


# 🖼 TEMPLATES
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',

        'DIRS': [],

        'APP_DIRS': True,

        'OPTIONS': {

            'context_processors': [

                'django.template.context_processors.request',

                'django.contrib.auth.context_processors.auth',

                'django.contrib.messages.context_processors.messages',

            ],
        },
    },
]


# 🚀 WSGI
WSGI_APPLICATION = 'config.wsgi.application'


# 🗄 BASE DATOS
DATABASES = {

    'default': {

        'ENGINE': 'django.db.backends.sqlite3',

        'NAME': BASE_DIR / 'db.sqlite3',

    }

}


# 🔐 PASSWORDS
AUTH_PASSWORD_VALIDATORS = [

    {
        'NAME':
        'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },

    {
        'NAME':
        'django.contrib.auth.password_validation.MinimumLengthValidator',
    },

    {
        'NAME':
        'django.contrib.auth.password_validation.CommonPasswordValidator',
    },

    {
        'NAME':
        'django.contrib.auth.password_validation.NumericPasswordValidator',
    },

]


# 🌎 IDIOMA
LANGUAGE_CODE = 'es-co'

TIME_ZONE = 'America/Bogota'

USE_I18N = True

USE_TZ = False


# 🌐 SITE
SITE_ID = 1


# 📁 STATIC
STATIC_URL = 'static/'


# 📱 CSRF
CSRF_TRUSTED_ORIGINS = [

    'http://*',

    'https://*',

]


# 🔐 LOGIN
LOGIN_URL = '/login/'

LOGIN_REDIRECT_URL = '/'

LOGOUT_REDIRECT_URL = '/login/'


# 🔐 AUTHENTICATION
AUTHENTICATION_BACKENDS = [

    # 🔥 LOGIN NORMAL DJANGO
    'django.contrib.auth.backends.ModelBackend',

    # 🔵 LOGIN GOOGLE
    'allauth.account.auth_backends.AuthenticationBackend',
]


# 🔵 CONFIG ALLAUTH
ACCOUNT_LOGIN_METHODS = {'email'}

ACCOUNT_SIGNUP_FIELDS = ['email*', 'username*', 'password1*', 'password2*']

ACCOUNT_EMAIL_VERIFICATION = 'none'


# 🔵 GOOGLE CONFIG
SOCIALACCOUNT_LOGIN_ON_GET = True

MEDIA_URL = '/media/'

MEDIA_ROOT = BASE_DIR / 'media'