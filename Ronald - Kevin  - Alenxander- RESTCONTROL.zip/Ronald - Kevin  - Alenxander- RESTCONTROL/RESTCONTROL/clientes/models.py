from django.db import models


class Cliente(models.Model):

    nombre = models.CharField(
        max_length=100
    )

    telefono = models.CharField(
        max_length=30
    )

    historial = models.IntegerField(
        default=0
    )

    creado = models.DateTimeField(
        auto_now_add=True
    )

    def __str__(self):

        return self.nombre