from django.shortcuts import render, redirect
from .models import Cliente


def clientes_view(request):

    if request.method == 'POST':

        nombre = request.POST.get('nombre')
        telefono = request.POST.get('telefono')

        Cliente.objects.create(
            nombre=nombre,
            telefono=telefono
        )

        return redirect('/clientes/')

    clientes = Cliente.objects.all().order_by('-id')

    return render(request, 'clientes/clientes.html', {

        'clientes': clientes

    })