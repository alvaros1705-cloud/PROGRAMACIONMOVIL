from django.shortcuts import render
from django.http import JsonResponse

from pedidos.models import Pedido, DetallePedido


# 🍳 Vista principal cocina
def cocina_view(request):

    return render(
        request,
        'cocina/cocina.html'
    )


# 🔄 Obtener pedidos pendientes
def obtener_pedidos(request):

    pedidos = Pedido.objects.filter(
        estado='pendiente'
    ).order_by('-id')

    data = []

    for p in pedidos:

        detalles = DetallePedido.objects.filter(
            pedido=p
        )

        productos = []

        for d in detalles:

            productos.append({
                'producto': d.producto,
                'cantidad': d.cantidad
            })

        # 🍽 DESTINO
        if p.tipo == 'mesa' and p.mesa:

            destino = f"🍽 Mesa {p.mesa.numero}"

        elif p.tipo == 'llevar':

            destino = "🛍 Para Llevar"

        elif p.tipo == 'domicilio':

            destino = "🛵 Domicilio"

        else:

            destino = "Pedido"

        data.append({
            'id': p.id,
            'destino': destino,
            'productos': productos
        })

    return JsonResponse({
        'pedidos': data
    })


# ✅ Marcar pedido como listo
def marcar_listo(request, id):

    pedido = Pedido.objects.get(id=id)

    pedido.estado = 'listo'

    pedido.facturado = False

    pedido.save()

    return JsonResponse({
        'mensaje': 'ok'
    })