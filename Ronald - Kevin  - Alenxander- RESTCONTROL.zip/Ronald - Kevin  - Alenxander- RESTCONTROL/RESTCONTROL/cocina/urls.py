from django.urls import path

from .views import (
    cocina_view,
    obtener_pedidos,
    marcar_listo
)

urlpatterns = [

    path(
        '',
        cocina_view,
        name='cocina'
    ),

    path(
        'obtener/',
        obtener_pedidos,
        name='obtener_pedidos'
    ),

    path(
        'listo/<int:id>/',
        marcar_listo,
        name='marcar_listo'
    ),

]