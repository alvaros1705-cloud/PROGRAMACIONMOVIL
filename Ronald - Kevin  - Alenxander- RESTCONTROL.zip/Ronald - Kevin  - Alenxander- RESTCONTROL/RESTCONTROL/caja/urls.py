from django.urls import path
from .views import caja_view

urlpatterns = [

    path('', caja_view),

]