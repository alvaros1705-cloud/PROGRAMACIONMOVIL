from django.shortcuts import render
from facturacion.models import Factura
from django.db.models import Sum
from datetime import date


def caja_view(request):

    hoy = date.today()

    # 💵 efectivo
    efectivo = Factura.objects.filter(
        fecha__date=hoy,
        metodo_pago='efectivo'
    ).aggregate(
        total=Sum('total')
    )['total']

    if efectivo is None:
        efectivo = 0

    # 💳 tarjetas
    tarjetas = Factura.objects.filter(
        fecha__date=hoy,
        metodo_pago='tarjeta'
    ).aggregate(
        total=Sum('total')
    )['total']

    if tarjetas is None:
        tarjetas = 0

    # 📈 total día
    ganancias = efectivo + tarjetas

    return render(request, 'caja/caja.html', {

        'efectivo': efectivo,
        'tarjetas': tarjetas,
        'ganancias': ganancias

    })