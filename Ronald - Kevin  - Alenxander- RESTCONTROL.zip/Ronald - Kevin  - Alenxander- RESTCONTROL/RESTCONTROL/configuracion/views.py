from django.shortcuts import (
    render,
    redirect,
    get_object_or_404
)

from .models import (
    Producto,
    Inventario,
    AparienciaSistema,
    CategoriaVisual,
    UsuarioSistema
)

from .forms import (
    ProductoForm,
    InventarioForm,
    MesaForm,
    AparienciaForm,
    CategoriaVisualForm,
    UsuarioSistemaForm
)

from pedidos.models import Mesa


# ⚙️ PANEL PRINCIPAL
def index(request):

    return render(
        request,
        'configuracion/configuracion.html'
    )


# 🍔 PRODUCTOS
def productos(request):

    form = ProductoForm()

    if request.method == 'POST':

        form = ProductoForm(
            request.POST,
            request.FILES
        )

        if form.is_valid():

            form.save()

            return redirect(
                '/configuracion/productos/'
            )

    productos = Producto.objects.all().order_by(
        '-id'
    )

    return render(
        request,
        'configuracion/productos.html',
        {
            'form': form,
            'productos': productos
        }
    )


# ✏ EDITAR PRODUCTO
def editar_producto(request, id):

    producto = get_object_or_404(
        Producto,
        id=id
    )

    form = ProductoForm(
        instance=producto
    )

    if request.method == 'POST':

        form = ProductoForm(
            request.POST,
            request.FILES,
            instance=producto
        )

        if form.is_valid():

            form.save()

            return redirect(
                '/configuracion/productos/'
            )

    productos = Producto.objects.all().order_by(
        '-id'
    )

    return render(
        request,
        'configuracion/productos.html',
        {
            'form': form,
            'productos': productos,
            'editando': True,
            'producto_id': producto.id
        }
    )


# 🗑 ELIMINAR PRODUCTO
def eliminar_producto(request, id):

    producto = get_object_or_404(
        Producto,
        id=id
    )

    producto.delete()

    return redirect(
        '/configuracion/productos/'
    )


# 🪑 MESAS
def mesas(request):

    form = MesaForm()

    if request.method == 'POST':

        form = MesaForm(
            request.POST
        )

        if form.is_valid():

            form.save()

            return redirect(
                '/configuracion/mesas/'
            )

    mesas = Mesa.objects.all().order_by(
        'numero'
    )

    return render(
        request,
        'configuracion/mesas.html',
        {
            'form': form,
            'mesas': mesas
        }
    )


# ✏ EDITAR MESA
def editar_mesa(request, id):

    mesa = get_object_or_404(
        Mesa,
        id=id
    )

    form = MesaForm(
        instance=mesa
    )

    if request.method == 'POST':

        form = MesaForm(
            request.POST,
            instance=mesa
        )

        if form.is_valid():

            form.save()

            return redirect(
                '/configuracion/mesas/'
            )

    mesas = Mesa.objects.all().order_by(
        'numero'
    )

    return render(
        request,
        'configuracion/mesas.html',
        {
            'form': form,
            'mesas': mesas,
            'editando': True,
            'mesa_id': mesa.id
        }
    )


# 🗑 ELIMINAR MESA
def eliminar_mesa(request, id):

    mesa = get_object_or_404(
        Mesa,
        id=id
    )

    mesa.delete()

    return redirect(
        '/configuracion/mesas/'
    )


# 🎨 APARIENCIA DEL SISTEMA
def apariencia(request):

    apariencia_obj, created = AparienciaSistema.objects.get_or_create(
        id=1
    )

    form = AparienciaForm(
        instance=apariencia_obj
    )

    if request.method == 'POST':

        form = AparienciaForm(
            request.POST,
            request.FILES,
            instance=apariencia_obj
        )

        if form.is_valid():

            form.save()

            return redirect(
                '/configuracion/apariencia/'
            )

    return render(
        request,
        'configuracion/apariencia.html',
        {
            'form': form,
            'apariencia': apariencia_obj
        }
    )


# 📂 CATEGORÍAS VISUALES
def categorias(request):

    form = CategoriaVisualForm()

    categorias_base = [
        {
            'codigo': 'comida',
            'nombre': 'Comida',
            'icono': '🍔',
            'descripcion': 'Platos principales y preparaciones de cocina.',
            'orden': 1
        },
        {
            'codigo': 'bebida',
            'nombre': 'Bebida',
            'icono': '🥤',
            'descripcion': 'Bebidas frías, gaseosas, aguas y jugos.',
            'orden': 2
        },
        {
            'codigo': 'combo',
            'nombre': 'Combo',
            'icono': '🍟',
            'descripcion': 'Combinaciones de productos o menús especiales.',
            'orden': 3
        },
        {
            'codigo': 'postre',
            'nombre': 'Postre',
            'icono': '🍰',
            'descripcion': 'Productos dulces o complementarios.',
            'orden': 4
        },
        {
            'codigo': 'adicional',
            'nombre': 'Adicional',
            'icono': '➕',
            'descripcion': 'Porciones adicionales y acompañamientos extras.',
            'orden': 5
        },
    ]

    for cat in categorias_base:

        CategoriaVisual.objects.get_or_create(
            codigo=cat['codigo'],
            defaults={
                'nombre': cat['nombre'],
                'icono': cat['icono'],
                'descripcion': cat['descripcion'],
                'orden': cat['orden'],
                'activo': True
            }
        )

    if request.method == 'POST':

        form = CategoriaVisualForm(
            request.POST
        )

        if form.is_valid():

            form.save()

            return redirect(
                '/configuracion/categorias/'
            )

    categorias = CategoriaVisual.objects.all().order_by(
        'orden',
        'nombre'
    )

    return render(
        request,
        'configuracion/categorias.html',
        {
            'form': form,
            'categorias': categorias
        }
    )


# ✏ EDITAR CATEGORÍA VISUAL
def editar_categoria(request, id):

    categoria = get_object_or_404(
        CategoriaVisual,
        id=id
    )

    form = CategoriaVisualForm(
        instance=categoria
    )

    if request.method == 'POST':

        form = CategoriaVisualForm(
            request.POST,
            instance=categoria
        )

        if form.is_valid():

            form.save()

            return redirect(
                '/configuracion/categorias/'
            )

    categorias = CategoriaVisual.objects.all().order_by(
        'orden',
        'nombre'
    )

    return render(
        request,
        'configuracion/categorias.html',
        {
            'form': form,
            'categorias': categorias,
            'editando': True,
            'categoria_id': categoria.id
        }
    )


# 🗑 ELIMINAR CATEGORÍA VISUAL
def eliminar_categoria(request, id):

    categoria = get_object_or_404(
        CategoriaVisual,
        id=id
    )

    categoria.delete()

    return redirect(
        '/configuracion/categorias/'
    )


# 👥 USUARIOS Y ROLES
def usuarios(request):

    form = UsuarioSistemaForm()

    if request.method == 'POST':

        form = UsuarioSistemaForm(
            request.POST
        )

        if form.is_valid():

            form.save()

            return redirect(
                '/configuracion/usuarios/'
            )

    usuarios = UsuarioSistema.objects.all().order_by(
        '-id'
    )

    return render(
        request,
        'configuracion/usuarios.html',
        {
            'form': form,
            'usuarios': usuarios
        }
    )


# ✏ EDITAR USUARIO
def editar_usuario(request, id):

    usuario = get_object_or_404(
        UsuarioSistema,
        id=id
    )

    form = UsuarioSistemaForm(
        instance=usuario
    )

    if request.method == 'POST':

        form = UsuarioSistemaForm(
            request.POST,
            instance=usuario
        )

        if form.is_valid():

            form.save()

            return redirect(
                '/configuracion/usuarios/'
            )

    usuarios = UsuarioSistema.objects.all().order_by(
        '-id'
    )

    return render(
        request,
        'configuracion/usuarios.html',
        {
            'form': form,
            'usuarios': usuarios,
            'editando': True,
            'usuario_id': usuario.id
        }
    )


# 🗑 ELIMINAR USUARIO
def eliminar_usuario(request, id):

    usuario = get_object_or_404(
        UsuarioSistema,
        id=id
    )

    usuario.delete()

    return redirect(
        '/configuracion/usuarios/'
    )