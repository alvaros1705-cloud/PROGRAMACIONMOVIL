from django.contrib import admin

from .models import (
    Producto,
    Inventario,
    IngredienteProducto
)

admin.site.register(Producto)

admin.site.register(Inventario)

admin.site.register(IngredienteProducto)