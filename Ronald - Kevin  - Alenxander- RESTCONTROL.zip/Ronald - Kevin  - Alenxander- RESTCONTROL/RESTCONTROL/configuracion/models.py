from django.db import models


# 📦 INVENTARIO
class Inventario(models.Model):

    nombre = models.CharField(
        max_length=150
    )

    stock = models.IntegerField(
        default=0
    )

    minimo = models.IntegerField(
        default=5
    )

    unidad = models.CharField(
        max_length=50,
        default='unidad'
    )

    costo = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=0
    )

    activo = models.BooleanField(
        default=True
    )

    fecha_creacion = models.DateTimeField(
        auto_now_add=True
    )

    def __str__(self):

        return self.nombre


# 🍔 PRODUCTOS
class Producto(models.Model):

    # 📂 TIPO PRODUCTO
    TIPO_PRODUCTO = (

        ('comida', 'Comida'),

        ('bebida', 'Bebida'),

        ('combo', 'Combo'),

        ('postre', 'Postre'),

        ('adicional', 'Adicional'),

    )

    categoria = models.CharField(
        max_length=20,
        choices=TIPO_PRODUCTO,
        default='comida'
    )

    nombre = models.CharField(
        max_length=150
    )

    descripcion = models.TextField(
        blank=True,
        null=True
    )

    precio = models.DecimalField(
        max_digits=10,
        decimal_places=2
    )

    imagen = models.ImageField(
        upload_to='productos/',
        blank=True,
        null=True
    )

    disponible = models.BooleanField(
        default=True
    )

    destacado = models.BooleanField(
        default=False
    )

    # 📦 CONTROL STOCK
    maneja_stock = models.BooleanField(
        default=False
    )

    stock = models.IntegerField(
        default=0
    )

    minimo_stock = models.IntegerField(
        default=5
    )

    codigo = models.CharField(
        max_length=50,
        blank=True,
        null=True
    )

    activo = models.BooleanField(
        default=True
    )

    fecha_creacion = models.DateTimeField(
        auto_now_add=True
    )

    def __str__(self):

        return self.nombre


# 🧾 INGREDIENTES PRODUCTO
class IngredienteProducto(models.Model):

    producto = models.ForeignKey(
        Producto,
        on_delete=models.CASCADE,
        related_name='ingredientes'
    )

    inventario = models.ForeignKey(
        Inventario,
        on_delete=models.CASCADE
    )

    cantidad = models.FloatField()

    def __str__(self):

        return f"{self.producto.nombre} -> {self.inventario.nombre}"


# 🎨 APARIENCIA DEL SISTEMA
class AparienciaSistema(models.Model):

    nombre_sistema = models.CharField(
        max_length=100,
        default='RESTCONTROL'
    )

    color_primario = models.CharField(
        max_length=20,
        default='#38bdf8'
    )

    color_secundario = models.CharField(
        max_length=20,
        default='#22c55e'
    )

    color_fondo = models.CharField(
        max_length=20,
        default='#0f172a'
    )

    color_tarjetas = models.CharField(
        max_length=20,
        default='#1e293b'
    )

    color_texto = models.CharField(
        max_length=20,
        default='#ffffff'
    )

    modo_oscuro = models.BooleanField(
        default=True
    )

    logo = models.ImageField(
        upload_to='apariencia/',
        blank=True,
        null=True
    )

    actualizado = models.DateTimeField(
        auto_now=True
    )

    def __str__(self):

        return self.nombre_sistema
    
    # 📂 CONFIGURACIÓN DE CATEGORÍAS VISUALES
class CategoriaVisual(models.Model):

    codigo = models.CharField(
        max_length=50,
        unique=True
    )

    nombre = models.CharField(
        max_length=100
    )

    icono = models.CharField(
        max_length=20,
        default='📂'
    )

    descripcion = models.TextField(
        blank=True,
        null=True
    )

    activo = models.BooleanField(
        default=True
    )

    orden = models.IntegerField(
        default=0
    )

    def __str__(self):

        return self.nombre
    
    # 👥 USUARIOS DEL SISTEMA
class UsuarioSistema(models.Model):

    ROLES = (

        ('admin', 'Administrador'),

        ('cajero', 'Cajero'),

        ('cocina', 'Cocina'),

        ('mesero', 'Mesero'),

        ('gerente', 'Gerente'),

    )

    nombre = models.CharField(
        max_length=150
    )

    usuario = models.CharField(
        max_length=100,
        unique=True
    )

    password = models.CharField(
        max_length=100
    )

    rol = models.CharField(
        max_length=20,
        choices=ROLES,
        default='mesero'
    )

    activo = models.BooleanField(
        default=True
    )

    fecha_creacion = models.DateTimeField(
        auto_now_add=True
    )

    def __str__(self):

        return self.nombre