from django import forms

from .models import (
    Producto,
    Inventario,
    AparienciaSistema,
    CategoriaVisual,
    UsuarioSistema
)

from pedidos.models import Mesa


class ProductoForm(forms.ModelForm):

    class Meta:

        model = Producto

        fields = '__all__'


class InventarioForm(forms.ModelForm):

    class Meta:

        model = Inventario

        fields = '__all__'


class MesaForm(forms.ModelForm):

    class Meta:

        model = Mesa

        fields = [
            'numero',
            'estado'
        ]


class AparienciaForm(forms.ModelForm):

    class Meta:

        model = AparienciaSistema

        fields = [
            'nombre_sistema',
            'color_primario',
            'color_secundario',
            'color_fondo',
            'color_tarjetas',
            'color_texto',
            'modo_oscuro',
            'logo'
        ]

        widgets = {

            'color_primario': forms.TextInput(
                attrs={
                    'type': 'color'
                }
            ),

            'color_secundario': forms.TextInput(
                attrs={
                    'type': 'color'
                }
            ),

            'color_fondo': forms.TextInput(
                attrs={
                    'type': 'color'
                }
            ),

            'color_tarjetas': forms.TextInput(
                attrs={
                    'type': 'color'
                }
            ),

            'color_texto': forms.TextInput(
                attrs={
                    'type': 'color'
                }
            ),

        }


class CategoriaVisualForm(forms.ModelForm):

    class Meta:

        model = CategoriaVisual

        fields = [
            'codigo',
            'nombre',
            'icono',
            'descripcion',
            'activo',
            'orden'
        ]


class UsuarioSistemaForm(forms.ModelForm):

    class Meta:

        model = UsuarioSistema

        fields = [
            'nombre',
            'usuario',
            'password',
            'rol',
            'activo'
        ]

        widgets = {

            'password': forms.PasswordInput(
                render_value=True
            )

        }