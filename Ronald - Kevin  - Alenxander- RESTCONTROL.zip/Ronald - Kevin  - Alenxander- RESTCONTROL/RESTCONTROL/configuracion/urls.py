from django.urls import path

from . import views


urlpatterns = [

    # ⚙️ PANEL
    path(
        '',
        views.index,
        name='configuracion'
    ),

    # 🍔 PRODUCTOS
    path(
        'productos/',
        views.productos,
        name='productos'
    ),

    path(
        'productos/editar/<int:id>/',
        views.editar_producto,
        name='editar_producto'
    ),

    path(
        'productos/eliminar/<int:id>/',
        views.eliminar_producto,
        name='eliminar_producto'
    ),

    # 🪑 MESAS
    path(
        'mesas/',
        views.mesas,
        name='mesas'
    ),

    path(
        'mesas/editar/<int:id>/',
        views.editar_mesa,
        name='editar_mesa'
    ),

    path(
        'mesas/eliminar/<int:id>/',
        views.eliminar_mesa,
        name='eliminar_mesa'
    ),

    # 🎨 APARIENCIA
    path(
        'apariencia/',
        views.apariencia,
        name='apariencia'
    ),

    # 📂 CATEGORÍAS
    path(
        'categorias/',
        views.categorias,
        name='categorias'
    ),

    path(
        'categorias/editar/<int:id>/',
        views.editar_categoria,
        name='editar_categoria'
    ),

    path(
        'categorias/eliminar/<int:id>/',
        views.eliminar_categoria,
        name='eliminar_categoria'
    ),

    # 👥 USUARIOS
    path(
        'usuarios/',
        views.usuarios,
        name='usuarios'
    ),

    path(
        'usuarios/editar/<int:id>/',
        views.editar_usuario,
        name='editar_usuario'
    ),

    path(
        'usuarios/eliminar/<int:id>/',
        views.eliminar_usuario,
        name='eliminar_usuario'
    ),

]