from django.urls import path

from .views import reportes_view

urlpatterns = [

    path('', reportes_view),

]