from django.shortcuts import render

from facturacion.models import Factura
from pedidos.models import Pedido, Mesa, DetallePedido

from django.db.models import Sum, Count

from datetime import date

import json


def reportes_view(request):

    fecha = request.GET.get('fecha')

    if not fecha:

        fecha = str(date.today())

    facturas = Factura.objects.filter(
        fecha__date=str(fecha)
    ).order_by('-id')

    ventas_hoy = facturas.aggregate(
        total=Sum('total')
    )['total'] or 0

    total_efectivo = facturas.filter(
        metodo_pago='efectivo'
    ).aggregate(
        total=Sum('total')
    )['total'] or 0

    total_transferencia = facturas.filter(
        metodo_pago='transferencia'
    ).aggregate(
        total=Sum('total')
    )['total'] or 0

    total_facturas = facturas.count()

    mesas_ocupadas = Mesa.objects.filter(
        estado='ocupada'
    ).count()

    total_pedidos = Pedido.objects.count()

    ventas = Factura.objects.values(
        'fecha__date'
    ).annotate(
        total=Sum('total')
    ).order_by('fecha__date')

    ventas_labels = []
    ventas_data = []

    for venta in ventas:

        ventas_labels.append(
            str(venta['fecha__date'])
        )

        ventas_data.append(
            float(venta['total'] or 0)
        )

    pagos_labels = [
        'Efectivo',
        'Transferencia'
    ]

    pagos_data = [
        float(total_efectivo),
        float(total_transferencia)
    ]

    pedidos_tipo = Pedido.objects.values(
        'tipo'
    ).annotate(
        total=Count('id')
    )

    tipos_labels = []
    tipos_data = []

    for item in pedidos_tipo:

        tipos_labels.append(
            item['tipo']
        )

        tipos_data.append(
            item['total']
        )

    productos_vendidos = DetallePedido.objects.values(
        'producto'
    ).annotate(
        total=Sum('cantidad')
    ).order_by('-total')[:8]

    productos_labels = []
    productos_data = []

    for item in productos_vendidos:

        productos_labels.append(
            item['producto']
        )

        productos_data.append(
            item['total']
        )

    return render(
        request,
        'reportes/reportes.html',
        {
            'ventas_hoy': ventas_hoy,
            'total_efectivo': total_efectivo,
            'total_transferencia': total_transferencia,
            'total_facturas': total_facturas,
            'mesas_ocupadas': mesas_ocupadas,
            'total_pedidos': total_pedidos,
            'facturas': facturas,
            'ventas': ventas,
            'fecha': fecha,

            'ventas_labels': json.dumps(ventas_labels),
            'ventas_data': json.dumps(ventas_data),

            'pagos_labels': json.dumps(pagos_labels),
            'pagos_data': json.dumps(pagos_data),

            'tipos_labels': json.dumps(tipos_labels),
            'tipos_data': json.dumps(tipos_data),

            'productos_labels': json.dumps(productos_labels),
            'productos_data': json.dumps(productos_data),
        }
    )