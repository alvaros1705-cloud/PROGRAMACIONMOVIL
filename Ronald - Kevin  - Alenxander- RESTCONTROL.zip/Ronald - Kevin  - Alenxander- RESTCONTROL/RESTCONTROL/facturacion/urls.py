from django.urls import path
from .views import (
    facturacion_view,
    obtener_listos,
    cobrar,
    factura_pdf
)

urlpatterns = [
    path('', facturacion_view),
    path('obtener/', obtener_listos),
    path('cobrar/<int:id>/', cobrar),
    path('pdf/<int:id>/', factura_pdf),
]