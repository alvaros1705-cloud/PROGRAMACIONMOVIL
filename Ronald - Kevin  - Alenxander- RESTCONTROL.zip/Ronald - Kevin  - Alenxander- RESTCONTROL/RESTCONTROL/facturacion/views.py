from django.shortcuts import render
from django.http import JsonResponse, HttpResponse

from pedidos.models import Pedido, DetallePedido
from .models import Factura

# 👥 CLIENTES
from clientes.models import Cliente

# 📦 INVENTARIO
from inventario.models import ProductoInventario

# 🧾 PDF
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter

from datetime import datetime

import json


# 🧾 Pantalla facturación
def facturacion_view(request):

    clientes = Cliente.objects.all()

    return render(
        request,
        'facturacion/facturacion.html',
        {
            'clientes': clientes
        }
    )


# 🔄 Obtener pedidos listos
def obtener_listos(request):

    pedidos = Pedido.objects.filter(
        estado='listo',
        facturado=False
    ).order_by('-id')

    data = []

    for p in pedidos:

        detalles = DetallePedido.objects.filter(
            pedido=p
        )

        productos = []

        for d in detalles:

            productos.append({
                'producto': d.producto,
                'cantidad': d.cantidad
            })

        data.append({
            'id': p.id,

            # 🍽 mesa opcional
            'mesa': (
                p.mesa.numero
                if p.mesa
                else 'N/A'
            ),

            # 🥡 tipo pedido
            'tipo': p.tipo,

            'total': p.total,
            'productos': productos
        })

    return JsonResponse({
        'pedidos': data
    })


# 💵 COBRAR
def cobrar(request, id):

    pedido = Pedido.objects.get(id=id)

    # 📥 datos frontend
    data = json.loads(request.body)

    metodo = data.get(
        'metodo_pago',
        'efectivo'
    )

    cliente_id = data.get(
        'cliente'
    )

    # 💵 dinero recibido
    recibido = data.get(
        'recibido',
        0
    )

    # 🔄 vueltos
    vueltos = data.get(
        'vueltos',
        0
    )

    cliente = None

    # 👤 obtener cliente
    if cliente_id:

        try:

            cliente = Cliente.objects.get(
                id=cliente_id
            )

        except:

            cliente = None

    # 🧾 crear factura
    factura = Factura.objects.create(
        pedido=pedido,
        cliente=cliente,
        total=pedido.total,
        metodo_pago=metodo,
        recibido=recibido,
        vueltos=vueltos
    )

    # ✅ marcar pedido como facturado
    pedido.facturado = True
    pedido.save()

    # 🪑 liberar mesa SOLO si existe
    if pedido.mesa:

        pedido.mesa.estado = 'libre'
        pedido.mesa.save()

    # 📈 actualizar historial cliente
    if cliente:

        cliente.historial += pedido.total

        cliente.save()

    # 📦 DESCONTAR INVENTARIO
    detalles = DetallePedido.objects.filter(
        pedido=pedido
    )

    for d in detalles:

        try:

            producto = ProductoInventario.objects.get(
                nombre=d.producto
            )

            producto.stock -= d.cantidad

            producto.save()

        except:

            pass

    return JsonResponse({
        'factura_id': factura.id
    })


# 🧾 GENERAR PDF
def factura_pdf(request, id):

    factura = Factura.objects.get(id=id)

    pedido = factura.pedido

    detalles = DetallePedido.objects.filter(
        pedido=pedido
    )

    response = HttpResponse(
        content_type='application/pdf'
    )

    response['Content-Disposition'] = (
        f'attachment; filename="factura_{factura.id}.pdf"'
    )

    pdf = canvas.Canvas(
        response,
        pagesize=letter
    )

    # 🏪 TITULO
    pdf.setFont(
        "Helvetica-Bold",
        20
    )

    pdf.drawString(
        180,
        750,
        "RESTCONTROL"
    )

    pdf.setFont(
        "Helvetica",
        12
    )

    # 📄 DATOS FACTURA
    pdf.drawString(
        50,
        700,
        f"Factura #: {factura.id}"
    )

    # 🍽 mesa o tipo pedido
    if pedido.tipo == 'mesa':

        texto_tipo = (
            f"Mesa: {pedido.mesa.numero}"
        )

    elif pedido.tipo == 'llevar':

        texto_tipo = "Pedido: Para Llevar"

    else:

        texto_tipo = "Pedido: Domicilio"

    pdf.drawString(
        50,
        680,
        texto_tipo
    )

    pdf.drawString(
        50,
        660,
        f"Fecha: {datetime.now()}"
    )

    pdf.drawString(
        50,
        640,
        f"Método Pago: {factura.metodo_pago}"
    )

    # 💵 RECIBIDO
    pdf.drawString(
        50,
        620,
        f"Recibido: ${factura.recibido}"
    )

    # 🔄 VUELTOS
    pdf.drawString(
        50,
        600,
        f"Vueltos: ${factura.vueltos}"
    )

    # 👤 CLIENTE
    if factura.cliente:

        pdf.drawString(
            50,
            580,
            f"Cliente: {factura.cliente.nombre}"
        )

        y = 540

    else:

        y = 560

    # 🍔 PRODUCTOS
    pdf.drawString(
        50,
        y,
        "PRODUCTOS"
    )

    y -= 30

    for d in detalles:

        subtotal = d.precio * d.cantidad

        # 🍔 nombre producto
        pdf.drawString(
            70,
            y,
            f"{d.producto}"
        )

        y -= 15

        # 💰 detalle precio
        detalle = (
            f"{d.cantidad} x ${d.precio} = ${subtotal}"
        )

        pdf.drawString(
            90,
            y,
            detalle
        )

        y -= 25

    # 💰 TOTAL
    y -= 20

    pdf.setFont(
        "Helvetica-Bold",
        14
    )

    pdf.drawString(
        50,
        y,
        f"TOTAL: ${factura.total}"
    )

    pdf.save()

    return response