from django.db import models
from pedidos.models import Pedido
from clientes.models import Cliente


class Factura(models.Model):

    pedido = models.ForeignKey(
        Pedido,
        on_delete=models.CASCADE
    )

    cliente = models.ForeignKey(
        Cliente,
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )

    total = models.IntegerField()

    metodo_pago = models.CharField(
        max_length=20,
        default='efectivo'
    )

    # 💵 DINERO RECIBIDO
    recibido = models.IntegerField(
        default=0
    )

    # 🔄 VUELTOS
    vueltos = models.IntegerField(
        default=0
    )

    fecha = models.DateTimeField(
        auto_now_add=True
    )

    def __str__(self):

        return f"Factura {self.id}"