from django.urls import path

from . import views

urlpatterns = [

    path(
        '',
        views.inteligencia_view,
        name='inteligencia'
    ),

]