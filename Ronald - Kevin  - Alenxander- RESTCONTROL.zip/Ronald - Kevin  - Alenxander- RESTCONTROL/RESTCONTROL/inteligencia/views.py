from django.shortcuts import render

from facturacion.models import Factura
from pedidos.models import Pedido
from configuracion.models import Producto

from django.db.models import Sum
from django.db.models import Count


def inteligencia_view(request):

    # 💰 VENTAS TOTALES

    ventas_totales = Factura.objects.aggregate(
        total=Sum('total')
    )['total'] or 0

    # 🧾 FACTURAS

    total_facturas = Factura.objects.count()

    # 📦 PEDIDOS

    total_pedidos = Pedido.objects.count()

    # 🍔 PRODUCTOS

    total_productos = Producto.objects.count()

    # 🚚 TIPOS DE PEDIDO

    pedidos_mesa = Pedido.objects.filter(
        tipo='mesa'
    ).count()

    pedidos_llevar = Pedido.objects.filter(
        tipo='llevar'
    ).count()

    pedidos_domicilio = Pedido.objects.filter(
        tipo='domicilio'
    ).count()

    # 🤖 RECOMENDACIONES

    recomendaciones = []

    if pedidos_domicilio > pedidos_mesa:

        recomendaciones.append(
            "Se observa mayor demanda en domicilios. Considere fortalecer este canal."
        )

    if pedidos_llevar > pedidos_mesa:

        recomendaciones.append(
            "Las ventas para llevar presentan un comportamiento positivo."
        )

    if ventas_totales > 1000000:

        recomendaciones.append(
            "El restaurante presenta un excelente nivel de ventas acumuladas."
        )

    if not recomendaciones:

        recomendaciones.append(
            "No existen suficientes datos para generar recomendaciones avanzadas."
        )

    context = {

        'ventas_totales': ventas_totales,
        'total_facturas': total_facturas,
        'total_pedidos': total_pedidos,
        'total_productos': total_productos,

        'pedidos_mesa': pedidos_mesa,
        'pedidos_llevar': pedidos_llevar,
        'pedidos_domicilio': pedidos_domicilio,

        'recomendaciones': recomendaciones,

    }

    return render(
        request,
        'inteligencia/inteligencia.html',
        context
    )