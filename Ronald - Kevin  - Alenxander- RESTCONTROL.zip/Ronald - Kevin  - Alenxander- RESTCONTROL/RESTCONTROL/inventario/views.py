from django.shortcuts import render

from configuracion.models import Producto


def inventario_view(request):

    productos = Producto.objects.filter(
        categoria__in=[
            'bebida',
            'adicional'
        ]
    ).order_by(
        'categoria',
        'nombre'
    )

    total_productos = productos.count()

    productos_bajo_stock = productos.filter(
        maneja_stock=True,
        stock__lte=5
    ).count()

    bebidas = productos.filter(
        categoria='bebida'
    ).count()

    adicionales = productos.filter(
        categoria='adicional'
    ).count()

    return render(
        request,
        'inventario/inventario.html',
        {
            'productos': productos,
            'total_productos': total_productos,
            'productos_bajo_stock': productos_bajo_stock,
            'bebidas': bebidas,
            'adicionales': adicionales
        }
    )