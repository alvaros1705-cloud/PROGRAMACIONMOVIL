from django.contrib import admin
from .models import ProductoInventario

admin.site.register(ProductoInventario)