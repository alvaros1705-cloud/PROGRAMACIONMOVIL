from django.db import models


class ProductoInventario(models.Model):

    nombre = models.CharField(max_length=100)

    stock = models.IntegerField(default=0)

    minimo = models.IntegerField(default=5)

    precio = models.IntegerField(default=0)

    def __str__(self):
        return self.nombre
