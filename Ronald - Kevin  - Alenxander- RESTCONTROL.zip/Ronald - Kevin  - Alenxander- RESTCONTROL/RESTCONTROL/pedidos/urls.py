from django.urls import path

from . import views


urlpatterns = [

    path(
        '',
        views.pedidos_view,
        name='pedidos'
    ),

    path(
        'guardar/',
        views.guardar_pedido,
        name='guardar_pedido'
    ),

    path(
        'obtener/',
        views.obtener_pedidos,
        name='obtener_pedidos'
    ),

    path(
        'editar/<int:id>/',
        views.editar_pedido,
        name='editar_pedido'
    ),

    path(
        'actualizar/<int:id>/',
        views.actualizar_pedido,
        name='actualizar_pedido'
    ),

]