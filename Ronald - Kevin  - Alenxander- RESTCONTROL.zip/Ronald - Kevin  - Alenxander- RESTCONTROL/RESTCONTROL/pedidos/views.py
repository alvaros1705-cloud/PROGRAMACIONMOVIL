from django.shortcuts import render
from django.http import JsonResponse

from .models import (
    Mesa,
    Pedido,
    DetallePedido
)

from configuracion.models import Producto

import json


def pedidos_view(request):

    mesas = Mesa.objects.all()

    productos = Producto.objects.all().order_by(
        '-id'
    )

    return render(
        request,
        'pedidos/pedidos.html',
        {
            'mesas': mesas,
            'productos': productos
        }
    )


def guardar_pedido(request):

    if request.method == 'POST':

        data = json.loads(request.body)

        tipo = data.get(
            'tipo',
            'mesa'
        )

        mesa = None

        if tipo == 'mesa':

            mesa = Mesa.objects.get(
                id=data['mesa']
            )

            mesa.estado = 'ocupada'
            mesa.save()

        pedido = Pedido.objects.create(
            mesa=mesa,
            tipo=tipo,
            total=data['total']
        )

        for nombre, item in data['productos'].items():

            cantidad = int(
                item['cantidad']
            )

            observacion = item.get(
                'observacion',
                ''
            )

            DetallePedido.objects.create(
                pedido=pedido,
                producto=nombre,
                cantidad=cantidad,
                precio=item['precio'],
                observacion=observacion
            )

            try:

                producto = Producto.objects.get(
                    nombre=nombre
                )

                if producto.maneja_stock:

                    producto.stock -= cantidad

                    if producto.stock < 0:
                        producto.stock = 0

                    producto.save()

            except Producto.DoesNotExist:

                pass

        return JsonResponse({
            'mensaje': 'ok'
        })


def cocina_view(request):

    return render(
        request,
        'pedidos/cocina.html'
    )


def obtener_pedidos(request):

    pedidos = Pedido.objects.filter(
        estado='pendiente'
    ).order_by('-id')

    data = []

    for p in pedidos:

        detalles = DetallePedido.objects.filter(
            pedido=p
        )

        productos = []

        for d in detalles:

            productos.append({
                'producto': d.producto,
                'cantidad': d.cantidad,
                'observacion': d.observacion
            })

        if p.tipo == 'mesa' and p.mesa:

            destino = f"Mesa {p.mesa.numero}"

        elif p.tipo == 'llevar':

            destino = "🛍 Para llevar"

        else:

            destino = "🛵 Domicilio"

        data.append({
            'id': p.id,
            'destino': destino,
            'tipo': p.tipo,
            'productos': productos
        })

    return JsonResponse({
        'pedidos': data
    })


def marcar_listo(request, id):

    pedido = Pedido.objects.get(id=id)

    pedido.estado = 'listo'
    pedido.save()

    if pedido.mesa:

        pedido.mesa.estado = 'libre'
        pedido.mesa.save()

    return JsonResponse({
        'mensaje': 'ok'
    })


def editar_pedido(request, id):

    pedido = Pedido.objects.get(
        id=id
    )

    detalles = DetallePedido.objects.filter(
        pedido=pedido
    )

    productos = Producto.objects.all().order_by(
        '-id'
    )

    mesas = Mesa.objects.all()

    return render(
        request,
        'pedidos/editar_pedido.html',
        {
            'pedido': pedido,
            'detalles': detalles,
            'productos': productos,
            'mesas': mesas
        }
    )


def actualizar_pedido(request, id):

    if request.method == 'POST':

        pedido = Pedido.objects.get(
            id=id
        )

        data = json.loads(request.body)

        productos_nuevos = data.get(
            'productos',
            {}
        )

        total = data.get(
            'total',
            0
        )

        detalles_anteriores = DetallePedido.objects.filter(
            pedido=pedido
        )

        for d in detalles_anteriores:

            try:

                producto = Producto.objects.get(
                    nombre=d.producto
                )

                if producto.maneja_stock:

                    producto.stock += d.cantidad
                    producto.save()

            except Producto.DoesNotExist:

                pass

        detalles_anteriores.delete()

        for nombre, item in productos_nuevos.items():

            cantidad = int(
                item['cantidad']
            )

            precio = item['precio']

            observacion = item.get(
                'observacion',
                ''
            )

            DetallePedido.objects.create(
                pedido=pedido,
                producto=nombre,
                cantidad=cantidad,
                precio=precio,
                observacion=observacion
            )

            try:

                producto = Producto.objects.get(
                    nombre=nombre
                )

                if producto.maneja_stock:

                    producto.stock -= cantidad

                    if producto.stock < 0:
                        producto.stock = 0

                    producto.save()

            except Producto.DoesNotExist:

                pass

        pedido.total = total
        pedido.save()

        return JsonResponse({
            'mensaje': 'pedido actualizado'
        })