from django.db import models


# 🍽 MESAS
class Mesa(models.Model):

    numero = models.IntegerField(
        unique=True
    )

    estado = models.CharField(
        max_length=20,
        default='libre'
    )

    def __str__(self):

        return f"Mesa {self.numero}"


# 🧾 PEDIDOS
class Pedido(models.Model):

    mesa = models.ForeignKey(
        Mesa,
        on_delete=models.CASCADE,
        null=True,
        blank=True
    )

    total = models.IntegerField()

    estado = models.CharField(
        max_length=20,
        default='pendiente'
    )

    tipo = models.CharField(
        max_length=20,
        default='mesa'
    )

    facturado = models.BooleanField(
        default=False
    )

    fecha = models.DateTimeField(
        auto_now_add=True
    )

    observacion = models.TextField(
        blank=True,
        null=True
    )

    def __str__(self):

        if self.tipo == 'mesa' and self.mesa:

            return (
                f"Pedido {self.id} "
                f"- Mesa {self.mesa.numero}"
            )

        elif self.tipo == 'llevar':

            return (
                f"Pedido {self.id} "
                f"- Para Llevar"
            )

        elif self.tipo == 'domicilio':

            return (
                f"Pedido {self.id} "
                f"- Domicilio"
            )

        return f"Pedido {self.id}"


# 📦 DETALLE PEDIDO
class DetallePedido(models.Model):

    pedido = models.ForeignKey(
        Pedido,
        on_delete=models.CASCADE
    )

    producto = models.CharField(
        max_length=100
    )

    cantidad = models.IntegerField()

    precio = models.IntegerField()

    observacion = models.TextField(
        blank=True,
        null=True
    )

    def __str__(self):

        return f"{self.producto} x{self.cantidad}"