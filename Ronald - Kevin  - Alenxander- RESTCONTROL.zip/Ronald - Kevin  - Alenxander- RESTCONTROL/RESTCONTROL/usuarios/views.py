from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout


# 🔐 LOGIN
def login_view(request):

    error = ""

    if request.method == "POST":

        username = request.POST.get("username")
        password = request.POST.get("password")

        user = authenticate(
            request,
            username=username,
            password=password
        )

        if user is not None:

            login(request, user)

            return redirect('/')

        else:

            error = "Usuario o contraseña incorrectos"

    return render(request, 'usuarios/login.html', {
        'error': error
    })


# 🚪 LOGOUT
def logout_view(request):

    logout(request)

    return redirect('/login/')